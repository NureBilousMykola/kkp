# Shiyu Nexus Backend Documentation

## Overview

Shiyu Nexus Backend is a NestJS-based service providing APIs for managing game entities including agents, engines, bangboos, factions, and more. The application supports user authentication, role-based access control, and real-time features.

## Architecture

### Technology Stack

- **Framework**: NestJS 11
- **Database**: MongoDB
- **Caching**: Redis
- **Authentication**: JWT, Discord OAuth
- **Documentation**: Swagger/OpenAPI

### Core Modules

- **Users**: Authentication, profile management
- **Agents**: Game character management
- **Engines**: Game engine management
- **Bangboos**: Companion entity management
- **Factions**: Game faction management
- **Presets**: Draft configuration management
- **Draft**: Game session management
- **Tournaments**: Tournament management with brackets and agent saves
- **Enemies**: Enemy entity management

## Setup & Installation

### Prerequisites

- Node.js 20+
- MongoDB
- Redis
- pnpm

### Environment Configuration

Required environment variables:

- `MONGODB_URI`: MongoDB connection string
- `MONGODB_DB_NAME`: Database name
- `JWT_SECRET`: Secret for JWT signing
- `JWT_EXPIRATION`: Token expiration time
- `REDIS_URL`: Redis connection string
- `FRONTEND_URL`: Frontend application URL
- `DISCORD_CLIENT_ID`: Discord OAuth client ID
- `DISCORD_CLIENT_SECRET`: Discord OAuth client secret
- `DISCORD_CALLBACK_URL`: OAuth callback URL

### Development Workflow

1. Install dependencies: `pnpm install`
2. Start development server: `pnpm run start:dev`
3. Run tests: `pnpm run test`
4. Build for production: `pnpm run build`

## API Reference

### Authentication

- POST `/users/register`: Register new user
- POST `/users/login`: User login
- GET `/users/auth/discord`: Discord OAuth login
- GET `/users/profile`: Get user profile

### Agents

- GET `/agents`: List all agents with filtering
- GET `/agents/:id`: Get agent by ID
- POST `/agents`: Create new agent (admin)
- PATCH `/agents/:id`: Update agent (admin)
- DELETE `/agents/:id`: Delete agent (admin)

### Engines

- GET `/engines`: List all engines with filtering
- GET `/engines/:id`: Get engine by ID
- POST `/engines`: Create new engine (admin)
- PATCH `/engines/:id`: Update engine (admin)
- DELETE `/engines/:id`: Delete engine (admin)

### Bangboos

- GET `/bangboos`: List all bangboos with filtering
- GET `/bangboos/:id`: Get bangboo by ID
- POST `/bangboos`: Create new bangboo (admin)
- PATCH `/bangboos/:id`: Update bangboo (admin)
- DELETE `/bangboos/:id`: Delete bangboo (admin)

### Factions

- GET `/factions`: List all factions
- GET `/factions/:id`: Get faction by ID
- POST `/factions`: Create new faction (admin)
- PATCH `/factions/:id`: Update faction (admin)
- DELETE `/factions/:id`: Delete faction (admin)

### Presets

- GET `/presets`: List all presets with filtering
- GET `/presets/:id`: Get preset by ID
- POST `/presets`: Create new preset
- PATCH `/presets/:id`: Update preset
- DELETE `/presets/:id`: Delete preset

### Enemies

- GET `/enemies`: List all enemies with filtering
- GET `/enemies/:id`: Get enemy by ID
- POST `/enemies`: Create new enemy (admin)
- PATCH `/enemies/:id`: Update enemy (admin)
- DELETE `/enemies/:id`: Delete enemy (admin)

## Database Schema

### User

- email: String (required, unique)
- username: String (required, unique)
- passwordHash: String (optional for OAuth)
- discordId: String (optional)
- role: String (user, moderator, admin)
- ownedAgents: Array of agent references with level and mindscape
- ownedEngines: Array of engine references with level and ascension
- ownedBangboos: Array of bangboo references with level

### Agent

- name: String (required)
- fullName: String (required)
- normalizedName: String (required)
- rarity: String (S, A)
- specialty: String (attack, anomaly, defense, stun, support)
- attribute: String (physical, fire, ice, ether, electric, frost)
- faction: Reference to Faction
- isReleased: Boolean
- isLimited: Boolean

### Engine

- name: String (required)
- normalizedName: String (required)
- rarity: String (S, A, B)
- specialty: String
- isCraftable: Boolean
- isEventLimited: Boolean
- signatureAgent: Reference to Agent (optional)

### Bangboo

- name: String (required)
- normalizedName: String (required)
- rarity: String (S, A)

### Faction

- name: String (required)
- normalizedName: String (required, unique)

### Enemy

- name: String (required)
- normalizedName: String (required)
- category: String (ether_mutants, thugs, corrupted, rebel_soldiers, special)
- weaknessAttributes: Array of Strings
- resistanceAttributes: Array of Strings

## Deployment

### Docker Deployment

```bash
docker build -t shiyu-nexus-backend .
docker run -p 3030:3030 -e MONGODB_URI=... shiyu-nexus-backend
```

### Docker Compose

Use the provided docker-compose.yml file to deploy with MongoDB and Redis:

```bash
docker-compose up -d
```

## Security Considerations

- All API endpoints requiring authentication are protected with JWT
- Admin-only endpoints are protected with role-based guards
- CORS is configured to allow only the frontend application
- Passwords are hashed using bcrypt
- Rate limiting is recommended for production
