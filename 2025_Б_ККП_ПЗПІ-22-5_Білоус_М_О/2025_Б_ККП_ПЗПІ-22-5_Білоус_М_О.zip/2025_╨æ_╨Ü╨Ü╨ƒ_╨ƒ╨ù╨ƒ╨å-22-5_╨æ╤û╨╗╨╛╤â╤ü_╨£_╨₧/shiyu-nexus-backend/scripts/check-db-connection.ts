import * as dotenv from "dotenv";
// scripts/check-db-connection.ts
import mongoose from "mongoose";

// Load environment variables
dotenv.config({ path: ".env" });
dotenv.config(); // Fallback to .env if .env.local doesn't exist

async function checkConnection() {
	try {
		console.log("Checking MongoDB connection...");

		// Get MongoDB connection string from environment variables
		const MONGODB_URI = process.env.MONGODB_URI;

		if (!MONGODB_URI) {
			console.error("MONGODB_URI is not defined in environment variables");
			process.exit(1);
		}

		console.log(
			`Connecting to: ${MONGODB_URI.replace(/:([^:@]+)@/, ":****@")}`
		); // Hide password in logs

		// MongoDB connection options
		const options = {
			useNewUrlParser: true,
			useUnifiedTopology: true,
			authSource: "admin",
			retryWrites: true
		};

		// Check if we have username and password in separate env vars
		let connectionString = MONGODB_URI;
		if (
			!MONGODB_URI.includes("@") &&
			process.env.MONGO_USERNAME &&
			process.env.MONGO_PASSWORD
		) {
			console.log(
				"Using separate username/password from environment variables"
			);
			const mongoUri = new URL(MONGODB_URI);
			mongoUri.username = encodeURIComponent(process.env.MONGO_USERNAME);
			mongoUri.password = encodeURIComponent(process.env.MONGO_PASSWORD);
			connectionString = mongoUri.toString();
		}

		// Connect to MongoDB
		const conn = await mongoose.connect(connectionString, options);

		console.log("✅ Successfully connected to MongoDB");
		// Get MongoDB server information
		const adminDb = conn.connection.db.admin();
		const serverInfo = await adminDb.serverInfo();
		console.log(`MongoDB version: ${serverInfo.version}`);

		// List available databases
		const dbInfo = await adminDb.listDatabases();
		console.log("\nAvailable databases:");

		for (const db of dbInfo.databases) {
			console.log(
				`- ${db.name} (${(db.sizeOnDisk / 1024 / 1024).toFixed(2)} MB)`
			);
		}

		// List collections in the current database
		const collections = await conn.connection.db.listCollections().toArray();
		console.log(`\nCollections in ${conn.connection.db.databaseName}:`);
		if (collections.length === 0) {
			console.log("No collections found. Database might be empty.");
		} else {
			for (const collection of collections) {
				console.log(`- ${collection.name}`);
			}
		}

		// Close connection
		await mongoose.disconnect();
		console.log("\nConnection closed");
		process.exit(0);
	} catch (error) {
		console.error("❌ Error connecting to MongoDB:", error);
		process.exit(1);
	}
}

// Run the check
checkConnection();
