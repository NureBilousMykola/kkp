import * as readline from "node:readline";
// scripts/create-admin.ts
import * as bcrypt from "bcrypt";
import * as dotenv from "dotenv";
import mongoose from "mongoose";
// import { UserRole } from '../src/shared/enums/user-role.enum';

// Load environment variables
dotenv.config({ path: ".env" });
dotenv.config({ path: ".env.local" }); // Also load local overrides if present

// Helper function to prompt for input
function prompt(question: string): Promise<string> {
	const rl = readline.createInterface({
		input: process.stdin,
		output: process.stdout
	});

	return new Promise((resolve) => {
		rl.question(question, (answer) => {
			rl.close();
			resolve(answer);
		});
	});
}

// Get User model schema
const UserSchema = new mongoose.Schema({
	email: { type: String, required: true, unique: true },
	username: { type: String, required: true, unique: true },
	passwordHash: { type: String },
	discordId: { type: String },
	discordUsername: { type: String },
	discordAvatar: { type: String },
	role: { type: String, enum: ["user", "moderator", "admin"], default: "user" },
	permissions: [{ type: String }],
	ownedAgents: [
		{
			agent: { type: mongoose.Schema.Types.ObjectId, ref: "Agent" },
			level: { type: Number, min: 1, max: 60 },
			mindscape: { type: Number, min: 0, max: 6 }
		}
	],
	ownedEngines: [
		{
			engine: { type: mongoose.Schema.Types.ObjectId, ref: "Engine" },
			level: { type: Number, min: 1, max: 60 },
			ascension: { type: Number, min: 1, max: 5 }
		}
	],
	ownedBangboos: [
		{
			bangboo: { type: mongoose.Schema.Types.ObjectId, ref: "Bangboo" },
			level: { type: Number, min: 1, max: 60 },
			ascension: { type: Number, min: 1, max: 5 }
		}
	]
});

async function createAdminUser() {
	try {
		// Get MongoDB connection string
		const MONGODB_URI = "mongodb://admin:secret@localhost:27017/shiyu-mongo";
		if (!MONGODB_URI) {
			throw new Error("MONGODB_URI is not defined in environment variables");
		}

		console.log("Connecting to MongoDB...");

		await mongoose.connect(MONGODB_URI, {
			authSource: "admin",
			retryWrites: true
		});

		console.log("Connected to MongoDB");

		// Initialize User model
		const UserModel =
			mongoose.models.User || mongoose.model("User", UserSchema);

		// Check if admin user already exists
		const adminExists = await UserModel.findOne({ role: "admin" });
		if (adminExists) {
			console.log(
				`Admin user already exists: ${adminExists.username} (${adminExists.email})`
			);
			const createAnyway = await prompt(
				"Do you want to create another admin user? (y/n): "
			);
			if (createAnyway.toLowerCase() !== "y") {
				console.log("Operation cancelled.");
				await mongoose.disconnect();
				return;
			}
		}

		// Get admin user details from env or prompt
		let adminEmail = process.env.ADMIN_EMAIL;
		let adminUsername = process.env.ADMIN_USERNAME;
		let adminPassword = process.env.ADMIN_PASSWORD;

		if (!adminEmail) {
			adminEmail = await prompt("Enter admin email: ");
		}

		if (!adminUsername) {
			adminUsername = await prompt("Enter admin username: ");
		}

		if (!adminPassword) {
			adminPassword = await prompt("Enter admin password: ");
		}

		// Validate input
		if (!adminEmail || !adminUsername || !adminPassword) {
			throw new Error("Admin email, username, and password are required");
		}

		// Check if user with same email/username already exists
		const existingUser = await UserModel.findOne({
			$or: [{ email: adminEmail }, { username: adminUsername }]
		});

		if (existingUser) {
			throw new Error(
				`User with ${existingUser.email === adminEmail ? "this email" : "this username"} already exists`
			);
		}

		// Hash the password
		const saltRounds = 10;
		const passwordHash = await bcrypt.hash(adminPassword, saltRounds);

		// Create the admin user
		const adminUser = new UserModel({
			email: adminEmail,
			username: adminUsername,
			passwordHash,
			role: "admin",
			permissions: ["*"] // Full permissions
		});

		await adminUser.save();
		console.log(
			`Admin user created successfully: ${adminUsername} (${adminEmail})`
		);

		// Disconnect from MongoDB
		await mongoose.disconnect();
		console.log("Disconnected from MongoDB");
	} catch (error) {
		console.error("Error creating admin user:", error);
		await mongoose.disconnect();
		process.exit(1);
	}
}

// Run the script
createAdminUser().catch(console.error);
