import "dotenv/config";
import { type Agent, AgentSchema } from "@schemas/agent.schema";
import { type Engine, EngineSchema } from "@schemas/engine.schema";
import { type Faction, FactionSchema } from "@schemas/faction.schema";
import { type Enemy, EnemySchema } from "@schemas/enemy.schema";
import { connect, model } from "mongoose";
import fetch from "node-fetch";

// Log environment variables for debugging (without exposing sensitive data)
console.log("Environment check:", {
	MONGODB_URI_EXISTS: !!process.env.MONGODB_URI,
	MONGO_USERNAME_EXISTS: !!process.env.MONGO_USERNAME,
	MONGO_PASSWORD_EXISTS: !!process.env.MONGO_PASSWORD
});

// GitHub raw content URLs for data files
const AGENTS_URL =
	"https://raw.githubusercontent.com/shiyu-nexus/shiyu-nexus-assets/main/agents.json";
const ENGINES_URL =
	"https://raw.githubusercontent.com/shiyu-nexus/shiyu-nexus-assets/main/engines.json";
const ENEMIES_URL =
	"https://raw.githubusercontent.com/shiyu-nexus/shiyu-nexus-assets/main/enemies.json";

// Fetch data from GitHub repository
async function fetchData() {
	console.log("Fetching data from GitHub...");

	try {
		// Fetch agents data
		console.log(`Fetching agents from: ${AGENTS_URL}`);
		const agentsResponse = await fetch(AGENTS_URL);
		if (!agentsResponse.ok) {
			throw new Error(
				`Failed to fetch agents data: ${agentsResponse.status} ${agentsResponse.statusText}`
			);
		}
		const agentsData = (await agentsResponse.json()) as any[];

		// Fetch engines data
		console.log(`Fetching engines from: ${ENGINES_URL}`);
		const enginesResponse = await fetch(ENGINES_URL);
		if (!enginesResponse.ok) {
			throw new Error(
				`Failed to fetch engines data: ${enginesResponse.status} ${enginesResponse.statusText}`
			);
		}
		const enginesData = (await enginesResponse.json()) as any[];

		// Fetch enemies data
		console.log(`Fetching enemies from: ${ENEMIES_URL}`);
		const enemiesResponse = await fetch(ENEMIES_URL);
		if (!enemiesResponse.ok) {
			throw new Error(
				`Failed to fetch enemies data: ${enemiesResponse.status} ${enemiesResponse.statusText}`
			);
		}
		const enemiesData = (await enemiesResponse.json()) as any[];

		// Log the fetched data counts
		console.log(
			`Fetched ${agentsData.length} agents, ${enginesData.length} engines, and ${enemiesData.length} enemies`
		);

		// Log a sample of the data to verify structure
		if (agentsData.length > 0) {
			console.log("Sample agent data:", JSON.stringify(agentsData[0], null, 2));
		}
		if (enginesData.length > 0) {
			console.log(
				"Sample engine data:",
				JSON.stringify(enginesData[0], null, 2)
			);
		}
		if (enemiesData.length > 0) {
			console.log(
				"Sample enemy data:",
				JSON.stringify(enemiesData[0], null, 2)
			);
		}

		return { agentsData, enginesData, enemiesData };
	} catch (error) {
		console.error("Error fetching data:", error);
		throw error;
	}
}

// Get MongoDB connection string from environment
const MONGODB_URI =
	process.env.MONGODB_URI ||
	"mongodb://admin:secret@localhost:27017/shiyu-mongo";

// Make sure the database name is explicitly set
const dbName = MONGODB_URI.split("/").pop() || "shiyu-mongo";

// Updated MongoDB connection options
const mongoOptions = {
	retryWrites: true,
	authSource: "admin", // Specify the authentication database
	dbName: dbName // Explicitly set the database name
};

// Initialize models
const AgentModel = model<Agent>("Agent", AgentSchema);
const EngineModel = model<Engine>("Engine", EngineSchema);
const FactionModel = model<Faction>("Faction", FactionSchema);
const EnemyModel = model<Enemy>("Enemy", EnemySchema);

// Function to convert string booleans to actual booleans
const convertStringToBoolean = (value: string | boolean): boolean => {
	if (typeof value === "boolean") return value;
	return value.toLowerCase() === "true";
};

// Function to seed factions
async function seedFactions(agentsData: any[]): Promise<Map<string, string>> {
	console.log("Seeding factions...");

	// Extract unique factions from agents data
	const uniqueFactions = [
		...new Set(agentsData.map((agent) => agent.faction))
	] as string[];

	console.log(
		`Found ${uniqueFactions.length} unique factions:`,
		uniqueFactions
	);

	// Create faction documents
	const factionDocs = uniqueFactions.map((factionName) => ({
		name: factionName,
		normalizedName: factionName.toLowerCase().replace(/\s+/g, "_")
	}));

	// Insert factions
	await FactionModel.deleteMany({});
	console.log("Cleared existing factions");

	const insertedFactions = await FactionModel.insertMany(factionDocs);
	console.log(`${insertedFactions.length} factions inserted`);

	// Create a map for faction name to ID lookup
	const factionMap = new Map<string, string>();
	for (const faction of insertedFactions) {
		factionMap.set(faction.name, faction._id.toString());
	}

	return factionMap;
}

// Function to seed agents
async function seedAgents(
	factionMap: Map<string, string>,
	agentsData: any[]
): Promise<Map<string, string>> {
	console.log("Seeding agents...");

	// Transform agents data
	const transformedAgents = agentsData.map((agent) => {
		const factionId = factionMap.get(agent.faction);
		if (!factionId) {
			console.warn(
				`Warning: Faction not found for agent ${agent.name}: ${agent.faction}`
			);
		}

		return {
			name: agent.name,
			fullName: agent.fullName || agent.name, // Fallback to name if fullName is missing
			normalizedName:
				agent.normalizedName || agent.name.toLowerCase().replace(/\s+/g, "_"),
			isReleased: convertStringToBoolean(agent.isReleased),
			isLimited: convertStringToBoolean(agent.isLimited),
			rarity: agent.rarity,
			specialty: agent.speciality || agent.specialty, // Handle both spellings
			attribute: agent.attribute,
			faction: factionId,
			imageUrl: agent.imageUrl,
			iconUrl: agent.iconUrl
		};
	});

	// Insert agents
	await AgentModel.deleteMany({});
	console.log("Cleared existing agents");

	const insertedAgents = await AgentModel.insertMany(transformedAgents);
	console.log(`${insertedAgents.length} agents inserted`);

	// Create a map for agent name to ID lookup
	const agentMap = new Map<string, string>();
	for (const agent of insertedAgents) {
		agentMap.set(agent.normalizedName, agent._id.toString());
	}

	return agentMap;
}

// Function to seed engines
async function seedEngines(agentMap: Map<string, string>, enginesData: any[]) {
	console.log("Seeding engines...");

	// Transform engines data
	const transformedEngines = enginesData.map((engine) => {
		const transformed: any = {
			name: engine.name,
			normalizedName:
				engine.normalizedName || engine.name.toLowerCase().replace(/\s+/g, "_"),
			rarity: engine.rarity,
			specialty: engine.speciality || engine.specialty, // Handle both spellings
			isCraftable: convertStringToBoolean(engine.isCraftable),
			isEventLimited: convertStringToBoolean(engine.isEventLimited),
			maxAscension: engine.maxAscension || 5, // Default max ascension to 5
			imageUrl: engine.imageUrl
		};

		// Add signature agent if it's not "null"
		if (engine.signatureAgent && engine.signatureAgent !== "null") {
			const agentId = agentMap.get(engine.signatureAgent);
			if (agentId) {
				transformed.signatureAgent = agentId;
			} else {
				console.warn(
					`Warning: Signature agent not found for engine ${engine.name}: ${engine.signatureAgent}`
				);
			}
		}

		return transformed;
	});

	// Insert engines
	await EngineModel.deleteMany({});
	console.log("Cleared existing engines");

	const insertedEngines = await EngineModel.insertMany(transformedEngines);
	console.log(`${insertedEngines.length} engines inserted`);
}

// Function to seed enemies
async function seedEnemies(enemiesData: any[]) {
	console.log("Seeding enemies...");

	// Transform enemies data
	const transformedEnemies = enemiesData.map((enemy) => ({
		name: enemy.name,
		normalizedName:
			enemy.normalized_name || enemy.name.toLowerCase().replace(/\s+/g, "_"),
		category: enemy.category,
		weaknessAttributes: enemy.weaknessAttributes || [],
		resistanceAttributes: enemy.resistanceAttributes || [],
		imageUrl: enemy.imageUrl
	}));

	// Insert enemies
	await EnemyModel.deleteMany({});
	console.log("Cleared existing enemies");

	const insertedEnemies = await EnemyModel.insertMany(transformedEnemies);
	console.log(`${insertedEnemies.length} enemies inserted`);
}

// Main function to seed database
async function seedDatabase() {
	try {
		console.log("Starting database seeding process...");
		console.log(
			"MongoDB URI:",
			MONGODB_URI.replace(/\/\/([^:]+):([^@]+)@/, "//***:***@")
		); // Hide credentials in logs

		console.log("Connecting to MongoDB...");
		await connect(MONGODB_URI, mongoOptions);
		console.log("Successfully connected to MongoDB");

		// Fetch data from GitHub
		const { agentsData, enginesData, enemiesData } = await fetchData();

		// Seed data in order: factions -> agents -> engines -> enemies
		const factionMap = await seedFactions(agentsData);
		const agentMap = await seedAgents(factionMap, agentsData);
		await seedEngines(agentMap, enginesData);
		await seedEnemies(enemiesData);

		console.log("Database seeding completed successfully");
		process.exit(0);
	} catch (error) {
		console.error("Error seeding database:", error);
		console.error("Stack trace:", error.stack);
		process.exit(1);
	}
}

// Run the seeding function
seedDatabase().catch((err) => {
	console.error("Unhandled error in seeding process:", err);
	process.exit(1);
});
