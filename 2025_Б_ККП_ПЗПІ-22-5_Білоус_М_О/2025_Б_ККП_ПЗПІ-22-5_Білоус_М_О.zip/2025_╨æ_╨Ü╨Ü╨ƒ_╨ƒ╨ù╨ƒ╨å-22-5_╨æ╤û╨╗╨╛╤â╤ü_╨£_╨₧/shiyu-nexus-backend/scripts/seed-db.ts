// scripts/seed-db.ts
import "dotenv/config";
import { type Agent, AgentSchema } from "@schemas/agent.schema";
import { type Engine, EngineSchema } from "@schemas/engine.schema";
import { type Faction, FactionSchema } from "@schemas/faction.schema";
import { connect } from "mongoose";
import { model } from "mongoose";
import fetch from "node-fetch";

// GitHub raw content URLs for data files
const AGENTS_URL =
	"https://raw.githubusercontent.com/shiyu-nexus/shiyu-nexus-assets/refs/heads/main/agents.json";
const ENGINES_URL =
	"https://raw.githubusercontent.com/shiyu-nexus/shiyu-nexus-assets/refs/heads/main/engines.json";

// Fetch data from GitHub repository
async function fetchData() {
	console.log("Fetching data from GitHub...");

	try {
		// Fetch agents data
		const agentsResponse = await fetch(AGENTS_URL);
		if (!agentsResponse.ok) {
			throw new Error(
				`Failed to fetch agents data: ${agentsResponse.statusText}`
			);
		}
		const agentsData = await agentsResponse.json();

		// Fetch engines data
		const enginesResponse = await fetch(ENGINES_URL);
		if (!enginesResponse.ok) {
			throw new Error(
				`Failed to fetch engines data: ${enginesResponse.statusText}`
			);
		}
		const enginesData = await enginesResponse.json();

		// Log the fetched data counts
		console.log(
			`Fetched ${(agentsData as any[]).length} agents and ${(enginesData as any[]).length} engines`
		);
		return { agentsData, enginesData };
	} catch (error) {
		console.error("Error fetching data:", error);
		throw error;
	}
}

// Get MongoDB connection string from environment
const MONGODB_URI =
	process.env.MONGODB_URI ||
	"mongodb://admin:secret@localhost:27017/shiyu-mongo";

// Make sure the database name is explicitly set
const dbName = MONGODB_URI.split("/").pop() || "shiyu-mongo";

// Updated MongoDB connection options
const mongoOptions = {
	retryWrites: true,
	authSource: "admin", // Specify the authentication database
	dbName: dbName // Explicitly set the database name
};

// Initialize models
const AgentModel = model<Agent>("Agent", AgentSchema);
const EngineModel = model<Engine>("Engine", EngineSchema);
const FactionModel = model<Faction>("Faction", FactionSchema);

// Function to convert string booleans to actual booleans
const convertStringToBoolean = (value: string): boolean => {
	return value.toLowerCase() === "true";
};

// Function to seed factions
async function seedFactions(agentsData) {
	console.log("Seeding factions...");

	// Extract unique factions from agents data
	const uniqueFactions = [
		...new Set(agentsData.map((agent) => agent.faction))
	] as string[];

	// Create faction documents
	const factionDocs = uniqueFactions.map((factionName) => ({
		name: factionName,
		normalizedName: factionName.toLowerCase().replace(/\s+/g, "_")
	}));

	// Insert factions
	await FactionModel.deleteMany({});
	const insertedFactions = await FactionModel.insertMany(factionDocs);

	console.log(`${insertedFactions.length} factions inserted`);

	// Create a map for faction name to ID lookup
	const factionMap = new Map();
	for (const faction of insertedFactions) {
		factionMap.set(faction.name, faction._id);
	}

	return factionMap;
}

// Function to seed agents
async function seedAgents(factionMap: Map<string, string>, agentsData) {
	console.log("Seeding agents...");

	// Transform agents data
	const transformedAgents = agentsData.map((agent) => ({
		name: agent.name,
		fullName: agent.fullName,
		normalizedName: agent.normalizedName,
		isReleased: convertStringToBoolean(agent.isReleased),
		isLimited: convertStringToBoolean(agent.isLimited),
		rarity: agent.rarity,
		specialty: agent.speciality, // Note: correct the field name from speciality to specialty
		attribute: agent.attribute,
		faction: factionMap.get(agent.faction), // Changed from factionId to faction
		imageUrl: agent.imageUrl,
		iconUrl: agent.iconUrl
	}));

	// Insert agents
	await AgentModel.deleteMany({});
	const insertedAgents = await AgentModel.insertMany(transformedAgents);

	console.log(`${insertedAgents.length} agents inserted`);

	// Create a map for agent name to ID lookup
	const agentMap = new Map();
	for (const agent of insertedAgents) {
		agentMap.set(agent.normalizedName, agent._id);
	}

	return agentMap;
}

// Function to seed engines
async function seedEngines(agentMap: Map<string, string>, enginesData) {
	console.log("Seeding engines...");

	// Transform engines data
	const transformedEngines = enginesData.map((engine) => {
		const transformed: any = {
			name: engine.name,
			normalizedName: engine.normalizedName,
			rarity: engine.rarity,
			specialty: engine.speciality, // Note: correct the field name from speciality to specialty
			isCraftable: convertStringToBoolean(engine.isCraftable),
			isEventLimited: convertStringToBoolean(engine.isEventLimited),
			maxAscension: 5, // Default max ascension to 5
			imageUrl: engine.imageUrl
		};

		// Add signature agent if it's not "null"
		if (engine.signatureAgent && engine.signatureAgent !== "null") {
			transformed.signatureAgent = agentMap.get(engine.signatureAgent); // Changed from signatureAgentId to signatureAgent
		}

		return transformed;
	});

	// Insert engines
	await EngineModel.deleteMany({});
	const insertedEngines = await EngineModel.insertMany(transformedEngines);

	console.log(`${insertedEngines.length} engines inserted`);
}

// Main function to seed database
async function seedDatabase() {
	try {
		console.log("Connecting to MongoDB...");

		// Check if we have username and password in the connection string
		if (
			!MONGODB_URI.includes("@") &&
			process.env.MONGO_USERNAME &&
			process.env.MONGO_PASSWORD
		) {
			console.log("Using environment variables for MongoDB authentication");
			// If credentials are provided as separate environment variables
			const mongoUri = new URL(MONGODB_URI);
			mongoUri.username = encodeURIComponent(process.env.MONGO_USERNAME);
			mongoUri.password = encodeURIComponent(process.env.MONGO_PASSWORD);
			await connect(mongoUri.toString(), mongoOptions);
		} else {
			// Either credentials are in the URI or no auth is needed
			await connect(MONGODB_URI, mongoOptions);
		}

		// Fetch data from GitHub
		const { agentsData, enginesData } = await fetchData();

		// Seed data in order: factions -> agents -> engines
		const factionMap = await seedFactions(agentsData);
		const agentMap = await seedAgents(factionMap, agentsData);
		await seedEngines(agentMap, enginesData);

		console.log("Database seeding completed successfully");
		process.exit(0);
	} catch (error) {
		console.error("Error seeding database:", error);
		process.exit(1);
	}
}

// Run the seeding function
seedDatabase();
