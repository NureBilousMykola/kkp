import configuration from "@/config/configuration";
import { AgentsModule } from "@modules/agents/agents.module";
import { BangboosModule } from "@modules/bangboos/bangboos.module";
import { CostSystemsModule } from "@modules/cost-systems/cost-systems.module";
import { DraftModule } from "@modules/draft/draft.module";
import { EnginesModule } from "@modules/engines/engines.module";
import { PresetsModule } from "@modules/presets/presets.module";
import { TournamentsModule } from "@modules/tournaments/tournaments.module";
import { UsersModule } from "@modules/users/users.module";
import { RedisModule, type RedisModuleOptions } from "@nestjs-modules/ioredis";
import { Module } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { MongooseModule } from "@nestjs/mongoose";
import { EnemiesModule } from "./modules/enemies/enemies.module";

@Module({
	imports: [
		ConfigModule.forRoot({
			isGlobal: true,
			load: [configuration]
		}),
		MongooseModule.forRootAsync({
			imports: [ConfigModule],
			useFactory: async (configService: ConfigService) => ({
				uri: configService.get<string>("database.uri"),
				dbName: configService.get<string>("database.name")
			}),
			inject: [ConfigService]
		}),
		RedisModule.forRootAsync({
			imports: [ConfigModule],
			useFactory: (configService: ConfigService): RedisModuleOptions => ({
				type: "single",
				url: configService.get<string>("redis.url")
			}),
			inject: [ConfigService]
		}),
		UsersModule,
		AgentsModule,
		EnginesModule,
		EnemiesModule,
		BangboosModule,
		CostSystemsModule,
		PresetsModule,
		DraftModule,
		TournamentsModule
	]
})
export class AppModule {}
