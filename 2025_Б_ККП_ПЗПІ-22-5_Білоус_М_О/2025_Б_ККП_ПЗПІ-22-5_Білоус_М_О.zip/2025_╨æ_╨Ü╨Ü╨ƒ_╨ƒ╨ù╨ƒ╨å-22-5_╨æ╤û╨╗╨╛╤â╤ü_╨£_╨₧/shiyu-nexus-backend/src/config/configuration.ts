export default () => ({
	port: Number.parseInt(process.env.PORT, 10) || 3030,
	database: {
		uri: process.env.MONGODB_URI,
		name: process.env.MONGODB_DB_NAME
	},
	jwt: {
		secret: process.env.JWT_SECRET,
		expirationTime: process.env.JWT_EXPIRATION || "1d"
	},
	redis: {
		url: process.env.REDIS_URL || "redis://localhost:6379",
		ttl: Number.parseInt(process.env.REDIS_TTL, 10) || 3600
	},
	discord: {
		clientId: process.env.DISCORD_CLIENT_ID,
		clientSecret: process.env.DISCORD_CLIENT_SECRET,
		callbackURL:
			process.env.DISCORD_CALLBACK_URL ||
			"http://localhost:3030/auth/discord/callback"
	},
	admin: {
		initialPassword: process.env.ADMIN_INITIAL_PASSWORD
	},
	frontend: {
		url: process.env.FRONTEND_URL || "http://localhost:3000"
	}
});
