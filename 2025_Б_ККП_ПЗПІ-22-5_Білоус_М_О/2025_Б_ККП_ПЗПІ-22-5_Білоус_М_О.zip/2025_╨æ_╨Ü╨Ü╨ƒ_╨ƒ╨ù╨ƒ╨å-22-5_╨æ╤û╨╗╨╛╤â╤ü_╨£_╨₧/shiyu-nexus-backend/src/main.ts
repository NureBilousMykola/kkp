import { ValidationPipe } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import * as cookieParser from "cookie-parser";
import * as morgan from "morgan";
import { AppModule } from "./app.module";

async function bootstrap() {
	const app = await NestFactory.create(AppModule);

	app.enableCors({
		origin: process.env.FRONTEND_URL || "http://localhost:3000",
		credentials: true
	});
	// Global validation pipe (if using DTOs w/ class-validator)
	app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

	// Use morgan
	app.use(morgan("dev"));
	// Use cookie parser
	app.use(cookieParser());

	await app.listen(3030);
	console.log("Application is running on: http://localhost:3030");
}
bootstrap();
