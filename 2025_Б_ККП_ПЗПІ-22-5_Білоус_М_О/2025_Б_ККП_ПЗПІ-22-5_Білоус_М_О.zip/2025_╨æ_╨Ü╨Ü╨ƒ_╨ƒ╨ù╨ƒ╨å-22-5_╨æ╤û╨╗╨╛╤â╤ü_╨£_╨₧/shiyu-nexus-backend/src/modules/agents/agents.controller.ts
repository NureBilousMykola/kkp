import { Roles } from "@modules/users/decorators/roles.decorator";
import { JwtAuthGuard } from "@modules/users/guards/jwt-auth.guard";
import { RolesGuard } from "@modules/users/guards/roles.guard";
import {
	BadRequestException,
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	Query,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiResponse, ApiTags } from "@nestjs/swagger";
import { UserRole } from "@shared/enums/user-role.enum";
import { AgentsService } from "./agents.service";
import { CreateAgentDto } from "./dto/create-agent.dto";
import { QueryAgentDto } from "./dto/query-agent.dto";
import { UpdateAgentDto } from "./dto/update-agent.dto";

@ApiTags("agents")
@Controller("agents")
export class AgentsController {
	constructor(private readonly agentsService: AgentsService) {}

	@Post()
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Create a new agent" })
	@ApiResponse({ status: 201, description: "Agent successfully created" })
	@ApiResponse({ status: 400, description: "Invalid input" })
	async create(@Body(ValidationPipe) createAgentDto: CreateAgentDto) {
		try {
			return await this.agentsService.create(createAgentDto);
		} catch (error) {
			if (error.code === 11000) {
				// MongoDB duplicate key error
				throw new BadRequestException("Agent with this name already exists");
			}
			throw error;
		}
	}

	@Get()
	@ApiOperation({ summary: "Get all agents with optional filtering" })
	async findAll(@Query(ValidationPipe) query: QueryAgentDto) {
		return this.agentsService.findAll(query);
	}

	@Get(":id")
	@ApiOperation({ summary: "Get agent by ID" })
	@ApiResponse({ status: 200, description: "Returns the agent" })
	@ApiResponse({ status: 404, description: "Agent not found" })
	async findOne(@Param("id") id: string) {
		return this.agentsService.findOne(id);
	}

	@Get("name/:normalizedName")
	@ApiOperation({ summary: "Get agent by normalized name" })
	async findByNormalizedName(@Param("normalizedName") normalizedName: string) {
		return this.agentsService.findByNormalizedName(normalizedName);
	}

	@Patch(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update an agent" })
	async update(
		@Param("id") id: string,
		@Body(ValidationPipe) updateAgentDto: UpdateAgentDto
	) {
		try {
			return await this.agentsService.update(id, updateAgentDto);
		} catch (error) {
			if (error.code === 11000) {
				throw new BadRequestException("Agent with this name already exists");
			}
			throw error;
		}
	}

	@Delete(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Delete an agent" })
	async remove(@Param("id") id: string) {
		return this.agentsService.remove(id);
	}

	// Additional endpoints for specific queries
	@Get("filter/released")
	@ApiOperation({ summary: "Get all released agents" })
	async getReleasedAgents() {
		return this.agentsService.getReleasedAgents();
	}

	@Get("filter/limited")
	@ApiOperation({ summary: "Get all limited agents" })
	async getLimitedAgents() {
		return this.agentsService.getLimitedAgents();
	}

	@Get("filter/attribute/:attribute")
	@ApiOperation({ summary: "Get agents by attribute" })
	async getAgentsByAttribute(@Param("attribute") attribute: string) {
		return this.agentsService.getAgentsByAttribute(attribute);
	}

	@Get("filter/specialty/:specialty")
	@ApiOperation({ summary: "Get agents by specialty" })
	async getAgentsBySpecialty(@Param("specialty") specialty: string) {
		return this.agentsService.getAgentsBySpecialty(specialty);
	}

	@Get("filter/rarity/:rarity")
	@ApiOperation({ summary: "Get agents by rarity" })
	async getAgentsByRarity(@Param("rarity") rarity: string) {
		return this.agentsService.getAgentsByRarity(rarity);
	}
}
