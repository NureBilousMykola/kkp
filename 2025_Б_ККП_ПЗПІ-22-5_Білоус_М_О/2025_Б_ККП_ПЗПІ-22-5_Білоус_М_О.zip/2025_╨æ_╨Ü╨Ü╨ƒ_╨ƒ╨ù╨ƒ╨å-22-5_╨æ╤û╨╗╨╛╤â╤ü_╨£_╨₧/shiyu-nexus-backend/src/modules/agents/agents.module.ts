import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Agent, AgentSchema } from "@schemas/agent.schema";
import { FactionsModule } from "../factions/factions.module";
import { AgentsController } from "./agents.controller";
import { AgentsService } from "./agents.service";

@Module({
	imports: [
		MongooseModule.forFeature([{ name: Agent.name, schema: AgentSchema }]),
		FactionsModule
	],
	controllers: [AgentsController],
	providers: [AgentsService],
	exports: [AgentsService]
})
export class AgentsModule {}
