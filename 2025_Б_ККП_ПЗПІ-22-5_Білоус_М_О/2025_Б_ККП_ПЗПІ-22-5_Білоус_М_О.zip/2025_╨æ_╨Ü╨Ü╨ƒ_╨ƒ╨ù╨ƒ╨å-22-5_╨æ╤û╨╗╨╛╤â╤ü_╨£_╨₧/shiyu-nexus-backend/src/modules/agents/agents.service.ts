//src/modules/agents/agents.service.ts
import {
	ConflictException,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Agent } from "@schemas/agent.schema";
import { Model } from "mongoose";
import { CreateAgentDto } from "./dto/create-agent.dto";
import { QueryAgentDto } from "./dto/query-agent.dto";
import { UpdateAgentDto } from "./dto/update-agent.dto";

@Injectable()
export class AgentsService {
	constructor(@InjectModel(Agent.name) private agentModel: Model<Agent>) {}

	async create(createAgentDto: CreateAgentDto): Promise<Agent> {
		// Check if agent with same normalized name exists
		const existing = await this.agentModel.findOne({
			normalizedName: createAgentDto.normalizedName
		});

		if (existing) {
			throw new ConflictException(
				"Agent with this normalized name already exists"
			);
		}

		const agent = new this.agentModel(createAgentDto);
		return agent.save();
	}

	async findAll(query: QueryAgentDto = {}): Promise<Agent[]> {
		const filter: any = {};

		// Build filter based on query parameters
		if (query.rarity) filter.rarity = query.rarity;
		if (query.specialty) filter.specialty = query.specialty;
		if (query.attribute) filter.attribute = query.attribute;
		if (query.isReleased !== undefined) filter.isReleased = query.isReleased;
		if (query.isLimited !== undefined) filter.isLimited = query.isLimited;
		if (query.name !== undefined)
			filter.name = { $regex: query.name, $options: "i" };

		return this.agentModel.find(filter).exec();
	}

	async findOne(id: string): Promise<Agent> {
		const agent = await this.agentModel.findById(id).exec();
		if (!agent) {
			throw new NotFoundException(`Agent with ID ${id} not found`);
		}
		return agent;
	}

	async findByNormalizedName(normalizedName: string): Promise<Agent> {
		const agent = await this.agentModel.findOne({ normalizedName }).exec();
		if (!agent) {
			throw new NotFoundException(
				`Agent with normalized name ${normalizedName} not found`
			);
		}
		return agent;
	}

	async update(id: string, updateAgentDto: UpdateAgentDto): Promise<Agent> {
		// Check for name conflict if name is being updated
		if (updateAgentDto.normalizedName) {
			const existing = await this.agentModel.findOne({
				normalizedName: updateAgentDto.normalizedName,
				_id: { $ne: id }
			});

			if (existing) {
				throw new ConflictException(
					"Agent with this normalized name already exists"
				);
			}
		}

		const agent = await this.agentModel
			.findByIdAndUpdate(id, updateAgentDto, { new: true })
			.exec();

		if (!agent) {
			throw new NotFoundException(`Agent with ID ${id} not found`);
		}

		return agent;
	}

	async remove(id: string): Promise<Agent> {
		const agent = await this.agentModel.findByIdAndDelete(id).exec();
		if (!agent) {
			throw new NotFoundException(`Agent with ID ${id} not found`);
		}
		return agent;
	}

	// Additional utility methods
	async getReleasedAgents(): Promise<Agent[]> {
		return this.agentModel.find({ isReleased: true }).exec();
	}

	async getLimitedAgents(): Promise<Agent[]> {
		return this.agentModel.find({ isLimited: true }).exec();
	}

	async getAgentsByAttribute(attribute: string): Promise<Agent[]> {
		return this.agentModel.find({ attribute }).exec();
	}

	async getAgentsBySpecialty(specialty: string): Promise<Agent[]> {
		return this.agentModel.find({ specialty }).exec();
	}

	async getAgentsByRarity(rarity: string): Promise<Agent[]> {
		return this.agentModel.find({ rarity }).exec();
	}

	async findByIds(characterIds: number[]): Promise<Agent[]> {
		return this.agentModel.find({ _id: { $in: characterIds } }).exec();
	}
}
