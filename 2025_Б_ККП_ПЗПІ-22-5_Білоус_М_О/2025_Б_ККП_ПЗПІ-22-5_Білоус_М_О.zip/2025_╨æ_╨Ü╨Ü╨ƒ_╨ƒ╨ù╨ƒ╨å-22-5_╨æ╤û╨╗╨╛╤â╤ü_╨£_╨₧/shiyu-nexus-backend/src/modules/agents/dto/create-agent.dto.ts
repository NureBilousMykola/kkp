import {
	IsBoolean,
	IsEnum,
	IsMongoId,
	IsOptional,
	IsString
} from "class-validator";

export class CreateAgentDto {
	@IsString()
	name: string;

	@IsString()
	fullName: string;

	@IsString()
	normalizedName: string;

	@IsBoolean()
	isReleased: boolean;

	@IsBoolean()
	isLimited: boolean;

	@IsEnum(["S", "A"])
	rarity: string;

	@IsEnum(["attack", "anomaly", "defense", "stun", "support"])
	specialty: string;

	@IsEnum(["physical", "fire", "ice", "ether", "electric", "frost"])
	attribute: string;

	@IsMongoId()
	faction: string;

	@IsBoolean()
	@IsOptional()
	hasEngineCostException?: boolean;

	@IsString()
	@IsOptional()
	imageUrl?: string;

	@IsString()
	@IsOptional()
	iconUrl?: string;
}
