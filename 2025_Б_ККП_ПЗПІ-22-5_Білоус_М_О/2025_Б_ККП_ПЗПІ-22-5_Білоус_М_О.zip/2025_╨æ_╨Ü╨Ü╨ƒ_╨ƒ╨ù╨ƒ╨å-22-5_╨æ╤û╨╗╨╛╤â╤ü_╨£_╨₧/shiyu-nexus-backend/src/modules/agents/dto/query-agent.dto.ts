import { IsBoolean, IsEnum, IsOptional, IsString } from "class-validator";

export class QueryAgentDto {
	@IsEnum(["S", "A"])
	@IsOptional()
	rarity?: string;

	@IsEnum(["attack", "anomaly", "defense", "stun", "support"])
	@IsOptional()
	specialty?: string;

	@IsEnum(["physical", "fire", "ice", "ether", "electric", "frost"])
	@IsOptional()
	attribute?: string;

	@IsBoolean()
	@IsOptional()
	isReleased?: boolean;

	@IsBoolean()
	@IsOptional()
	isLimited?: boolean;

	@IsString()
	@IsOptional()
	name?: string;
}
