// src/modules/bangboos/bangboos.controller.ts
import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	Query,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import { UserRole } from "@shared/enums/user-role.enum";
import { ParseMongoIdPipe } from "@shared/pipes/parse-mongo-id.pipe";
import { Roles } from "../users/decorators/roles.decorator";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { RolesGuard } from "../users/guards/roles.guard";
import { BangboosService } from "./bangboos.service";
import { CreateBangbooDto } from "./dto/create-bangboo.dto";
import { QueryBangbooDto } from "./dto/query-bangboo.dto";
import { UpdateBangbooDto } from "./dto/update-bangboo.dto";

@ApiTags("bangboos")
@Controller("bangboos")
export class BangboosController {
	constructor(private readonly bangboosService: BangboosService) {}

	@Post()
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Create a new bangboo" })
	async create(@Body(ValidationPipe) createBangbooDto: CreateBangbooDto) {
		return this.bangboosService.create(createBangbooDto);
	}

	@Get()
	@ApiOperation({ summary: "Get all bangboos with optional filtering" })
	async findAll(@Query(ValidationPipe) query: QueryBangbooDto) {
		return this.bangboosService.findAll(query);
	}

	@Get(":id")
	@ApiOperation({ summary: "Get bangboo by ID" })
	async findOne(@Param("id", ParseMongoIdPipe) id: string) {
		return this.bangboosService.findOne(id);
	}

	@Get("name/:normalizedName")
	@ApiOperation({ summary: "Get bangboo by normalized name" })
	async findByNormalizedName(@Param("normalizedName") normalizedName: string) {
		return this.bangboosService.findByNormalizedName(normalizedName);
	}

	@Patch(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update a bangboo" })
	async update(
		@Param("id", ParseMongoIdPipe) id: string,
		@Body(ValidationPipe) updateBangbooDto: UpdateBangbooDto
	) {
		return this.bangboosService.update(id, updateBangbooDto);
	}

	@Delete(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Delete a bangboo" })
	async remove(@Param("id", ParseMongoIdPipe) id: string) {
		return this.bangboosService.remove(id);
	}

	@Get("filter/rarity/:rarity")
	@ApiOperation({ summary: "Get bangboos by rarity" })
	async getBangboosByRarity(@Param("rarity") rarity: string) {
		return this.bangboosService.getBangboosByRarity(rarity);
	}
}
