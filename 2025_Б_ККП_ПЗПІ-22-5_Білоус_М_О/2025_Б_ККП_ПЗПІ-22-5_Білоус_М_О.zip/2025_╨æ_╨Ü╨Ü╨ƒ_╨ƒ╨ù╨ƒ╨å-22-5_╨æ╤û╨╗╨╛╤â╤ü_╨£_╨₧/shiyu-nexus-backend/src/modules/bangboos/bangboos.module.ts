import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Bangboo, BangbooSchema } from "@schemas/bangboo.schema";
import { BangboosController } from "./bangboos.controller";
import { BangboosService } from "./bangboos.service";

@Module({
	imports: [
		MongooseModule.forFeature([{ name: Bangboo.name, schema: BangbooSchema }])
	],
	controllers: [BangboosController],
	providers: [BangboosService],
	exports: [BangboosService]
})
export class BangboosModule {}
