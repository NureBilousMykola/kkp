import { Bangboo } from "@/schemas/bangboo.schema";
import {
	ConflictException,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { CreateBangbooDto } from "./dto/create-bangboo.dto";
import { QueryBangbooDto } from "./dto/query-bangboo.dto";
import { UpdateBangbooDto } from "./dto/update-bangboo.dto";

@Injectable()
export class BangboosService {
	constructor(
		@InjectModel(Bangboo.name) private bangbooModel: Model<Bangboo>
	) {}

	async create(createBangbooDto: CreateBangbooDto): Promise<Bangboo> {
		const existing = await this.bangbooModel.findOne({
			normalizedName: createBangbooDto.normalizedName
		});

		if (existing) {
			throw new ConflictException(
				"Bangboo with this normalized name already exists"
			);
		}

		const bangboo = new this.bangbooModel(createBangbooDto);
		return bangboo.save();
	}

	async findAll(query: QueryBangbooDto = {}): Promise<Bangboo[]> {
		const filter: any = {};
		if (query.rarity) filter.rarity = query.rarity;
		return this.bangbooModel.find(filter).exec();
	}

	async findOne(id: string): Promise<Bangboo> {
		const bangboo = await this.bangbooModel.findById(id).exec();
		if (!bangboo) {
			throw new NotFoundException(`Bangboo with ID ${id} not found`);
		}
		return bangboo;
	}

	async findByNormalizedName(normalizedName: string): Promise<Bangboo> {
		const bangboo = await this.bangbooModel.findOne({ normalizedName }).exec();
		if (!bangboo) {
			throw new NotFoundException(
				`Bangboo with normalized name ${normalizedName} not found`
			);
		}
		return bangboo;
	}

	async update(
		id: string,
		updateBangbooDto: UpdateBangbooDto
	): Promise<Bangboo> {
		if (updateBangbooDto.normalizedName) {
			const existing = await this.bangbooModel.findOne({
				normalizedName: updateBangbooDto.normalizedName,
				_id: { $ne: id }
			});

			if (existing) {
				throw new ConflictException(
					"Bangboo with this normalized name already exists"
				);
			}
		}

		const bangboo = await this.bangbooModel
			.findByIdAndUpdate(id, updateBangbooDto, { new: true })
			.exec();

		if (!bangboo) {
			throw new NotFoundException(`Bangboo with ID ${id} not found`);
		}

		return bangboo;
	}

	async remove(id: string): Promise<Bangboo> {
		const bangboo = await this.bangbooModel.findByIdAndDelete(id).exec();
		if (!bangboo) {
			throw new NotFoundException(`Bangboo with ID ${id} not found`);
		}
		return bangboo;
	}

	async getBangboosByRarity(rarity: string): Promise<Bangboo[]> {
		return this.bangbooModel.find({ rarity }).exec();
	}
}
