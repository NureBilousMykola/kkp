import { IsEnum, IsOptional, IsString } from "class-validator";

export class CreateBangbooDto {
	@IsString()
	name: string;

	@IsString()
	normalizedName: string;

	@IsEnum(["S", "A"])
	rarity: string;

	@IsString()
	@IsOptional()
	imageUrl?: string;
}
