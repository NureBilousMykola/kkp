import { IsEnum, IsOptional } from "class-validator";

export class QueryBangbooDto {
	@IsEnum(["S", "A"])
	@IsOptional()
	rarity?: string;
}
