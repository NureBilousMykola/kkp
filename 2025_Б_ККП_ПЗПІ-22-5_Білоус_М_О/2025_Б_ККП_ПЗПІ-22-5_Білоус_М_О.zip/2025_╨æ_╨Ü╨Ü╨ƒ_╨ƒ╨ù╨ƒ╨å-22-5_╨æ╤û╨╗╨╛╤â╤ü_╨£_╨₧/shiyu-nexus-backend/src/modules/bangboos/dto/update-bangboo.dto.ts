// src/modules/bangboos/dto/update-bangboo.dto.ts
import { PartialType } from "@nestjs/mapped-types";
import { CreateBangbooDto } from "./create-bangboo.dto";

export class UpdateBangbooDto extends PartialType(CreateBangbooDto) {}
