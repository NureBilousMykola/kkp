import {
	Controller,
	Get,
	Post,
	Body,
	Patch,
	Param,
	Delete,
	Query,
	UseGuards,
	HttpCode,
	HttpStatus
} from "@nestjs/common";
import { CostSystemsService } from "./cost-systems.service";
import { CreateCostSystemDto } from "./dto/create-cost-system.dto";
import { UpdateCostSystemDto } from "./dto/update-cost-system.dto";
import { QueryCostSystemDto } from "./dto/query-cost-system.dto";
import { CloneCostSystemDto } from "./dto/clone-cost-system.dto";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { RolesGuard } from "../users/guards/roles.guard";
import { GetUser } from "../users/decorators/get-user.decorator";
import { Roles } from "../users/decorators/roles.decorator";
import { ParseMongoIdPipe } from "../../shared/pipes/parse-mongo-id.pipe";
import { UserRole } from "../../shared/enums/user-role.enum";

@Controller("cost-systems")
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.ADMIN)
export class CostSystemsController {
	constructor(private readonly costSystemsService: CostSystemsService) {}

	@Post()
	@HttpCode(HttpStatus.CREATED)
	async create(
		@Body() createCostSystemDto: CreateCostSystemDto,
		@GetUser("sub") userId: string
	) {
		return this.costSystemsService.create(createCostSystemDto, userId);
	}

	@Get()
	async findAll(@Query() query: QueryCostSystemDto) {
		return this.costSystemsService.findAll(query);
	}

	@Get("default")
	async getDefault() {
		return this.costSystemsService.getDefault();
	}

	@Get(":id")
	async findOne(@Param("id", ParseMongoIdPipe) id: string) {
		return this.costSystemsService.findOne(id);
	}

	@Patch(":id")
	async update(
		@Param("id", ParseMongoIdPipe) id: string,
		@Body() updateCostSystemDto: UpdateCostSystemDto,
		@GetUser("sub") userId: string
	) {
		return this.costSystemsService.update(id, updateCostSystemDto, userId);
	}

	@Delete(":id")
	@HttpCode(HttpStatus.NO_CONTENT)
	async remove(
		@Param("id", ParseMongoIdPipe) id: string,
		@GetUser("sub") userId: string
	) {
		return this.costSystemsService.remove(id, userId);
	}

	@Post(":id/clone")
	@HttpCode(HttpStatus.CREATED)
	async clone(
		@Param("id", ParseMongoIdPipe) id: string,
		@Body() cloneDto: CloneCostSystemDto,
		@GetUser("sub") userId: string
	) {
		return this.costSystemsService.clone(id, cloneDto.name, userId);
	}

	@Patch(":id/set-default")
	async setDefault(@Param("id", ParseMongoIdPipe) id: string) {
		return this.costSystemsService.setDefault(id);
	}
}
