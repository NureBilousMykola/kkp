import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { CostSystemsController } from "./cost-systems.controller";
import { CostSystemsService } from "./cost-systems.service";
import { CostSystem, CostSystemSchema } from "../../schemas/cost-system.schema";

@Module({
	imports: [
		MongooseModule.forFeature([
			{ name: CostSystem.name, schema: CostSystemSchema }
		])
	],
	controllers: [CostSystemsController],
	providers: [CostSystemsService],
	exports: [CostSystemsService]
})
export class CostSystemsModule {}
