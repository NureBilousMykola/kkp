import {
	Injectable,
	NotFoundException,
	BadRequestException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model, Types } from "mongoose";
import {
	CostSystem,
	CostSystemDocument
} from "../../schemas/cost-system.schema";
import { CreateCostSystemDto } from "./dto/create-cost-system.dto";
import { UpdateCostSystemDto } from "./dto/update-cost-system.dto";
import { QueryCostSystemDto } from "./dto/query-cost-system.dto";

@Injectable()
export class CostSystemsService {
	constructor(
		@InjectModel(CostSystem.name)
		private costSystemModel: Model<CostSystemDocument>
	) {}

	async create(
		createDto: CreateCostSystemDto,
		userId: string
	): Promise<CostSystem> {
		const costSystem = new this.costSystemModel({
			...createDto,
			createdBy: new Types.ObjectId(userId)
		});

		return costSystem.save();
	}

	async findAll(query: QueryCostSystemDto): Promise<CostSystem[]> {
		const filter: any = {};

		if (query.search) {
			filter.$or = [
				{ name: { $regex: query.search, $options: "i" } },
				{ description: { $regex: query.search, $options: "i" } }
			];
		}

		if (query.isDefault !== undefined) {
			filter.isDefault = query.isDefault;
		}

		const costSystems = await this.costSystemModel
			.find(filter)
			.populate("agentCosts.agent", "name rarity")
			.populate("engineCosts.engine", "name rarity")
			.populate("createdBy", "username")
			.sort({ isDefault: -1, createdAt: -1 })
			.limit(query.limit || 50)
			.skip(query.offset || 0)
			.exec();

		return costSystems;
	}

	async findOne(id: string): Promise<CostSystem> {
		if (!Types.ObjectId.isValid(id)) {
			throw new BadRequestException("Invalid cost system ID");
		}

		const costSystem = await this.costSystemModel
			.findById(id)
			.populate("agentCosts.agent", "name rarity")
			.populate("engineCosts.engine", "name rarity")
			.populate("createdBy", "username")
			.exec();

		if (!costSystem) {
			throw new NotFoundException("Cost system not found");
		}

		return costSystem;
	}

	async update(
		id: string,
		updateDto: UpdateCostSystemDto,
		userId: string
	): Promise<CostSystem> {
		if (!Types.ObjectId.isValid(id)) {
			throw new BadRequestException("Invalid cost system ID");
		}

		const costSystem = await this.costSystemModel.findById(id);
		if (!costSystem) {
			throw new NotFoundException("Cost system not found");
		}

		const updated = await this.costSystemModel
			.findByIdAndUpdate(id, updateDto, { new: true })
			.populate("agentCosts.agent", "name rarity")
			.populate("engineCosts.engine", "name rarity")
			.populate("createdBy", "username")
			.exec();

		if (!updated) {
			throw new NotFoundException("Cost system not found after update");
		}

		return updated;
	}

	async remove(id: string, userId: string): Promise<void> {
		if (!Types.ObjectId.isValid(id)) {
			throw new BadRequestException("Invalid cost system ID");
		}

		const costSystem = await this.costSystemModel.findById(id);
		if (!costSystem) {
			throw new NotFoundException("Cost system not found");
		}

		if (costSystem.isDefault) {
			throw new BadRequestException("Cannot delete default cost system");
		}

		await this.costSystemModel.findByIdAndDelete(id);
	}

	async clone(
		id: string,
		newName: string,
		userId: string
	): Promise<CostSystem> {
		const original = await this.findOne(id);

		const cloneData: CreateCostSystemDto = {
			name: newName,
			description: original.description,
			agentCosts: original.agentCosts.map((cost) => ({
				agent: cost.agent.toString(),
				mindscapeCosts: cost.mindscapeCosts
			})),
			engineCosts: original.engineCosts.map((cost) => ({
				engine: cost.engine.toString(),
				ascensionCosts: cost.ascensionCosts
			}))
		};

		return this.create(cloneData, userId);
	}

	async getDefault(): Promise<CostSystem | null> {
		return this.costSystemModel
			.findOne({ isDefault: true })
			.populate("agentCosts.agent", "name rarity")
			.populate("engineCosts.engine", "name rarity")
			.exec();
	}

	async setDefault(id: string): Promise<CostSystem> {
		// Remove default flag from all systems
		await this.costSystemModel.updateMany({}, { isDefault: false });

		// Set the specified system as default
		const updated = await this.costSystemModel
			.findByIdAndUpdate(id, { isDefault: true }, { new: true })
			.populate("agentCosts.agent", "name rarity")
			.populate("engineCosts.engine", "name rarity")
			.populate("createdBy", "username")
			.exec();

		if (!updated) {
			throw new NotFoundException("Cost system not found");
		}

		return updated;
	}
}
