import { IsString, IsNotEmpty } from "class-validator";

export class CloneCostSystemDto {
	@IsString()
	@IsNotEmpty()
	name: string;
}
