import {
	IsString,
	IsOptional,
	IsArray,
	ValidateNested,
	IsNotEmpty,
	IsBoolean
} from "class-validator";
import { Type } from "class-transformer";

export class AgentCostDto {
	@IsString()
	@IsNotEmpty()
	agent: string;

	@IsOptional()
	mindscapeCosts: Map<number, number>;
}

export class EngineCostDto {
	@IsString()
	@IsNotEmpty()
	engine: string;

	@IsOptional()
	ascensionCosts: Map<number, number>;
}

export class CreateCostSystemDto {
	@IsString()
	@IsNotEmpty()
	name: string;

	@IsOptional()
	@IsString()
	description?: string;

	@IsOptional()
	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => AgentCostDto)
	agentCosts?: AgentCostDto[];

	@IsOptional()
	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => EngineCostDto)
	engineCosts?: EngineCostDto[];

	@IsOptional()
	@IsBoolean()
	isDefault?: boolean;
}
