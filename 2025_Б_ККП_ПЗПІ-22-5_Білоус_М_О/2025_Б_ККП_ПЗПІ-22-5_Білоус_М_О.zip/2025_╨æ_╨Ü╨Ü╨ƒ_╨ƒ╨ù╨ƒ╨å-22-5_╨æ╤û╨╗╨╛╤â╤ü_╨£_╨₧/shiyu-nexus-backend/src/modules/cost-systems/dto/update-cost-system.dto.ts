import { PartialType } from "@nestjs/mapped-types";
import { CreateCostSystemDto } from "./create-cost-system.dto";

export class UpdateCostSystemDto extends PartialType(CreateCostSystemDto) {}
