// src/modules/draft/draft.controller.ts
import {
	BadRequestException,
	Body,
	Controller,
	Get,
	Param,
	Post,
	Query,
	Request,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiResponse, ApiTags } from "@nestjs/swagger";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { DraftService } from "./draft.service";
import { AssignEngineDto } from "./dto/assign-engine.dto";
import { AssignRoomDto } from "./dto/assign-room.dto";
import { AvailableEngineDto } from "./dto/available-engine.dto";
import { BanCharacterDto } from "./dto/ban-character.dto";
import { BanStageDto } from "./dto/ban-stage.dto";
import { CreateSessionDto } from "./dto/create-session.dto";
import { SubmitGameResultDto } from "./dto/game-result.dto";
import { JoinSessionDto } from "./dto/join-session.dto";
import { PickCharacterDto } from "./dto/pick-character.dto";
import { PrebanAgentDto } from "./dto/preban-agent.dto";

@ApiTags("draft")
@Controller("draft/sessions")
@UseGuards(JwtAuthGuard)
export class DraftController {
	constructor(private readonly draftService: DraftService) {}

	@Post()
	@ApiOperation({ summary: "Create a new draft session" })
	@ApiResponse({ status: 201, description: "Session created successfully" })
	async createSession(
		@Request() req: any,
		@Body(ValidationPipe) createSessionDto: CreateSessionDto
	) {
		return this.draftService.createSession(req.user.userId, createSessionDto);
	}

	@Post(":id/join")
	@ApiOperation({ summary: "Join an existing draft session" })
	@ApiResponse({ status: 200, description: "Joined session successfully" })
	async joinSession(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) joinSessionDto: JoinSessionDto
	) {
		return this.draftService.joinSession(id, req.user.userId, joinSessionDto);
	}

	@Post(":id/leave")
	@ApiOperation({ summary: "Leave a draft session" })
	@ApiResponse({ status: 200, description: "Left session successfully" })
	async leaveSession(@Request() req: any, @Param("id") id: string) {
		return this.draftService.leaveSession(id, req.user.userId);
	}

	@Get()
	@ApiOperation({ summary: "Get all active draft sessions" })
	async getAllSessions() {
		return this.draftService.getAllSessions();
	}

	@Get("agent-saves")
	@ApiOperation({ summary: "Get agent saves for the current user" })
	@ApiResponse({ status: 200, description: "Returns agent saves for the user" })
	async getAgentSaves(@Request() req: any) {
		return this.draftService.getAgentSavesForUser(req.user.userId);
	}

	@Get(":id")
	@ApiOperation({ summary: "Get draft session by ID" })
	@ApiResponse({ status: 200, description: "Returns the draft session" })
	async getSession(@Param("id") id: string) {
		return this.draftService.getSession(id);
	}

	@Post(":id/ready")
	@ApiOperation({ summary: "Set player ready status" })
	async setReady(@Request() req: any, @Param("id") id: string) {
		return this.draftService.setPlayerReady(id, req.user.userId);
	}

	@Post(":id/pick")
	@ApiOperation({ summary: "Pick a character" })
	async pickCharacter(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) pickDto: PickCharacterDto
	) {
		return this.draftService.pickCharacter(id, req.user.userId, pickDto);
	}

	@Post(":id/ban")
	@ApiOperation({ summary: "Ban a character" })
	async banCharacter(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) banDto: BanCharacterDto
	) {
		return this.draftService.banCharacter(id, req.user.userId, banDto);
	}

	@Post(":id/assign-room")
	@ApiOperation({ summary: "Assign characters to a room" })
	async assignRoom(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) assignRoomDto: AssignRoomDto
	) {
		if (assignRoomDto.roomId < 1 || assignRoomDto.roomId > 2) {
			throw new BadRequestException("Invalid room ID. Must be 1 or 2");
		}
		return this.draftService.assignRoom(id, req.user.userId, assignRoomDto);
	}

	@Get(":id/available-characters")
	@ApiOperation({ summary: "Get available characters for the session" })
	async getAvailableCharacters(@Param("id") id: string) {
		return this.draftService.getAvailableCharacters(id);
	}

	@Get(":id/available-engines")
	@ApiOperation({ summary: "Get available engines for the session with costs" })
	@ApiResponse({
		status: 200,
		description: "Returns available engines with their costs",
		type: [AvailableEngineDto]
	})
	async getAvailableEngines(
		@Param("id") id: string,
		@Query("characterId") characterId: string
	) {
		return this.draftService.getAvailableEngines(id, characterId);
	}

	@Post(":id/spectate")
	@ApiOperation({ summary: "Join session as spectator" })
	async spectateSession(@Request() req: any, @Param("id") id: string) {
		return this.draftService.addSpectator(id, req.user.userId);
	}

	@Post(":id/stop-spectating")
	@ApiOperation({ summary: "Stop spectating session" })
	async stopSpectating(@Request() req: any, @Param("id") id: string) {
		return this.draftService.removeSpectator(id, req.user.userId);
	}

	@Post(":id/ban-stage")
	@ApiOperation({ summary: "Ban a stage for the draft" })
	async banStage(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) banStageDto: BanStageDto
	) {
		return this.draftService.banStage(id, req.user.userId, banStageDto);
	}

	@Post(":id/preban")
	@ApiOperation({ summary: "Preban an agent for the entire match" })
	async prebanAgent(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) prebanAgentDto: PrebanAgentDto
	) {
		return this.draftService.prebanAgent(id, req.user.userId, prebanAgentDto);
	}

	@Post(":id/assign-engine")
	@ApiOperation({ summary: "Assign an engine to a character" })
	async assignEngine(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) assignEngineDto: AssignEngineDto
	) {
		return this.draftService.assignEngine(id, req.user.userId, assignEngineDto);
	}

	@Post(":id/submit-result")
	@ApiOperation({ summary: "Submit the result of a game" })
	async submitGameResult(
		@Request() req: any,
		@Param("id") id: string,
		@Body(ValidationPipe) submitGameResultDto: SubmitGameResultDto
	) {
		return this.draftService.submitGameResult(
			id,
			req.user.userId,
			submitGameResultDto
		);
	}

	@Post(":id/ready-for-next-game")
	@ApiOperation({ summary: "Mark player as ready for the next game" })
	async readyForNextGame(@Request() req: any, @Param("id") id: string) {
		return this.draftService.setReadyForNextGame(id, req.user.userId);
	}

	@Get(":id/game-results")
	@ApiOperation({ summary: "Get all game results for a draft session" })
	async getGameResults(@Param("id") id: string) {
		return this.draftService.getGameResults(id);
	}

	@Get(":id/available-stages")
	@ApiOperation({ summary: "Get available stages for the session" })
	async getAvailableStages(@Param("id") id: string) {
		return this.draftService.getAvailableStages(id);
	}
}
