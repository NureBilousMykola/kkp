import { forwardRef, Inject, UseGuards } from "@nestjs/common";
import {
	ConnectedSocket,
	MessageBody,
	OnGatewayConnection,
	OnGatewayDisconnect,
	SubscribeMessage,
	WebSocketGateway,
	WebSocketServer
} from "@nestjs/websockets";
import { Redis } from "ioredis";
import { Server, Socket } from "socket.io";
import { WsJwtAuthGuard } from "../users/guards/ws-jwt-auth.guard";
import { DraftService } from "./draft.service";
import { InjectRedis } from "@nestjs-modules/ioredis";

@WebSocketGateway({
	namespace: "draft",
	cors: {
		origin: process.env.FRONTEND_URL || "http://localhost:3000",
		credentials: true
	}
})
@UseGuards(WsJwtAuthGuard)
export class DraftGateway implements OnGatewayConnection, OnGatewayDisconnect {
	@WebSocketServer()
	server: Server;

	constructor(
		@Inject(forwardRef(() => DraftService))
		private readonly draftService: DraftService,
		@InjectRedis() private readonly redis: Redis
	) {}

	async handleConnection(@ConnectedSocket() client: Socket) {
		console.log("WebSocket connection attempt:", {
			socketId: client.id,
			hasData: !!client.data,
			hasUser: !!client.data?.user,
			userData: client.data?.user
		});

		if (!client.data?.user?.userId && !client.data?.user?.id) {
			console.error("WebSocket connection failed: No user data found");
			client.disconnect();
			return;
		}

		const userId = client.data.user.userId || client.data.user.id;
		await this.redis.hset("socket_users", client.id, userId);
		console.log("WebSocket connection successful for user:", userId);
	}

	async handleDisconnect(@ConnectedSocket() client: Socket) {
		await this.redis.hdel("socket_users", client.id);
		const sessionId = await this.redis.hget(
			"user_sessions",
			client.data.user.userId || client.data.user.id
		);
		if (sessionId) {
			await this.handleLeaveSession(client, { sessionId });
		}
	}

	@SubscribeMessage("joinSession")
	async handleJoinSession(
		@ConnectedSocket() client: Socket,
		@MessageBody() data: { sessionId: string }
	) {
		const userId = client.data.user.userId || client.data.user.id;
		const sessionChannel = `session:${data.sessionId}`;

		await this.redis.hset("user_sessions", userId, data.sessionId);
		await this.redis.sadd(`session_users:${data.sessionId}`, userId);

		client.join(sessionChannel);

		const session = await this.draftService.getSession(data.sessionId);
		this.server.to(sessionChannel).emit("sessionUpdate", session);

		// Subscribe to Redis channel for session updates
		const subscriber = this.redis.duplicate();
		await subscriber.subscribe(sessionChannel);

		subscriber.on("message", (channel, message) => {
			if (channel === sessionChannel) {
				this.server
					.to(sessionChannel)
					.emit("sessionUpdate", JSON.parse(message));
			}
		});
	}

	@SubscribeMessage("leaveSession")
	async handleLeaveSession(
		@ConnectedSocket() client: Socket,
		@MessageBody() data: { sessionId: string }
	) {
		const userId = client.data.user.userId || client.data.user.id;
		const sessionChannel = `session:${data.sessionId}`;

		await this.redis.hdel("user_sessions", userId);
		await this.redis.srem(`session_users:${data.sessionId}`, userId);

		client.leave(sessionChannel);
	}

	async publishSessionUpdate(sessionId: string, sessionData: any) {
		const sessionChannel = `session:${sessionId}`;
		await this.redis.publish(sessionChannel, JSON.stringify(sessionData));
	}
}
