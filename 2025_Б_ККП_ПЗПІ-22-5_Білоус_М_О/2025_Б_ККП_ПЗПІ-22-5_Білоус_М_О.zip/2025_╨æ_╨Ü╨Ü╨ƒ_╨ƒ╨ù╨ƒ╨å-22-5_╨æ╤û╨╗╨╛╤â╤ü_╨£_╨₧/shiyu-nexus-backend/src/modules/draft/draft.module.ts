import { RedisModule, type RedisModuleOptions } from "@nestjs-modules/ioredis";
import { Module } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { JwtService } from "@nestjs/jwt";
import { MongooseModule } from "@nestjs/mongoose";
import { Agent, AgentSchema } from "@schemas/agent.schema";
import { DraftPreset, DraftPresetSchema } from "@schemas/draft-preset.schema";
import {
	DraftSession,
	DraftSessionSchema
} from "@schemas/draft-session.schema";
import { Engine, EngineSchema } from "@schemas/engine.schema";
import { User, UserSchema } from "@schemas/user.schema";
import { UsersModule } from "../users/users.module";
import { DraftController } from "./draft.controller";
import { DraftGateway } from "./draft.gateway";
import { DraftService } from "./draft.service";

@Module({
	imports: [
		MongooseModule.forFeature([
			{ name: DraftPreset.name, schema: DraftPresetSchema },
			{ name: DraftSession.name, schema: DraftSessionSchema },
			{ name: Agent.name, schema: AgentSchema },
			{ name: Engine.name, schema: EngineSchema },
			{ name: User.name, schema: UserSchema }
		]),
		RedisModule.forRootAsync({
			imports: [ConfigModule],
			useFactory: (configService: ConfigService): RedisModuleOptions => ({
				type: "single",
				url: configService.get<string>("REDIS_URL")
			}),
			inject: [ConfigService]
		}),
		UsersModule
	],
	controllers: [DraftController],
	providers: [DraftService, DraftGateway, JwtService],
	exports: [DraftService]
})
export class DraftModule {}
