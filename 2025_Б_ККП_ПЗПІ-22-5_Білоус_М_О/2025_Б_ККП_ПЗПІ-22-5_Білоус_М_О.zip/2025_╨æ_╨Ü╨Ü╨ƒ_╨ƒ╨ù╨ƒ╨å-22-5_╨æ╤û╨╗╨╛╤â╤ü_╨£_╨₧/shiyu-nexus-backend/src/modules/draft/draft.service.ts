import { InjectRedis } from "@nestjs-modules/ioredis";
//src/modules/draft/draft.service.ts
import {
	BadRequestException,
	ConflictException,
	forwardRef,
	Inject,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Agent } from "@schemas/agent.schema";
import { DraftPreset } from "@schemas/draft-preset.schema";
import {
	DraftPhaseType,
	DraftSession,
	SessionStatus
} from "@schemas/draft-session.schema";
import { Engine } from "@schemas/engine.schema";
import { User } from "@schemas/user.schema";
import { Redis } from "ioredis";
import { Model, Types } from "mongoose";
import { DraftGateway } from "./draft.gateway";
import { AssignEngineDto } from "./dto/assign-engine.dto";
import { AssignRoomDto } from "./dto/assign-room.dto";
import { BanCharacterDto } from "./dto/ban-character.dto";
import { BanStageDto } from "./dto/ban-stage.dto";
import { CreateSessionDto } from "./dto/create-session.dto";
import { SubmitGameResultDto } from "./dto/game-result.dto";
import { JoinSessionDto } from "./dto/join-session.dto";
import { PickCharacterDto } from "./dto/pick-character.dto";
import { PrebanAgentDto } from "./dto/preban-agent.dto";
import {
	CostReason,
	EngineWithCost
} from "./interfaces/engine-with-cost.interface";

@Injectable()
export class DraftService {
	private readonly SESSION_STATE_PREFIX = "session_state:";
	private readonly SESSION_TIMER_PREFIX = "session_timer:";
	private readonly TTL = 3600; // 1 hour

	constructor(
		@InjectModel(DraftSession.name) private sessionModel: Model<DraftSession>,
		@InjectModel(DraftPreset.name) private presetModel: Model<DraftPreset>,
		@InjectModel(Agent.name) private agentModel: Model<Agent>,
		@InjectModel(Engine.name) private engineModel: Model<Engine>,
		@InjectModel(User.name) private userModel: Model<User>,
		@InjectRedis() private readonly redis: Redis,
		@Inject(forwardRef(() => DraftGateway))
		private readonly draftGateway: DraftGateway
	) {}

	async createSession(
		userId: string,
		dto: CreateSessionDto
	): Promise<DraftSession> {
		const preset = await this.presetModel.findById(dto.presetId);
		if (!preset) {
			throw new NotFoundException("Preset not found");
		}

		// Create the session
		const session = new this.sessionModel({
			...dto,
			hostId: userId,
			status: SessionStatus.WAITING,
			currentPhase: 0,
			currentTeam: preset.draftFlow[0]?.player || 1,
			timeLeft: preset.draftFlow[0]?.timeLimit || 30,
			players: [],
			numberOfGames: dto.numberOfGames || 1,
			currentGameNumber: 1,
			availableStages: [...preset.rules.allowedStages], // Copy allowed stages
			gameResults: [],
			prebansCalculated: false,
			engineAssignmentComplete: false,
			readyForNextGame: false,
			currentPhaseType: DraftPhaseType.STAGE_BAN
		});

		await session.save();
		await this.cacheSessionState(session);

		// If an agent save ID was provided, add the host to the session with that agent save
		if (dto.agentSaveId) {
			await this.joinSessionWithAgentSave(session._id.toString(), userId, {
				team: 1, // Host is always team 1
				password: dto.password,
				agentSaveId: dto.agentSaveId
			});
		}

		return session;
	}

	async joinSession(
		sessionId: string,
		userId: string,
		dto: JoinSessionDto
	): Promise<DraftSession> {
		// If an agent save ID was provided, use the joinSessionWithAgentSave method
		if (dto.agentSaveId) {
			return this.joinSessionWithAgentSave(sessionId, userId, dto);
		}

		const session = await this.getSession(sessionId);

		if (session.status !== SessionStatus.WAITING) {
			throw new BadRequestException("Session is not accepting new players");
		}

		if (session.password && session.password !== dto.password) {
			throw new BadRequestException("Invalid password");
		}

		if (
			session.players.some((p) => p.userId && p.userId.toString() === userId)
		) {
			throw new ConflictException("Already in session");
		}

		if (session.players.filter((p) => p.team === dto.team).length >= 1) {
			throw new BadRequestException("Team is full");
		}

		session.players.push({
			userId: new Types.ObjectId(userId) as any,
			team: dto.team,
			isReady: false,
			selectedCharacters: [],
			selectedEngines: [],
			roomAssignments: new Map(),
			banList: [],
			bannedStages: [],
			prebannedAgents: [],
			engineAssignments: new Map(),
			totalAgentCost: 0
		});

		await this.updateSession(session);
		return session;
	}

	async joinSessionWithAgentSave(
		sessionId: string,
		userId: string,
		dto: JoinSessionDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		if (session.status !== SessionStatus.WAITING) {
			throw new BadRequestException("Session is not accepting new players");
		}

		if (session.password && session.password !== dto.password) {
			throw new BadRequestException("Invalid password");
		}

		if (
			session.players.some((p) => p.userId && p.userId.toString() === userId)
		) {
			throw new ConflictException("Already in session");
		}

		if (session.players.filter((p) => p.team === dto.team).length >= 1) {
			throw new BadRequestException("Team is full");
		}

		// Get the user's agent save
		const user = await this.userModel.findById(userId).populate({
			path: "agentSaves",
			match: { _id: dto.agentSaveId }
		});

		if (!user) {
			throw new NotFoundException("User not found");
		}

		const agentSave = user.agentSaves.find(
			(save) => save._id.toString() === dto.agentSaveId
		);

		if (!agentSave) {
			throw new NotFoundException("Agent save not found");
		}

		// We'll calculate the actual agent cost when prebans are calculated
		// For now, just set it to 0 as a placeholder
		const totalAgentCost = 0;

		// Add player to session with agent save
		session.players.push({
			userId: new Types.ObjectId(userId) as any,
			team: dto.team,
			isReady: false,
			selectedCharacters: [],
			selectedEngines: [],
			roomAssignments: new Map(),
			banList: [],
			bannedStages: [],
			prebannedAgents: [],
			engineAssignments: new Map(),
			totalAgentCost,
			agentSaveId: new Types.ObjectId(dto.agentSaveId) as any,
			agentSaveAgents: agentSave.agents.map(
				(id) => new Types.ObjectId(id.toString()) as any
			)
		});

		await this.updateSession(session);
		return session;
	}

	async leaveSession(sessionId: string, userId: string): Promise<void> {
		const session = await this.getSession(sessionId);

		session.players = session.players.filter(
			(p) => p.userId && p.userId.toString() !== userId
		);

		if (session.players.length === 0) {
			await this.cleanupSession(sessionId);
		} else {
			await this.updateSession(session);
		}
	}

	async pickCharacter(
		sessionId: string,
		userId: string,
		dto: PickCharacterDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);
		const player = this.validatePlayerTurn(session, userId);

		// Validate character selection
		const character = await this.agentModel.findById(dto.characterId);
		if (!character) {
			throw new NotFoundException("Character not found");
		}

		// Validate engine if provided
		if (dto.engineId) {
			const engine = await this.engineModel
				.findById(dto.engineId)
				.populate("signatureAgent")
				.exec();

			if (!engine) {
				throw new NotFoundException("Engine not found");
			}

			// Verify the engine is valid for this character
			const availableEngines = await this.getAvailableEngines(
				sessionId,
				dto.characterId
			);

			const engineIsAvailable = availableEngines.some(
				(e) => e.engine._id.toString() === dto.engineId
			);

			if (!engineIsAvailable) {
				throw new BadRequestException(
					"Engine is not available for this character"
				);
			}

			player.selectedEngines.push(dto.engineId);
		}

		player.selectedCharacters.push(dto.characterId);
		await this.advancePhase(session);
		return session;
	}

	async banCharacter(
		sessionId: string,
		userId: string,
		dto: BanCharacterDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);
		const player = this.validatePlayerTurn(session, userId);

		const character = await this.agentModel.findById(dto.characterId);
		if (!character) {
			throw new NotFoundException("Character not found");
		}

		player.banList.push(dto.characterId);
		await this.advancePhase(session);
		return session;
	}

	async assignRoom(
		sessionId: string,
		userId: string,
		dto: AssignRoomDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);
		const player = this.validatePlayerTurn(session, userId);

		// Validate all characters exist and are selected by the player
		const characters = await this.agentModel.find({
			_id: { $in: dto.characterIds }
		});

		if (characters.length !== dto.characterIds.length) {
			throw new BadRequestException("Invalid character selection");
		}

		if (
			!player.selectedCharacters.some((id: any) =>
				dto.characterIds.includes(id.toString())
			)
		) {
			throw new BadRequestException("Can only assign selected characters");
		}

		player.roomAssignments.set(dto.roomId, dto.characterIds);
		await this.advancePhase(session);
		return session;
	}

	async setPlayerReady(
		sessionId: string,
		userId: string
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);
		const player = session.players.find(
			(p) => p.userId && p.userId.toString() === userId.toString()
		);

		if (!player) {
			throw new BadRequestException("Not a player in this session");
		}

		player.isReady = true;

		if (
			session.status === SessionStatus.WAITING &&
			session.players.every((p) => p.isReady)
		) {
			// Start the stage banning phase
			session.status = SessionStatus.STAGE_BANNING;
			session.startTime = new Date();
			session.currentPhaseType = DraftPhaseType.STAGE_BAN;

			// Set the first player to ban a stage
			session.currentTeam = 1; // Start with player 1

			await this.updateSession(session);
		} else {
			await this.updateSession(session);
		}

		return session;
	}

	async getSession(id: string): Promise<DraftSession> {
		// Always fetch from database to ensure we have a proper Mongoose document
		// that has the save() method and other Mongoose functionality
		const session = await this.sessionModel
			.findById(id)
			.populate("players.userId", "username")
			.populate("presetId")
			.exec();

		if (!session) {
			throw new NotFoundException("Session not found");
		}

		await this.cacheSessionState(session);
		return session;
	}

	async getAllSessions(): Promise<DraftSession[]> {
		return this.sessionModel
			.find()
			.populate("hostId", "username")
			.populate("presetId", "name")
			.exec();
	}

	private async cacheSessionState(session: DraftSession): Promise<void> {
		await this.redis.setex(
			this.SESSION_STATE_PREFIX + session._id,
			this.TTL,
			JSON.stringify(session)
		);
	}

	private async updateSession(session: DraftSession): Promise<void> {
		await session.save();
		await this.cacheSessionState(session);
		await this.draftGateway.publishSessionUpdate(
			session._id.toString(),
			session
		);
	}

	private async cleanupSession(sessionId: string): Promise<void> {
		await Promise.all([
			this.sessionModel.findByIdAndDelete(sessionId),
			this.redis.del(this.SESSION_STATE_PREFIX + sessionId),
			this.redis.del(this.SESSION_TIMER_PREFIX + sessionId)
		]);
	}

	private validatePlayerTurn(session: DraftSession, userId: string): any {
		const player = session.players.find(
			(p) => p.userId && p.userId.toString() === userId
		);

		if (!player) {
			throw new BadRequestException("Not a player in this session");
		}

		if (player.team !== session.currentTeam) {
			throw new BadRequestException("Not your turn");
		}

		return player;
	}

	private async advancePhase(session: DraftSession): Promise<void> {
		const preset = await session.populate("presetId");
		session.currentPhase++;

		if (session.currentPhase >= preset.presetId.draftFlow.length) {
			// Draft phase is complete, move to room and engine assignment
			session.status = SessionStatus.FINISHED;
			session.currentPhaseType = DraftPhaseType.ROOM_ASSIGNMENT;
			await this.updateSession(session);
			return;
		}

		const currentPhase = preset.presetId.draftFlow[session.currentPhase];
		session.currentTeam = currentPhase.player;
		session.timeLeft = currentPhase.timeLimit;

		// Update the current phase type based on the draft flow
		switch (currentPhase.type) {
			case "BAN":
				session.currentPhaseType = DraftPhaseType.BAN;
				break;
			case "PICK":
				session.currentPhaseType = DraftPhaseType.PICK;
				break;
			case "PREBANS":
				session.currentPhaseType = DraftPhaseType.PREBAN;
				break;
			default:
				session.currentPhaseType = DraftPhaseType.BAN;
		}

		await this.updateSession(session);
		await this.startPhaseTimer(session);
	}

	private async startPhaseTimer(session: DraftSession): Promise<void> {
		const timerKey = this.SESSION_TIMER_PREFIX + session._id;
		await this.redis.setex(timerKey, session.timeLeft, "running");

		// Set up Redis key expiration event
		const subscriber = this.redis.duplicate();
		await subscriber.config("SET", "notify-keyspace-events", "Ex");
		await subscriber.subscribe("__keyevent@0__:expired");

		subscriber.on("message", async (_, expiredKey) => {
			if (expiredKey === timerKey) {
				await this.handlePhaseTimeout(session._id.toString());
				subscriber.unsubscribe();
			}
		});
	}

	private async handlePhaseTimeout(sessionId: string): Promise<void> {
		const session = await this.getSession(sessionId);

		if (session.status === SessionStatus.IN_PROGRESS) {
			// Auto-select or auto-ban logic could be implemented here
			await this.advancePhase(session);
		}
	}
	async getAvailableCharacters(sessionId: string): Promise<Agent[]> {
		const session = await this.getSession(sessionId);
		const preset = await this.presetModel.findById(session.presetId);

		if (!preset) {
			throw new NotFoundException("Preset not found");
		}

		const query: any = { isReleased: true };

		// Filter by pickable agents if specified in preset
		if (preset.pickableAgents && preset.pickableAgents.length > 0) {
			query._id = { $in: preset.pickableAgents };
		}

		// Exclude banned and prebanned characters
		const bannedCharacters = session.players.flatMap((p) => [
			...p.banList,
			...p.prebannedAgents
		]);

		if (bannedCharacters.length > 0) {
			if (!query._id) {
				query._id = {};
			}
			query._id.$nin = bannedCharacters;
		}

		// Get stage constraints if applicable
		// Get current stage based on room assignments or session settings
		const currentStage = session.currentStage || preset.rules.allowedStages[0];
		if (currentStage) {
			const constraints = preset.constraints.find(
				(c) => c.stageId === currentStage
			)?.roomConstraints;

			if (constraints) {
				query.$and = [
					{ _id: { $nin: constraints.flatMap((c) => c.bannedAgents) } },
					{
						specialty: {
							$nin: constraints.flatMap((c) => c.bannedSpecialties || [])
						}
					},
					{
						attribute: {
							$nin: constraints.flatMap((c) => c.bannedAttributes || [])
						}
					}
				];
			}
		}

		return this.agentModel.find(query).exec();
	}

	async getAvailableEngines(
		sessionId: string,
		characterId: string
	): Promise<EngineWithCost[]> {
		const session = await this.getSession(sessionId);
		const preset = await this.presetModel.findById(session.presetId);
		const character = await this.agentModel.findById(characterId);

		if (!character) {
			throw new NotFoundException("Character not found");
		}

		if (!preset) {
			throw new NotFoundException("Preset not found");
		}

		// Get engines that match character's specialty or are their signature engine
		const query = {
			$or: [
				{ specialty: character.specialty },
				{ signatureAgent: character._id }
			],
			isReleased: true
		};

		const engines = await this.engineModel
			.find(query)
			.populate("signatureAgent")
			.exec();

		// Calculate costs for each engine based on the relationship with the agent
		const enginesWithCost: EngineWithCost[] = [];

		for (const engine of engines) {
			const cost = await this.calculateEngineCost(character, engine, preset);
			enginesWithCost.push(cost);
		}

		return enginesWithCost;
	}

	/**
	 * Calculate the cost of an engine for a specific agent based on their relationship
	 * @param agent The agent that will use the engine
	 * @param engine The engine to calculate cost for
	 * @param preset The draft preset containing cost information
	 * @returns The engine with its calculated cost and reason
	 */
	private async calculateEngineCost(
		agent: Agent,
		engine: Engine,
		preset: DraftPreset
	): Promise<EngineWithCost> {
		// Find the base engine cost from the preset
		const engineCostConfig = preset.engineCosts.find(
			(ec) => ec.engine.toString() === engine._id.toString()
		);

		if (!engineCostConfig) {
			// If no cost configuration is found, default to 0
			return {
				engine,
				cost: 0,
				costReason: CostReason.DIFFERENT_SPECIALTY
			};
		}

		// Default ascension level (can be made configurable if needed)
		const ascensionLevel = 1;
		const baseCost = engineCostConfig.ascensionCosts.get(ascensionLevel) || 0;

		// Case 1: Engine is chosen by its signature agent
		if (
			engine.signatureAgent &&
			engine.signatureAgent._id.toString() === agent._id.toString()
		) {
			return {
				engine,
				cost: baseCost,
				costReason: CostReason.SIGNATURE_AGENT
			};
		}

		// Case 2: Engine is chosen by an agent with the same specialty
		if (engine.specialty === agent.specialty) {
			// Cost is equal or slightly different from signature agent cost
			// For now, we'll use the same cost, but this could be adjusted
			return {
				engine,
				cost: baseCost,
				costReason: CostReason.SAME_SPECIALTY
			};
		}

		// Case 3: Agent has an exception for engine costs
		if (agent.hasEngineCostException) {
			return {
				engine,
				cost: baseCost,
				costReason: CostReason.EXCEPTION
			};
		}

		// Case 4: Engine is chosen by an agent with a different specialty
		// Cost will be 0
		return {
			engine,
			cost: 0,
			costReason: CostReason.DIFFERENT_SPECIALTY
		};
	}

	async addSpectator(sessionId: string, userId: string): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		if (!session.allowSpectators) {
			throw new BadRequestException(
				"Spectators are not allowed in this session"
			);
		}

		if (
			session.players.some((p) => p.userId && p.userId.toString() === userId)
		) {
			throw new BadRequestException("Players cannot be spectators");
		}

		if (!session.spectators.includes(userId)) {
			session.spectators.push(new Types.ObjectId(userId) as any);
			await this.updateSession(session);
		}

		return session;
	}

	async banStage(
		sessionId: string,
		userId: string,
		dto: BanStageDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		if (
			session.status !== SessionStatus.STAGE_BANNING &&
			session.status !== SessionStatus.WAITING
		) {
			throw new BadRequestException("Stage banning phase has ended");
		}

		const player = this.validatePlayerTurn(session, userId);

		// Check if the stage is available to ban
		if (!session.availableStages.includes(dto.stageId)) {
			throw new BadRequestException("Stage is not available to ban");
		}

		// Add stage to player's banned stages
		player.bannedStages.push(dto.stageId);

		// Remove stage from available stages
		session.availableStages = session.availableStages.filter(
			(stageId) => stageId !== dto.stageId
		);

		// If both players have banned stages or only one stage is left, move to preban phase
		const allPlayersBannedStages = session.players.every(
			(p) => p.bannedStages.length > 0
		);

		if (allPlayersBannedStages || session.availableStages.length === 1) {
			// If only one stage is left, set it as the current stage
			if (session.availableStages.length === 1) {
				session.currentStage = session.availableStages[0];
			}

			// Calculate agent costs for preban phase
			await this.calculateAgentCostsForPreban(session);

			// If the session is still in STAGE_BANNING status, it means the cost difference
			// is above the threshold and we should move to preban phase
			if (session.status === SessionStatus.STAGE_BANNING) {
				session.status = SessionStatus.PREBANNING;
				session.currentPhaseType = DraftPhaseType.PREBAN;
			}

			// Note: The calculateAgentCostsForPreban method now handles setting the current team
			// and may transition directly to the draft phase if the cost difference is below threshold
		} else {
			// Switch to the other player for their ban
			session.currentTeam = player.team === 1 ? 2 : 1;
		}

		await this.updateSession(session);
		return session;
	}

	async prebanAgent(
		sessionId: string,
		userId: string,
		dto: PrebanAgentDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		if (session.status !== SessionStatus.PREBANNING) {
			throw new BadRequestException("Not in preban phase");
		}

		const player = this.validatePlayerTurn(session, userId);

		// Check if the agent exists
		const agent = await this.agentModel.findById(dto.characterId);
		if (!agent) {
			throw new NotFoundException("Agent not found");
		}

		// Add agent to player's prebanned agents
		player.prebannedAgents.push(dto.characterId);

		// Move to draft phase
		session.status = SessionStatus.IN_PROGRESS;
		session.currentPhaseType = DraftPhaseType.BAN;

		// Reset to the first phase of the draft flow
		session.currentPhase = 0;
		const preset = await this.presetModel.findById(session.presetId);
		if (preset) {
			// Check if there are any more prebans needed based on the preset rules
			const player1 = session.players.find((p) => p.team === 1);
			const player2 = session.players.find((p) => p.team === 2);

			if (player1 && player2) {
				const costDifference = Math.abs(
					player1.totalAgentCost - player2.totalAgentCost
				);
				const prebanThreshold = preset.rules.costDifferenceForPreban;

				// If the cost difference is still above the threshold after this preban,
				// let the other player preban as well
				if (
					costDifference >= prebanThreshold &&
					player1.prebannedAgents.length + player2.prebannedAgents.length < 2
				) {
					// Switch to the other player for their preban
					session.currentTeam = player.team === 1 ? 2 : 1;
					session.status = SessionStatus.PREBANNING;
					session.currentPhaseType = DraftPhaseType.PREBAN;

					// Update the session and return
					await this.updateSession(session);
					return session; // Skip setting up the draft phase
				}
			}

			// If no more prebans are needed, set up the draft phase
			session.currentTeam = preset.draftFlow[0]?.player || 1;
			session.timeLeft = preset.draftFlow[0]?.timeLimit || 30;
		}

		await this.updateSession(session);
		await this.startPhaseTimer(session);
		return session;
	}

	async assignEngine(
		sessionId: string,
		userId: string,
		dto: AssignEngineDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		if (session.status !== SessionStatus.FINISHED) {
			throw new BadRequestException(
				"Draft must be finished before assigning engines"
			);
		}

		const player = session.players.find(
			(p) => p.userId && p.userId.toString() === userId.toString()
		);

		if (!player) {
			throw new BadRequestException("Not a player in this session");
		}

		// Check if the character is selected by the player
		if (!player.selectedCharacters.includes(dto.characterId)) {
			throw new BadRequestException("Character not selected by this player");
		}

		// Check if the engine is available for this character
		const availableEngines = await this.getAvailableEngines(
			sessionId,
			dto.characterId
		);

		const engineIsAvailable = availableEngines.some(
			(e) => e.engine._id.toString() === dto.engineId
		);

		if (!engineIsAvailable) {
			throw new BadRequestException(
				"Engine is not available for this character"
			);
		}

		// Assign the engine to the character
		player.engineAssignments.set(dto.characterId, dto.engineId);

		// Check if all characters have engines assigned
		const allCharactersHaveEngines = player.selectedCharacters.every(
			(characterId) => player.engineAssignments.has(characterId.toString())
		);

		if (allCharactersHaveEngines) {
			player.isReady = true;

			// Check if all players are ready
			const allPlayersReady = session.players.every((p) => p.isReady);

			if (allPlayersReady) {
				session.engineAssignmentComplete = true;
				session.currentPhaseType = DraftPhaseType.READY_CHECK;
			}
		}

		await this.updateSession(session);
		return session;
	}

	async submitGameResult(
		sessionId: string,
		userId: string,
		dto: SubmitGameResultDto
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		// Only host or judge can submit results
		if (
			session.hostId.toString() !== userId &&
			(!session.judgeId || session.judgeId.toString() !== userId)
		) {
			throw new BadRequestException(
				"Only host or judge can submit game results"
			);
		}

		// Validate game number
		if (dto.gameNumber > session.numberOfGames) {
			throw new BadRequestException("Invalid game number");
		}

		// Check if result for this game already exists
		const existingResultIndex = session.gameResults.findIndex(
			(result) => result.gameNumber === dto.gameNumber
		);

		if (existingResultIndex >= 0) {
			// Update existing result
			session.gameResults[existingResultIndex] = {
				gameNumber: dto.gameNumber,
				stageId: dto.stageId,
				winner: dto.winner,
				timeElapsed: dto.timeElapsed,
				freeRestartsUsed: dto.freeRestartsUsed,
				paidRestartsUsed: dto.paidRestartsUsed,
				notes: dto.notes
			};
		} else {
			// Add new result
			session.gameResults.push({
				gameNumber: dto.gameNumber,
				stageId: dto.stageId,
				winner: dto.winner,
				timeElapsed: dto.timeElapsed,
				freeRestartsUsed: dto.freeRestartsUsed,
				paidRestartsUsed: dto.paidRestartsUsed,
				notes: dto.notes
			});
		}

		// Check if all games have results
		if (session.gameResults.length === session.numberOfGames) {
			session.status = SessionStatus.FINISHED;
			session.endTime = new Date();
		} else {
			// Prepare for next game
			session.currentGameNumber = dto.gameNumber + 1;
			session.readyForNextGame = false;

			// Reset player ready status
			for (const player of session.players) {
				player.isReady = false;
			}

			session.currentPhaseType = DraftPhaseType.READY_CHECK;
		}

		await this.updateSession(session);
		return session;
	}

	async setReadyForNextGame(
		sessionId: string,
		userId: string
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		const player = session.players.find(
			(p) => p.userId && p.userId.toString() === userId.toString()
		);

		if (!player) {
			throw new BadRequestException("Not a player in this session");
		}

		player.isReady = true;

		// Check if all players are ready
		const allPlayersReady = session.players.every((p) => p.isReady);

		if (allPlayersReady) {
			session.readyForNextGame = true;

			// Start next game
			if (session.currentGameNumber <= session.numberOfGames) {
				// Reset for next game
				session.status = SessionStatus.IN_PROGRESS;
				session.currentPhase = 0;

				const preset = await this.presetModel.findById(session.presetId);
				if (preset) {
					session.currentTeam = preset.draftFlow[0]?.player || 1;
					session.timeLeft = preset.draftFlow[0]?.timeLimit || 30;
				}

				session.currentPhaseType = DraftPhaseType.BAN;
				await this.startPhaseTimer(session);
			}
		}

		await this.updateSession(session);
		return session;
	}

	async getGameResults(sessionId: string): Promise<any[]> {
		const session = await this.getSession(sessionId);
		return session.gameResults;
	}

	async getAvailableStages(sessionId: string): Promise<number[]> {
		const session = await this.getSession(sessionId);
		return session.availableStages;
	}

	async getAgentSavesForUser(userId: string): Promise<any[]> {
		const user = await this.userModel.findById(userId).populate({
			path: "agentSaves.agents",
			select:
				"name fullName normalizedName rarity specialty attribute imageUrl iconUrl"
		});

		if (!user) {
			throw new NotFoundException("User not found");
		}

		return user.agentSaves;
	}

	private async calculateAgentCostsForPreban(
		session: DraftSession
	): Promise<void> {
		const preset = await this.presetModel.findById(session.presetId);

		if (!preset) {
			throw new NotFoundException("Preset not found");
		}

		// Calculate total agent cost for each player
		for (const player of session.players) {
			let totalCost = 0;

			// If player has an agent save, calculate cost based on it
			if (player.agentSaveId) {
				totalCost = await this.calculateAgentSaveCost(
					player.agentSaveId.toString(),
					preset
				);
			} else if (player.agentSaveAgents && player.agentSaveAgents.length > 0) {
				// If player has agent save agents but no agent save ID (rare case)
				// Calculate costs based on the agent IDs
				for (const agentId of player.agentSaveAgents) {
					const agentCost = preset.agentCosts.find(
						(ac) => ac.agent.toString() === agentId.toString()
					);

					if (agentCost) {
						// Use base cost (mindscape level 0) as fallback
						const cost = agentCost.mindscapeCosts.get(0) || 0;
						totalCost += cost;
					}
				}
			} else {
				// For players without agent saves, use a default calculation
				// This should be rare in production, but we'll handle it gracefully
				totalCost = 0;
			}

			// Add the total cost to the player
			player.totalAgentCost = totalCost;
		}

		// Determine which player gets to preban based on cost difference
		const player1 = session.players.find((p) => p.team === 1);
		const player2 = session.players.find((p) => p.team === 2);

		if (player1 && player2) {
			// Calculate the cost difference
			const costDifference = Math.abs(
				player1.totalAgentCost - player2.totalAgentCost
			);

			// Check if the cost difference exceeds the threshold for prebans
			if (costDifference >= preset.rules.costDifferenceForPreban) {
				// The player with the higher cost gets to preban
				session.currentTeam =
					player1.totalAgentCost > player2.totalAgentCost
						? player1.team
						: player2.team;
			} else {
				// If the cost difference is below the threshold, no prebans are needed
				// Move directly to the draft phase
				session.status = SessionStatus.IN_PROGRESS;
				session.currentPhaseType = DraftPhaseType.BAN;
				session.currentPhase = 0;

				if (preset.draftFlow && preset.draftFlow.length > 0) {
					session.currentTeam = preset.draftFlow[0]?.player || 1;
					session.timeLeft = preset.draftFlow[0]?.timeLimit || 30;
				}
			}
		}

		session.prebansCalculated = true;
	}

	private async calculateAgentSaveCost(
		agentSaveId: string,
		preset: DraftPreset
	): Promise<number> {
		// Get the agent save
		const user = await this.userModel
			.findOne({
				"agentSaves._id": new Types.ObjectId(agentSaveId)
			})
			.populate("ownedAgents.agent");

		if (!user) {
			return 0;
		}

		const agentSave = user.agentSaves.find(
			(save: any) => save._id.toString() === agentSaveId
		);

		if (!agentSave) {
			return 0;
		}

		// Calculate total agent cost
		let totalAgentCost = 0;

		for (const agentId of agentSave.agents) {
			// Find the agent cost configuration in the preset
			const agentCost = preset.agentCosts.find(
				(ac) => ac.agent.toString() === agentId.toString()
			);

			if (agentCost) {
				// Find the user's owned agent to get the mindscape level
				const ownedAgent = user.ownedAgents.find(
					(oa) => oa.agent._id.toString() === agentId.toString()
				);

				if (ownedAgent) {
					// Get the cost for this mindscape level from the preset
					const mindscapeLevel = ownedAgent.mindscape;
					// Map is typed as Map<number, number> but we need to convert the key to number
					const cost = agentCost.mindscapeCosts.get(mindscapeLevel) || 0;
					totalAgentCost += cost;
				} else {
					// If the user doesn't own the agent (shouldn't happen in normal flow),
					// use the base cost (mindscape level 0)
					const cost = agentCost.mindscapeCosts.get(0) || 0;
					totalAgentCost += cost;
				}
			}
		}

		return totalAgentCost;
	}

	async removeSpectator(
		sessionId: string,
		userId: string
	): Promise<DraftSession> {
		const session = await this.getSession(sessionId);

		session.spectators = session.spectators.filter(
			(spectatorId) => spectatorId.toString() !== userId
		);

		await this.updateSession(session);
		return session;
	}
}
