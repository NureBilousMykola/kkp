// src/modules/draft/dto/assign-engine.dto.ts
import { IsString } from "class-validator";

export class AssignEngineDto {
	@IsString()
	characterId: string;

	@IsString()
	engineId: string;
}
