// src/modules/draft/dto/assign-room.dto.ts
import { IsArray, IsNumber, IsString, Max, Min } from "class-validator";

export class AssignRoomDto {
	@IsArray()
	@IsString({ each: true })
	characterIds: string[];

	@IsNumber()
	@Min(1)
	@Max(2)
	roomId: number;
}
