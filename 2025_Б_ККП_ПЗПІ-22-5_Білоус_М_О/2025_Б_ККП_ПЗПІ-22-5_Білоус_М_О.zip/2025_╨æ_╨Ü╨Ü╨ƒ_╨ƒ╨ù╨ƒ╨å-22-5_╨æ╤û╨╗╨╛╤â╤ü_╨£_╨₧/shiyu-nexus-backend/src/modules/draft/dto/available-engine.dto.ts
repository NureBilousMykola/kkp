// src/modules/draft/dto/available-engine.dto.ts
import { Engine } from "@schemas/engine.schema";
import { CostReason } from "../interfaces/engine-with-cost.interface";

export class AvailableEngineDto {
	engine: Engine;
	cost: number;
	costReason: CostReason;
}
