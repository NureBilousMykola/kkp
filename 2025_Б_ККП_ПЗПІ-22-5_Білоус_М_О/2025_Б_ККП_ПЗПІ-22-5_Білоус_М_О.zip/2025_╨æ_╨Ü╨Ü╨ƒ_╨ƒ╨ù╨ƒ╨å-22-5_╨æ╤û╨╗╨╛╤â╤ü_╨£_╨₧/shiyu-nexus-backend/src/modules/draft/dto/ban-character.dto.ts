// src/modules/draft/dto/ban-character.dto.ts
import { IsString } from "class-validator";

export class BanCharacterDto {
	@IsString()
	characterId: string;
}
