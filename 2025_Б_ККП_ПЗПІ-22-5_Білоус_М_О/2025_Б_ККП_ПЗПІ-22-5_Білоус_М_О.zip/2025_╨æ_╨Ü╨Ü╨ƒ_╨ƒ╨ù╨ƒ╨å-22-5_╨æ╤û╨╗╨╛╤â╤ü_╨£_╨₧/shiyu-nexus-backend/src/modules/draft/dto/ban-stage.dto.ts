// src/modules/draft/dto/ban-stage.dto.ts
import { IsNumber, Max, Min } from "class-validator";

export class BanStageDto {
	@IsNumber()
	@Min(1)
	@Max(7)
	stageId: number;
}
