import { ApiProperty } from "@nestjs/swagger";
import {
	IsBoolean,
	IsMongoId,
	IsNumber,
	IsOptional,
	IsString,
	Max,
	Min
} from "class-validator";

export class CreateSessionDto {
	@ApiProperty({
		description: "Name of the draft session",
		example: "Friendly Match"
	})
	@IsString()
	name: string;

	@ApiProperty({
		description: "ID of the draft preset to use",
		example: "60d21b4667d0d8992e610c86"
	})
	@IsMongoId()
	presetId: string;

	@ApiProperty({
		description: "Password for private sessions",
		example: "secret123",
		required: false
	})
	@IsString()
	@IsOptional()
	password?: string;

	@ApiProperty({
		description: "Whether to allow spectators",
		example: true,
		default: true,
		required: false
	})
	@IsBoolean()
	@IsOptional()
	allowSpectators?: boolean = true;

	@ApiProperty({
		description: "Whether to require a judge",
		example: false,
		default: false,
		required: false
	})
	@IsBoolean()
	@IsOptional()
	requireJudge?: boolean = false;

	@ApiProperty({
		description: "Number of games in the match (BO1, BO3, etc.)",
		example: 3,
		default: 1,
		minimum: 1,
		maximum: 5,
		required: false
	})
	@IsNumber()
	@IsOptional()
	@Min(1)
	@Max(5)
	numberOfGames?: number = 1; // Default to BO1

	@ApiProperty({
		description: "ID of the agent save to use for the host",
		example: "60d21b4667d0d8992e610c86",
		required: false
	})
	@IsMongoId()
	@IsOptional()
	agentSaveId?: string;
}
