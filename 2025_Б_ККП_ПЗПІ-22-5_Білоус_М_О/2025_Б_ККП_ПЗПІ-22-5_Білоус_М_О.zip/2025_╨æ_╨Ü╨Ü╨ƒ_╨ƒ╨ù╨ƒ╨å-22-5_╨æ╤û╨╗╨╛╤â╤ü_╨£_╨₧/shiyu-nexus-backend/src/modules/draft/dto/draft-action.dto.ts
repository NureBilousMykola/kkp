// src/modules/draft/dto/draft-action.dto.ts
import { IsArray, IsEnum, IsNumber, IsOptional } from "class-validator";

export class DraftPickDto {
	@IsNumber()
	characterId: string;

	@IsNumber()
	@IsOptional()
	engineId?: string;
}

export class DraftBanDto {
	@IsNumber()
	characterId: string;
}

export class RoomAssignmentDto {
	@IsEnum([1, 2])
	team: 1 | 2;

	@IsNumber()
	stageNumber: number;

	@IsNumber()
	roomNumber: 1 | 2;

	@IsArray()
	@IsNumber({}, { each: true })
	characterIds: string[];
}
