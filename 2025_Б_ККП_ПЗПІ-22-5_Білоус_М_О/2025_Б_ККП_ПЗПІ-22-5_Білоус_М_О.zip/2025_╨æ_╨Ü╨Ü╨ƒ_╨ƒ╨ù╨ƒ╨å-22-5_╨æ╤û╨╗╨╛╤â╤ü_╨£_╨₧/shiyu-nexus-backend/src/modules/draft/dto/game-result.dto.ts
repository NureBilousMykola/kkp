// src/modules/draft/dto/game-result.dto.ts
import {
	IsEnum,
	IsNumber,
	IsOptional,
	IsString,
	Max,
	Min
} from "class-validator";

export class SubmitGameResultDto {
	@IsNumber()
	@Min(1)
	gameNumber: number;

	@IsNumber()
	@Min(1)
	@Max(7)
	stageId: number;

	@IsEnum([1, 2, 0]) // 0 for draw
	winner: number;

	@IsNumber()
	@Min(0)
	timeElapsed: number; // in seconds

	@IsNumber()
	@Min(0)
	freeRestartsUsed: number;

	@IsNumber()
	@Min(0)
	paidRestartsUsed: number;

	@IsString()
	@IsOptional()
	notes?: string;
}
