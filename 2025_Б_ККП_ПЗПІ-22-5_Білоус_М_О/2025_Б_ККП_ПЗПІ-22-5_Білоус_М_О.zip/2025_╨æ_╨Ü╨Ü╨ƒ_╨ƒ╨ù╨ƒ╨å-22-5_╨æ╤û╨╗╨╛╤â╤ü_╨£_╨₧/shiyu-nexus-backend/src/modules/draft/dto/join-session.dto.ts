import { ApiProperty } from "@nestjs/swagger";
// src/modules/draft/dto/join-session.dto.ts
import {
	IsMongoId,
	IsNumber,
	IsOptional,
	IsString,
	Max,
	Min
} from "class-validator";

export class JoinSessionDto {
	@ApiProperty({
		description: "Team to join (1 or 2)",
		example: 2,
		minimum: 1,
		maximum: 2
	})
	@IsNumber()
	@Min(1)
	@Max(2)
	team: 1 | 2;

	@ApiProperty({
		description: "Password for private sessions",
		example: "secret123",
		required: false
	})
	@IsString()
	@IsOptional()
	password?: string;

	@ApiProperty({
		description: "ID of the agent save to use",
		example: "60d21b4667d0d8992e610c86",
		required: false
	})
	@IsMongoId()
	@IsOptional()
	agentSaveId?: string;
}
