// src/modules/draft/dto/pick-character.dto.ts
import { IsNumber, IsOptional, IsString } from "class-validator";

export class PickCharacterDto {
	@IsString()
	characterId: string;

	@IsString()
	@IsOptional()
	engineId?: string;

	@IsNumber()
	@IsOptional()
	engineCost?: number;
}
