// src/modules/draft/dto/preban-agent.dto.ts
import { IsString } from "class-validator";

export class PrebanAgentDto {
	@IsString()
	characterId: string;
}
