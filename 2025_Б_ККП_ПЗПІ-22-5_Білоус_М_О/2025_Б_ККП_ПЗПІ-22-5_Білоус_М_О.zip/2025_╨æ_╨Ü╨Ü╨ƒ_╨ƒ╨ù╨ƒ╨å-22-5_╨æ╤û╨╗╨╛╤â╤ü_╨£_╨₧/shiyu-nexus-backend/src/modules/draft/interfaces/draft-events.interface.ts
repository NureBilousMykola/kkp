// src/modules/draft/interfaces/draft-events.interface.ts
import { DraftState } from "@modules/draft/interfaces/draft-state.interface";

export interface DraftJoinEvent {
	userId: string;
	presetId: string;
	team: 1 | 2;
}

export interface DraftPickEvent {
	userId: string;
	characterId: string;
	engineId?: string;
}

export interface DraftBanEvent {
	userId: string;
	characterId: string;
}

export interface DraftRoomAssignEvent {
	userId: string;
	characterIds: string[];
	roomId: number;
}

export interface DraftTimerEvent {
	draftId: string;
	timeLeft: number;
}

export interface DraftStateUpdateEvent {
	state: DraftState;
}

export interface DraftErrorEvent {
	message: string;
	code: string;
}
