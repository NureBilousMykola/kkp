// src/modules/draft/interfaces/draft-session.interface.ts
import { DraftState } from "@modules/draft/interfaces/draft-state.interface";

export interface DraftSession {
	id: string;
	hostId: string;
	presetId: string;
	players: DraftPlayer[];
	state: DraftState;
	spectators: string[];
	settings: DraftSettings;
}

export interface DraftPlayer {
	userId: string;
	team: 1 | 2;
	connected: boolean;
	lastPing: Date;
}

export interface DraftSettings {
	allowSpectators?: boolean;
	pauseOnDisconnect?: boolean;
	autoReadyAfterCharacterPick?: boolean;
	autoReadyAfterRoomAssignment?: boolean;
}
