// src/modules/draft/interfaces/draft-state.interface.ts
import { Agent } from "@schemas/agent.schema";
import { DraftPhase } from "@schemas/draft-preset.schema";
import { Engine } from "@schemas/engine.schema";

export enum DraftStatus {
	WAITING = "waiting",
	IN_PROGRESS = "in_progress",
	FINISHED = "finished",
	CANCELLED = "cancelled"
}

export interface DraftPlayer {
	userId: string;
	username: string;
	team: 1 | 2;
	isReady: boolean;
	selectedCharacters: Agent[];
	selectedEngines: Engine[];
	roomAssignments: Map<number, Agent[]>;
	engineAssignments: Map<string, Engine>;
	banList: Agent[];
}

export interface DraftState {
	id: string;
	status: DraftStatus;
	presetId: string;
	currentPhase: number;
	currentTeam: 1 | 2;
	timeLeft: number;
	players: Map<string, DraftPlayer>;
	phases: DraftPhase[];
	startTime?: Date;
	endTime?: Date;
}

export interface DraftSession {
	state: DraftState;
	timer?: NodeJS.Timeout;
	lastUpdateTime: Date;
}
