// src/modules/draft/interfaces/engine-with-cost.interface.ts
import { Engine } from "@schemas/engine.schema";

export interface EngineWithCost {
	engine: Engine;
	cost: number;
	costReason: CostReason;
}

export enum CostReason {
	SIGNATURE_AGENT = "signature_agent",
	SAME_SPECIALTY = "same_specialty",
	DIFFERENT_SPECIALTY = "different_specialty",
	EXCEPTION = "exception"
}
