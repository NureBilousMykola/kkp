import { ATTRIBUTES } from "@shared/constants/constants";
import { IsArray, IsEnum, IsOptional, IsString } from "class-validator";

export class CreateEnemyDto {
	@IsString()
	name: string;

	@IsString()
	normalizedName: string;

	@IsEnum(["ether_mutants", "thugs", "corrupted", "rebel_soldiers", "special"])
	category: string;

	@IsString()
	@IsOptional()
	description?: string;

	@IsArray()
	@IsEnum(ATTRIBUTES, { each: true })
	weaknessAttributes: string[];

	@IsArray()
	@IsEnum(ATTRIBUTES, { each: true })
	resistanceAttributes: string[];

	@IsString()
	@IsOptional()
	imageUrl?: string;
}
