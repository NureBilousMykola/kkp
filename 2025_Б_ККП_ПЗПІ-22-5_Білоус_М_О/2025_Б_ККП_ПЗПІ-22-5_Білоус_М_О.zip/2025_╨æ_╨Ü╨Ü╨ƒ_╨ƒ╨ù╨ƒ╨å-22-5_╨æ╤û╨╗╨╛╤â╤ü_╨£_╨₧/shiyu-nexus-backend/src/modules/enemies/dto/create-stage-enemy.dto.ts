import {
	IsArray,
	IsMongoId,
	IsNumber,
	Max,
	Min,
	ValidateNested
} from "class-validator";
import { Type } from "class-transformer";

class EnemyEntryDto {
	@IsMongoId()
	enemyId: string;

	@IsNumber()
	@Min(1)
	level: number;
}

export class CreateStageEnemyDto {
	@IsNumber()
	@Min(1)
	@Max(7)
	stageId: number;

	@IsNumber()
	@Min(1)
	@Max(2)
	roomId: number;

	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => EnemyEntryDto)
	enemies: EnemyEntryDto[];
}
