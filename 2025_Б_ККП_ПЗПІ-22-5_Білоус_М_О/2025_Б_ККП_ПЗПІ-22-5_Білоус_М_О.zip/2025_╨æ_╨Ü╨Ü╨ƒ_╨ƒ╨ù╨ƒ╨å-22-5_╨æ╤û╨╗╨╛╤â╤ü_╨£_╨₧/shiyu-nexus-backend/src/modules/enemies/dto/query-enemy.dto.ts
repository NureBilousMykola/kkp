import { ATTRIBUTES } from "@shared/constants/constants";
import { IsArray, IsEnum, IsOptional } from "class-validator";

export class QueryEnemyDto {
	@IsOptional()
	@IsEnum(["ether_mutants", "thugs", "corrupted", "rebel_soldiers", "special"])
	category?: string;

	@IsOptional()
	@IsArray()
	@IsEnum(ATTRIBUTES, { each: true })
	weaknessAttributes?: string[];

	@IsOptional()
	@IsArray()
	@IsEnum(ATTRIBUTES, { each: true })
	resistanceAttributes?: string[];
}
