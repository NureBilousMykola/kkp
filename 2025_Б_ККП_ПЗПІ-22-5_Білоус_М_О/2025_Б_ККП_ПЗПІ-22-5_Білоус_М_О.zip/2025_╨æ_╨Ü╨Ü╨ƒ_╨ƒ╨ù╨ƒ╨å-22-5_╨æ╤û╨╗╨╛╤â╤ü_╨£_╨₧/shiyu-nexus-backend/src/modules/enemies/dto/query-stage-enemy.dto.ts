import { IsNumber, IsOptional, Max, Min } from "class-validator";

export class QueryStageEnemyDto {
	@IsOptional()
	@IsNumber()
	@Min(1)
	@Max(7)
	stageId?: number;

	@IsOptional()
	@IsNumber()
	@Min(1)
	@Max(2)
	roomId?: number;

	@IsOptional()
	@IsNumber()
	@Min(1)
	minLevel?: number;

	@IsOptional()
	@IsNumber()
	@Max(100)
	maxLevel?: number;
}
