import { PartialType } from "@nestjs/mapped-types";
import { CreateStageEnemyDto } from "./create-stage-enemy.dto";

export class UpdateStageEnemyDto extends PartialType(CreateStageEnemyDto) {}
