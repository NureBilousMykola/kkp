import {
	BadRequestException,
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	Query,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import { UserRole } from "@shared/enums/user-role.enum";
import { ParseMongoIdPipe } from "@shared/pipes/parse-mongo-id.pipe";
import { Roles } from "../users/decorators/roles.decorator";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { RolesGuard } from "../users/guards/roles.guard";
import { CreateEnemyDto } from "./dto/create-enemy.dto";
import { CreateStageEnemyDto } from "./dto/create-stage-enemy.dto";
import { QueryEnemyDto } from "./dto/query-enemy.dto";
import { UpdateEnemyDto } from "./dto/update-enemy.dto";
import { UpdateStageEnemyDto } from "./dto/update-stage-enemy.dto";
import { EnemiesService } from "./enemies.service";

@ApiTags("enemies")
@Controller("enemies")
export class EnemiesController {
	constructor(private readonly enemiesService: EnemiesService) {}

	// Enemy base data endpoints
	@Post()
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Create a new enemy" })
	async createEnemy(@Body(ValidationPipe) createEnemyDto: CreateEnemyDto) {
		try {
			return await this.enemiesService.createEnemy(createEnemyDto);
		} catch (error) {
			if (error.code === 11000) {
				throw new BadRequestException("Enemy with this name already exists");
			}
			throw error;
		}
	}

	@Get()
	@ApiOperation({ summary: "Get all enemies with optional filtering" })
	async findAllEnemies(@Query(ValidationPipe) query: QueryEnemyDto) {
		return this.enemiesService.findAllEnemies(query);
	}

	// Stage enemy endpoints - MUST come before :id routes
	@Get("stage")
	@ApiOperation({ summary: "Get all stage enemies with optional filtering" })
	async findAllStageEnemies(@Query() query: any) {
		return this.enemiesService.findAllStageEnemies(query);
	}

	@Get("stage/:id")
	@ApiOperation({ summary: "Get stage enemies by ID" })
	async findOneStageEnemy(@Param("id", ParseMongoIdPipe) id: string) {
		return this.enemiesService.findOneStageEnemy(id);
	}

	@Get("stage/filter/level")
	@ApiOperation({ summary: "Get stage enemies by level range" })
	async getStageEnemiesByLevel(
		@Query("minLevel") minLevel = 1,
		@Query("maxLevel") maxLevel = 100
	) {
		return this.enemiesService.getStageEnemiesByLevel(minLevel, maxLevel);
	}

	@Get("stage/filter/stage/:stageId")
	@ApiOperation({ summary: "Get all enemies for a specific stage" })
	async getEnemiesForStage(@Param("stageId") stageId: number) {
		return this.enemiesService.getEnemiesForStage(stageId);
	}

	// Additional utility endpoints
	@Get("filter/attribute/:attribute")
	@ApiOperation({ summary: "Get enemies by attribute (weakness/resistance)" })
	async getEnemiesByAttribute(
		@Param("attribute") attribute: string,
		@Query("type") type: "weakness" | "resistance" = "weakness"
	) {
		return this.enemiesService.getEnemiesByAttribute(
			attribute,
			type === "weakness"
		);
	}

	@Get(":id")
	@ApiOperation({ summary: "Get enemy by ID" })
	async findOneEnemy(@Param("id", ParseMongoIdPipe) id: string) {
		return this.enemiesService.findOneEnemy(id);
	}

	@Patch(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update an enemy" })
	async updateEnemy(
		@Param("id", ParseMongoIdPipe) id: string,
		@Body(ValidationPipe) updateEnemyDto: UpdateEnemyDto
	) {
		try {
			return await this.enemiesService.updateEnemy(id, updateEnemyDto);
		} catch (error) {
			if (error.code === 11000) {
				throw new BadRequestException("Enemy with this name already exists");
			}
			throw error;
		}
	}

	@Delete(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Delete an enemy" })
	async removeEnemy(@Param("id", ParseMongoIdPipe) id: string) {
		return this.enemiesService.removeEnemy(id);
	}

	// Stage enemy endpoints
	@Post("stage")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Assign enemies to a stage room" })
	async createStageEnemy(
		@Body(ValidationPipe) createStageEnemyDto: CreateStageEnemyDto
	) {
		return this.enemiesService.createStageEnemy(createStageEnemyDto);
	}

	@Patch("stage/:id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update stage enemies" })
	async updateStageEnemy(
		@Param("id", ParseMongoIdPipe) id: string,
		@Body(ValidationPipe) updateStageEnemyDto: UpdateStageEnemyDto
	) {
		return this.enemiesService.updateStageEnemy(id, updateStageEnemyDto);
	}

	@Delete("stage/:id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Remove enemies from stage room" })
	async removeStageEnemy(@Param("id", ParseMongoIdPipe) id: string) {
		return this.enemiesService.removeStageEnemy(id);
	}
}
