import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Enemy, EnemySchema } from "@schemas/enemy.schema";
import { StageEnemy, StageEnemySchema } from "@schemas/stage-enemy.schema";
import { UsersModule } from "../users/users.module";
import { EnemiesController } from "./enemies.controller";
import { EnemiesService } from "./enemies.service";

@Module({
	imports: [
		MongooseModule.forFeature([
			{ name: Enemy.name, schema: EnemySchema },
			{ name: StageEnemy.name, schema: StageEnemySchema }
		]),
		UsersModule
	],
	controllers: [EnemiesController],
	providers: [EnemiesService],
	exports: [EnemiesService]
})
export class EnemiesModule {}
