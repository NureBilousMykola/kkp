import {
	ConflictException,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Enemy } from "../../schemas/enemy.schema";
import { StageEnemy } from "../../schemas/stage-enemy.schema";
import { CreateEnemyDto } from "./dto/create-enemy.dto";
import { CreateStageEnemyDto } from "./dto/create-stage-enemy.dto";
import { QueryEnemyDto } from "./dto/query-enemy.dto";
import { UpdateEnemyDto } from "./dto/update-enemy.dto";
import { UpdateStageEnemyDto } from "./dto/update-stage-enemy.dto";

@Injectable()
export class EnemiesService {
	constructor(
		@InjectModel(Enemy.name) private enemyModel: Model<Enemy>,
		@InjectModel(StageEnemy.name) private stageEnemyModel: Model<StageEnemy>
	) {}

	// Enemy base data methods
	async createEnemy(createEnemyDto: CreateEnemyDto): Promise<Enemy> {
		const existing = await this.enemyModel.findOne({
			name: createEnemyDto.name
		});
		if (existing) {
			throw new ConflictException("Enemy with this name already exists");
		}

		const enemy = new this.enemyModel(createEnemyDto);
		return enemy.save();
	}

	async findAllEnemies(query: QueryEnemyDto = {}): Promise<Enemy[]> {
		const filter: any = {};

		if (query.weaknessAttributes?.length) {
			filter.weaknessAttributes = { $in: query.weaknessAttributes };
		}

		if (query.resistanceAttributes?.length) {
			filter.resistanceAttributes = { $in: query.resistanceAttributes };
		}

		return this.enemyModel.find(filter).exec();
	}

	async findOneEnemy(id: string): Promise<Enemy> {
		const enemy = await this.enemyModel.findById(id).exec();
		if (!enemy) {
			throw new NotFoundException(`Enemy with ID ${id} not found`);
		}
		return enemy;
	}

	async updateEnemy(
		id: string,
		updateEnemyDto: UpdateEnemyDto
	): Promise<Enemy> {
		if (updateEnemyDto.name) {
			const existing = await this.enemyModel.findOne({
				name: updateEnemyDto.name,
				_id: { $ne: id }
			});

			if (existing) {
				throw new ConflictException("Enemy with this name already exists");
			}
		}

		const enemy = await this.enemyModel
			.findByIdAndUpdate(id, updateEnemyDto, { new: true })
			.exec();

		if (!enemy) {
			throw new NotFoundException(`Enemy with ID ${id} not found`);
		}

		return enemy;
	}

	async removeEnemy(id: string): Promise<Enemy> {
		// Check if enemy is used in any stage
		const usedInStage = await this.stageEnemyModel
			.findOne({ enemyId: id })
			.exec();
		if (usedInStage) {
			throw new ConflictException("Cannot delete enemy that is used in stages");
		}

		const enemy = await this.enemyModel.findByIdAndDelete(id).exec();
		if (!enemy) {
			throw new NotFoundException(`Enemy with ID ${id} not found`);
		}

		return enemy;
	}

	// Stage enemy methods
	async createStageEnemy(
		createStageEnemyDto: CreateStageEnemyDto
	): Promise<StageEnemy> {
		// Check if all enemies exist
		for (const enemyEntry of createStageEnemyDto.enemies) {
			const enemy = await this.enemyModel.findById(enemyEntry.enemyId).exec();
			if (!enemy) {
				throw new NotFoundException(
					`Enemy with ID ${enemyEntry.enemyId} not found`
				);
			}
		}

		// Check if stage-room combination already exists
		const existing = await this.stageEnemyModel
			.findOne({
				stageId: createStageEnemyDto.stageId,
				roomId: createStageEnemyDto.roomId
			})
			.exec();

		if (existing) {
			// Merge new enemy entries into the existing document.
			for (const incoming of createStageEnemyDto.enemies) {
				const idx = existing.enemies.findIndex(
					(e) => e.enemyId.toString() === incoming.enemyId
				);
				if (idx !== -1) {
					// Update level if enemy already present.
					existing.enemies[idx].level = incoming.level;
				} else {
					existing.enemies.push(incoming as any);
				}
			}

			await existing.save();

			return await existing.populate("enemies.enemy");
		}

		const stageEnemy = new this.stageEnemyModel(createStageEnemyDto);
		return (await stageEnemy.save()).populate("enemies.enemy");
	}

	async findAllStageEnemies(query: any = {}): Promise<StageEnemy[]> {
		const filter: any = {};

		if (query.stageId) filter.stageId = Number(query.stageId);
		if (query.roomId) filter.roomId = Number(query.roomId);
		if (query.minLevel)
			filter["enemies.level"] = { $gte: Number(query.minLevel) };
		if (query.maxLevel) {
			filter["enemies.level"] = {
				...filter["enemies.level"],
				$lte: Number(query.maxLevel)
			};
		}

		return this.stageEnemyModel
			.find(filter)
			.populate({
				path: "enemies",
				populate: {
					path: "enemyId",
					model: "Enemy"
				}
			})
			.exec();
	}

	async findOneStageEnemy(id: string): Promise<StageEnemy> {
		const stageEnemy = await this.stageEnemyModel
			.findById(id)
			.populate("enemies.enemy")
			.exec();

		if (!stageEnemy) {
			throw new NotFoundException(`Stage enemy with ID ${id} not found`);
		}

		return stageEnemy;
	}

	async updateStageEnemy(
		id: string,
		updateStageEnemyDto: UpdateStageEnemyDto
	): Promise<StageEnemy> {
		if (updateStageEnemyDto.enemies) {
			// Check if all enemies exist
			for (const enemyEntry of updateStageEnemyDto.enemies) {
				const enemy = await this.enemyModel.findById(enemyEntry.enemyId).exec();
				if (!enemy) {
					throw new NotFoundException(
						`Enemy with ID ${enemyEntry.enemyId} not found`
					);
				}
			}
		}

		if (updateStageEnemyDto.stageId || updateStageEnemyDto.roomId) {
			const existing = await this.stageEnemyModel
				.findOne({
					stageId: updateStageEnemyDto.stageId,
					roomId: updateStageEnemyDto.roomId,
					_id: { $ne: id }
				})
				.exec();

			if (existing) {
				throw new ConflictException(
					`Stage ${updateStageEnemyDto.stageId} Room ${updateStageEnemyDto.roomId} already has enemies assigned`
				);
			}
		}

		const stageEnemy = await this.stageEnemyModel
			.findByIdAndUpdate(id, updateStageEnemyDto, { new: true })
			.populate("enemies.enemy")
			.exec();

		if (!stageEnemy) {
			throw new NotFoundException(`Stage enemy with ID ${id} not found`);
		}

		return stageEnemy;
	}

	async removeStageEnemy(id: string): Promise<StageEnemy> {
		const stageEnemy = await this.stageEnemyModel
			.findByIdAndDelete(id)
			.populate("enemies.enemy")
			.exec();

		if (!stageEnemy) {
			throw new NotFoundException(`Stage enemy with ID ${id} not found`);
		}

		return stageEnemy;
	}

	// Utility methods
	async getEnemiesByAttribute(
		attribute: string,
		isWeakness = true
	): Promise<Enemy[]> {
		const field = isWeakness ? "weaknessAttributes" : "resistanceAttributes";
		return this.enemyModel.find({ [field]: attribute }).exec();
	}

	async getStageEnemiesByLevel(
		minLevel: number,
		maxLevel: number
	): Promise<StageEnemy[]> {
		return this.stageEnemyModel
			.find({
				"enemies.level": { $gte: minLevel, $lte: maxLevel }
			})
			.populate("enemies.enemy")
			.exec();
	}

	async getEnemiesForStage(stageId: number): Promise<StageEnemy[]> {
		return this.stageEnemyModel
			.find({ stageId })
			.populate("enemies.enemy")
			.exec();
	}
}
