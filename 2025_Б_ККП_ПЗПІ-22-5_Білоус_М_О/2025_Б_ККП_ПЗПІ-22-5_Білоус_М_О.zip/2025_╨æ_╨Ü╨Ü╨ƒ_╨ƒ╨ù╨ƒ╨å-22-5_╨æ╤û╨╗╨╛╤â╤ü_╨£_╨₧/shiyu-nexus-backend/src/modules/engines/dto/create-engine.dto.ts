import {
	IsBoolean,
	IsEnum,
	IsMongoId,
	IsNumber,
	IsOptional,
	IsString,
	Max,
	Min
} from "class-validator";

export class CreateEngineDto {
	@IsString()
	name: string;

	@IsString()
	normalizedName: string;

	@IsEnum(["S", "A", "B"])
	rarity: string;

	@IsEnum(["attack", "anomaly", "defense", "stun", "support"])
	specialty: string;

	@IsBoolean()
	isCraftable: boolean;

	@IsBoolean()
	isEventLimited: boolean;

	@IsMongoId()
	@IsOptional()
	signatureAgentId?: string;

	@IsNumber()
	@Min(1)
	@Max(5)
	maxAscension: number;

	@IsString()
	@IsOptional()
	imageUrl?: string;
}
