import { IsBoolean, IsEnum, IsOptional } from "class-validator";

export class QueryEngineDto {
	@IsEnum(["S", "A", "B"])
	@IsOptional()
	rarity?: string;

	@IsEnum(["attack", "anomaly", "defense", "stun", "support"])
	@IsOptional()
	specialty?: string;

	@IsBoolean()
	@IsOptional()
	isCraftable?: boolean;

	@IsBoolean()
	@IsOptional()
	isEventLimited?: boolean;
}
