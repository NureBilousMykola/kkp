import {
	BadRequestException,
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	Query,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiResponse, ApiTags } from "@nestjs/swagger";
import { UserRole } from "@shared/enums/user-role.enum";
import { ParseMongoIdPipe } from "@shared/pipes/parse-mongo-id.pipe";
import { Roles } from "../users/decorators/roles.decorator";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { RolesGuard } from "../users/guards/roles.guard";
import { CreateEngineDto } from "./dto/create-engine.dto";
import { QueryEngineDto } from "./dto/query-engine.dto";
import { UpdateEngineDto } from "./dto/update-engine.dto";
import { EnginesService } from "./engines.service";

@ApiTags("engines")
@Controller("engines")
export class EnginesController {
	constructor(private readonly enginesService: EnginesService) {}

	@Post()
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Create a new engine" })
	@ApiResponse({ status: 201, description: "Engine successfully created" })
	@ApiResponse({ status: 400, description: "Invalid input" })
	async create(@Body(ValidationPipe) createEngineDto: CreateEngineDto) {
		try {
			return await this.enginesService.create(createEngineDto);
		} catch (error) {
			if (error.code === 11000) {
				throw new BadRequestException("Engine with this name already exists");
			}
			throw error;
		}
	}

	@Get()
	@ApiOperation({ summary: "Get all engines with optional filtering" })
	async findAll(@Query(ValidationPipe) query: QueryEngineDto) {
		return this.enginesService.findAll(query);
	}

	@Get(":id")
	@ApiOperation({ summary: "Get engine by ID" })
	@ApiResponse({ status: 200, description: "Returns the engine" })
	@ApiResponse({ status: 404, description: "Engine not found" })
	async findOne(@Param("id", ParseMongoIdPipe) id: string) {
		return this.enginesService.findOne(id);
	}

	@Get("name/:normalizedName")
	@ApiOperation({ summary: "Get engine by normalized name" })
	async findByNormalizedName(@Param("normalizedName") normalizedName: string) {
		return this.enginesService.findByNormalizedName(normalizedName);
	}

	@Patch(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update an engine" })
	async update(
		@Param("id", ParseMongoIdPipe) id: string,
		@Body(ValidationPipe) updateEngineDto: UpdateEngineDto
	) {
		try {
			return await this.enginesService.update(id, updateEngineDto);
		} catch (error) {
			if (error.code === 11000) {
				throw new BadRequestException("Engine with this name already exists");
			}
			throw error;
		}
	}

	@Delete(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Delete an engine" })
	async remove(@Param("id", ParseMongoIdPipe) id: string) {
		return this.enginesService.remove(id);
	}

	// Additional endpoints for specific queries
	@Get("filter/craftable")
	@ApiOperation({ summary: "Get all craftable engines" })
	async getCraftableEngines() {
		return this.enginesService.getCraftableEngines();
	}

	@Get("filter/signature")
	@ApiOperation({ summary: "Get all signature engines" })
	async getSignatureEngines() {
		return this.enginesService.getSignatureEngines();
	}

	@Get("filter/rarity/:rarity")
	@ApiOperation({ summary: "Get engines by rarity" })
	async getEnginesByRarity(@Param("rarity") rarity: string) {
		return this.enginesService.getEnginesByRarity(rarity);
	}

	@Get("filter/specialty/:specialty")
	@ApiOperation({ summary: "Get engines by specialty" })
	async getEnginesBySpecialty(@Param("specialty") specialty: string) {
		return this.enginesService.getEnginesBySpecialty(specialty);
	}

	@Get("filter/agent/:agentId")
	@ApiOperation({ summary: "Get engines for a specific agent" })
	async getEnginesForAgent(
		@Param("agentId", ParseMongoIdPipe) agentId: string
	) {
		return this.enginesService.getEnginesForAgent(agentId);
	}
}
