import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Engine, EngineSchema } from "../../schemas/engine.schema";
import { EnginesController } from "./engines.controller";
import { EnginesService } from "./engines.service";

@Module({
	imports: [
		MongooseModule.forFeature([{ name: Engine.name, schema: EngineSchema }])
	],
	controllers: [EnginesController],
	providers: [EnginesService],
	exports: [EnginesService]
})
export class EnginesModule {}
