import {
	ConflictException,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Engine } from "../../schemas/engine.schema";
import { CreateEngineDto } from "./dto/create-engine.dto";
import { QueryEngineDto } from "./dto/query-engine.dto";
import { UpdateEngineDto } from "./dto/update-engine.dto";

@Injectable()
export class EnginesService {
	constructor(@InjectModel(Engine.name) private engineModel: Model<Engine>) {}

	async create(createEngineDto: CreateEngineDto): Promise<Engine> {
		const existing = await this.engineModel.findOne({
			normalizedName: createEngineDto.normalizedName
		});

		if (existing) {
			throw new ConflictException(
				"Engine with this normalized name already exists"
			);
		}

		const engine = new this.engineModel(createEngineDto);
		return engine.save();
	}

	async findAll(query: QueryEngineDto = {}): Promise<Engine[]> {
		const filter: any = {};

		if (query.rarity) filter.rarity = query.rarity;
		if (query.specialty) filter.specialty = query.specialty;
		if (query.isCraftable !== undefined) filter.isCraftable = query.isCraftable;

		return this.engineModel
			.find(filter)
			.populate("signatureAgent", "name normalizedName rarity") // Only populate essential agent fields
			.exec();
	}

	async findOne(id: string): Promise<Engine> {
		const engine = await this.engineModel
			.findById(id)
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();

		if (!engine) {
			throw new NotFoundException(`Engine with ID ${id} not found`);
		}
		return engine;
	}

	async findByNormalizedName(normalizedName: string): Promise<Engine> {
		const engine = await this.engineModel
			.findOne({ normalizedName })
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();

		if (!engine) {
			throw new NotFoundException(
				`Engine with normalized name ${normalizedName} not found`
			);
		}
		return engine;
	}

	async update(id: string, updateEngineDto: UpdateEngineDto): Promise<Engine> {
		if (updateEngineDto.normalizedName) {
			const existing = await this.engineModel.findOne({
				normalizedName: updateEngineDto.normalizedName,
				_id: { $ne: id }
			});

			if (existing) {
				throw new ConflictException(
					"Engine with this normalized name already exists"
				);
			}
		}

		const engine = await this.engineModel
			.findByIdAndUpdate(id, updateEngineDto, { new: true })
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();

		if (!engine) {
			throw new NotFoundException(`Engine with ID ${id} not found`);
		}

		return engine;
	}

	async remove(id: string): Promise<Engine> {
		const engine = await this.engineModel
			.findByIdAndDelete(id)
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();

		if (!engine) {
			throw new NotFoundException(`Engine with ID ${id} not found`);
		}
		return engine;
	}

	// Additional utility methods
	async getCraftableEngines(): Promise<Engine[]> {
		return this.engineModel
			.find({ isCraftable: true })
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();
	}

	async getSignatureEngines(): Promise<Engine[]> {
		return this.engineModel
			.find({ signatureAgentId: { $exists: true } })
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();
	}

	async getEnginesByRarity(rarity: string): Promise<Engine[]> {
		return this.engineModel
			.find({ rarity })
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();
	}

	async getEnginesBySpecialty(specialty: string): Promise<Engine[]> {
		return this.engineModel
			.find({ specialty })
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();
	}

	async getEnginesForAgent(agentId: string): Promise<Engine[]> {
		return this.engineModel
			.find({ signatureAgentId: agentId })
			.populate("signatureAgent", "name normalizedName rarity")
			.exec();
	}
}
