import { IsOptional, IsString } from "class-validator";

export class CreateFactionDto {
	@IsString()
	name: string;

	@IsString()
	normalizedName: string;

	@IsString()
	@IsOptional()
	iconUrl?: string;
}
