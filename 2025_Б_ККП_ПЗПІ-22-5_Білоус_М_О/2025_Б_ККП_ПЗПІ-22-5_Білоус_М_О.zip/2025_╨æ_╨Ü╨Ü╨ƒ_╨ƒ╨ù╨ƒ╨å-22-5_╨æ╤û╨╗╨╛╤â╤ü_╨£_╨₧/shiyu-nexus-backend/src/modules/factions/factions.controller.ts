import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiTags } from "@nestjs/swagger";
import { UserRole } from "@shared/enums/user-role.enum";
import { ParseMongoIdPipe } from "@shared/pipes/parse-mongo-id.pipe";
import { Roles } from "../users/decorators/roles.decorator";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { RolesGuard } from "../users/guards/roles.guard";
import { CreateFactionDto } from "./dto/create-faction.dto";
import { UpdateFactionDto } from "./dto/update-faction.dto";
import { FactionsService } from "./factions.service";

@ApiTags("factions")
@Controller("factions")
export class FactionsController {
	constructor(private readonly factionsService: FactionsService) {}

	@Post()
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Create a new faction" })
	async create(@Body(ValidationPipe) createFactionDto: CreateFactionDto) {
		return this.factionsService.create(createFactionDto);
	}

	@Get()
	@ApiOperation({ summary: "Get all factions" })
	async findAll() {
		return this.factionsService.findAll();
	}

	@Get(":id")
	@ApiOperation({ summary: "Get faction by ID" })
	async findOne(@Param("id", ParseMongoIdPipe) id: string) {
		return this.factionsService.findOne(id);
	}

	@Get("name/:normalizedName")
	@ApiOperation({ summary: "Get faction by normalized name" })
	async findByNormalizedName(@Param("normalizedName") normalizedName: string) {
		return this.factionsService.findByNormalizedName(normalizedName);
	}

	@Patch(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update a faction" })
	async update(
		@Param("id", ParseMongoIdPipe) id: string,
		@Body(ValidationPipe) updateFactionDto: UpdateFactionDto
	) {
		return this.factionsService.update(id, updateFactionDto);
	}

	@Delete(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Delete a faction" })
	async remove(@Param("id", ParseMongoIdPipe) id: string) {
		return this.factionsService.remove(id);
	}
}
