import { Faction, FactionSchema } from "@/schemas/faction.schema";
import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { FactionsController } from "./factions.controller";
import { FactionsService } from "./factions.service";

@Module({
	imports: [
		MongooseModule.forFeature([{ name: Faction.name, schema: FactionSchema }])
	],
	controllers: [FactionsController],
	providers: [FactionsService],
	exports: [FactionsService]
})
export class FactionsModule {}
