import { Faction } from "@/schemas/faction.schema";
import {
	ConflictException,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { CreateFactionDto } from "./dto/create-faction.dto";
import { UpdateFactionDto } from "./dto/update-faction.dto";

@Injectable()
export class FactionsService {
	constructor(
		@InjectModel(Faction.name) private factionModel: Model<Faction>
	) {}

	async create(createFactionDto: CreateFactionDto): Promise<Faction> {
		const existing = await this.factionModel.findOne({
			normalizedName: createFactionDto.normalizedName
		});

		if (existing) {
			throw new ConflictException(
				"Faction with this normalized name already exists"
			);
		}

		const faction = new this.factionModel(createFactionDto);
		return faction.save();
	}

	async findAll(): Promise<Faction[]> {
		return this.factionModel.find().exec();
	}

	async findOne(id: string): Promise<Faction> {
		const faction = await this.factionModel.findById(id).exec();
		if (!faction) {
			throw new NotFoundException(`Faction with ID ${id} not found`);
		}
		return faction;
	}

	async findByNormalizedName(normalizedName: string): Promise<Faction> {
		const faction = await this.factionModel.findOne({ normalizedName }).exec();
		if (!faction) {
			throw new NotFoundException(
				`Faction with normalized name ${normalizedName} not found`
			);
		}
		return faction;
	}

	async update(
		id: string,
		updateFactionDto: UpdateFactionDto
	): Promise<Faction> {
		if (updateFactionDto.normalizedName) {
			const existing = await this.factionModel.findOne({
				normalizedName: updateFactionDto.normalizedName,
				_id: { $ne: id }
			});

			if (existing) {
				throw new ConflictException(
					"Faction with this normalized name already exists"
				);
			}
		}

		const faction = await this.factionModel
			.findByIdAndUpdate(id, updateFactionDto, { new: true })
			.exec();

		if (!faction) {
			throw new NotFoundException(`Faction with ID ${id} not found`);
		}

		return faction;
	}

	async remove(id: string): Promise<Faction> {
		const faction = await this.factionModel.findByIdAndDelete(id).exec();
		if (!faction) {
			throw new NotFoundException(`Faction with ID ${id} not found`);
		}
		return faction;
	}
}
