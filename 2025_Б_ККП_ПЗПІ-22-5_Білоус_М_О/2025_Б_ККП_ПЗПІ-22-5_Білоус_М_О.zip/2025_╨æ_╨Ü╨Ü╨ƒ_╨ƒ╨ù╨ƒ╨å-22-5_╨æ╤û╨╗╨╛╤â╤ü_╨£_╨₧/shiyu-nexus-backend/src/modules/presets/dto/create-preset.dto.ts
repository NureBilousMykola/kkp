import { Type } from "class-transformer";
import {
	IsArray,
	IsBoolean,
	IsEnum,
	IsMongoId,
	IsNumber,
	IsOptional,
	IsString,
	Max,
	Min,
	ValidateNested
} from "class-validator";

class RestartsDto {
	@IsNumber()
	@Min(0)
	freeRestarts: number;

	@IsNumber()
	@Min(0)
	paidRestarts: number;

	@IsNumber()
	@Min(0)
	timePenalty: number;
}

class GeneralRulesDto {
	@IsNumber()
	@Min(1)
	minCharacters: number;

	@IsNumber()
	maxCharacters: number;

	@IsNumber()
	@Min(0)
	minCost: number;

	@IsNumber()
	maxCost: number;

	@IsArray()
	@IsNumber({}, { each: true })
	@Min(1, { each: true })
	@Max(7, { each: true })
	allowedStages: number[];

	@IsNumber()
	@Min(0)
	costDifferenceForPreban: number;

	@IsBoolean()
	allowMirrorPicks: boolean;

	@ValidateNested()
	@Type(() => RestartsDto)
	restarts: RestartsDto;
}

class RoomConstraintDto {
	@IsNumber()
	@Min(1)
	@Max(2)
	roomId: number;

	@IsArray()
	@IsMongoId({ each: true })
	bannedAgents: string[];

	@IsArray()
	@IsOptional()
	@IsEnum(["attack", "anomaly", "defense", "stun", "support"], { each: true })
	bannedSpecialties?: string[];

	@IsArray()
	@IsOptional()
	@IsEnum(["physical", "fire", "ice", "ether", "electric", "frost"], {
		each: true
	})
	bannedAttributes?: string[];
}

class StageConstraintDto {
	@IsNumber()
	@Min(1)
	@Max(7)
	stageId: number;

	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => RoomConstraintDto)
	roomConstraints: RoomConstraintDto[];
}

class AgentCostDto {
	@IsMongoId()
	agent: string;

	@ValidateNested()
	mindscapeCosts: Map<number, number>;
}

class EngineCostDto {
	@IsMongoId()
	engine: string;

	@ValidateNested()
	ascensionCosts: Map<number, number>;
}

class DraftPhaseDto {
	@IsEnum(["BAN", "PICK", "PREBANS", "STAGE_BAN", "STAGE_PICK"])
	type: string;

	@IsNumber()
	@Min(1)
	@Max(2)
	player: number;

	@IsNumber()
	@Min(1)
	count: number;

	@IsNumber()
	@Min(0)
	timeLimit: number;
}

export class CreatePresetDto {
	@IsString()
	name: string;

	@IsString()
	@IsOptional()
	description?: string;

	@ValidateNested()
	@Type(() => GeneralRulesDto)
	rules: GeneralRulesDto;

	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => StageConstraintDto)
	constraints: StageConstraintDto[];

	@IsArray()
	@IsMongoId({ each: true })
	@IsOptional()
	pickableAgents?: string[];

	// Cost system reference (new approach)
	@IsMongoId()
	@IsOptional()
	costSystem?: string;

	// Legacy cost fields (for backward compatibility)
	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => AgentCostDto)
	@IsOptional()
	agentCosts?: AgentCostDto[];

	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => EngineCostDto)
	@IsOptional()
	engineCosts?: EngineCostDto[];

	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => DraftPhaseDto)
	draftFlow: DraftPhaseDto[];
}
