import { IsMongoId, IsOptional } from "class-validator";

export class QueryPresetDto {
	@IsOptional()
	@IsMongoId()
	createdBy?: string;
}
