import { CreatePresetDto } from "@modules/presets/dto/create-preset.dto";
import { PartialType } from "@nestjs/mapped-types";

export class UpdatePresetDto extends PartialType(CreatePresetDto) {}
