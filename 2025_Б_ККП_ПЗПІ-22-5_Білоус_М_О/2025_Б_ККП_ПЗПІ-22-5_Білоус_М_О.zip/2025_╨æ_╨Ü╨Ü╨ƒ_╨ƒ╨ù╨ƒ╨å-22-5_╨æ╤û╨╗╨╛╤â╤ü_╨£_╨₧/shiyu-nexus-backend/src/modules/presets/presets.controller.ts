import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	Query,
	Request,
	UseGuards
} from "@nestjs/common";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { Public } from "../users/decorators/public.decorator";
import { CreatePresetDto } from "./dto/create-preset.dto";
import { QueryPresetDto } from "./dto/query-preset.dto";
import { UpdatePresetDto } from "./dto/update-preset.dto";
import { PresetsService } from "./presets.service";

@Controller("presets")
@UseGuards(JwtAuthGuard)
export class PresetsController {
	constructor(private readonly presetsService: PresetsService) {}

	@Post()
	async create(@Body() createPresetDto: CreatePresetDto, @Request() req) {
		return this.presetsService.create(createPresetDto, req.user.userId);
	}

	@Public()
	@Get()
	async findAll(@Query() query: QueryPresetDto) {
		return this.presetsService.findAll(query);
	}

	@Public()
	@Get(":id")
	async findOne(@Param("id") id: string) {
		return this.presetsService.findOne(id);
	}

	@Patch(":id")
	async update(
		@Param("id") id: string,
		@Body() updatePresetDto: UpdatePresetDto,
		@Request() req
	) {
		return this.presetsService.update(
			id,
			updatePresetDto,
			req.user.userId,
			req.user.role
		);
	}

	@Delete(":id")
	async remove(@Param("id") id: string, @Request() req) {
		return this.presetsService.remove(id, req.user.userId, req.user.role);
	}

	@Get("user/created")
	async findUserCreated(@Request() req) {
		return this.presetsService.findAll({ createdBy: req.user.userId });
	}
}
