import { DraftPreset, DraftPresetSchema } from "@/schemas/draft-preset.schema";
import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { AgentsModule } from "../agents/agents.module";
import { CostSystemsModule } from "../cost-systems/cost-systems.module";
import { EnginesModule } from "../engines/engines.module";
import { PresetsController } from "./presets.controller";
import { PresetsService } from "./presets.service";

@Module({
	imports: [
		MongooseModule.forFeature([
			{ name: DraftPreset.name, schema: DraftPresetSchema }
		]),
		AgentsModule,
		EnginesModule,
		CostSystemsModule
	],
	controllers: [PresetsController],
	providers: [PresetsService],
	exports: [PresetsService]
})
export class PresetsModule {}
