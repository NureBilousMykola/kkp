import { DraftPreset, PresetDocument } from "@/schemas/draft-preset.schema";
import {
	BadRequestException,
	ConflictException,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { UserRole } from "@shared/enums/user-role.enum";
import { Model, Types } from "mongoose";
import { AgentsService } from "../agents/agents.service";
import { EnginesService } from "../engines/engines.service";
import { CostSystemsService } from "../cost-systems/cost-systems.service";
import { CreatePresetDto } from "./dto/create-preset.dto";
import { QueryPresetDto } from "./dto/query-preset.dto";
import { UpdatePresetDto } from "./dto/update-preset.dto";

@Injectable()
export class PresetsService {
	constructor(
		@InjectModel(DraftPreset.name) private presetModel: Model<PresetDocument>,
		private agentsService: AgentsService,
		private enginesService: EnginesService,
		private costSystemsService: CostSystemsService
	) {}

	async create(
		createPresetDto: CreatePresetDto,
		userId: string
	): Promise<PresetDocument> {
		await this.validatePresetData(createPresetDto);
		await this.validateDraftFlow(createPresetDto.draftFlow);

		const existing = await this.presetModel.findOne({
			name: createPresetDto.name
		});
		if (existing) {
			throw new ConflictException("Preset with this name already exists");
		}

		const preset = new this.presetModel({
			...createPresetDto,
			createdBy: new Types.ObjectId(userId),
			version: 1
		});

		return preset.save();
	}

	async findAll(query: QueryPresetDto = {}): Promise<PresetDocument[]> {
		const filter: any = {};

		if (query.createdBy) {
			filter.createdBy = new Types.ObjectId(query.createdBy);
		}

		return this.presetModel
			.find(filter)
			.populate("createdBy", "username")
			.populate("pickableAgents")
			.populate("constraints.roomConstraints.bannedAgents")
			.populate("costSystem", "name description isDefault")
			.populate("agentCosts.agent")
			.populate("engineCosts.engine")
			.exec();
	}

	async findOne(id: string): Promise<PresetDocument> {
		const preset = await this.presetModel
			.findById(id)
			.populate("createdBy", "username")
			.populate("pickableAgents")
			.populate("constraints.roomConstraints.bannedAgents")
			.populate("costSystem")
			.populate("agentCosts.agent")
			.populate("engineCosts.engine")
			.exec();

		if (!preset) {
			throw new NotFoundException(`Preset with ID ${id} not found`);
		}

		return preset;
	}

	async update(
		id: string,
		updatePresetDto: UpdatePresetDto,
		userId: string,
		userRole: UserRole
	): Promise<PresetDocument> {
		const preset = await this.presetModel.findById(id);
		if (!preset) {
			throw new NotFoundException(`Preset with ID ${id} not found`);
		}

		if (preset.createdBy.toString() !== userId && userRole !== UserRole.ADMIN) {
			throw new BadRequestException("No permission to update this preset");
		}

		if (updatePresetDto.name) {
			const existing = await this.presetModel.findOne({
				name: updatePresetDto.name,
				_id: { $ne: id }
			});

			if (existing) {
				throw new ConflictException("Preset with this name already exists");
			}
		}

		if (updatePresetDto.rules || updatePresetDto.draftFlow) {
			await this.validatePresetData(updatePresetDto as CreatePresetDto);
			await this.validateDraftFlow(
				updatePresetDto.draftFlow || preset.draftFlow
			);
		}

		const updatedData = {
			...updatePresetDto,
			version: preset.version + 1
		};

		const updatedPreset = await this.presetModel
			.findByIdAndUpdate(id, updatedData, { new: true })
			.populate("createdBy", "username")
			.populate("pickableAgents")
			.populate("constraints.roomConstraints.bannedAgents")
			.populate("costSystem", "name description isDefault")
			.populate("agentCosts.agent")
			.populate("engineCosts.engine")
			.exec();

		if (!updatedPreset) {
			throw new NotFoundException(`Preset with ID ${id} not found`);
		}

		return updatedPreset;
	}

	async remove(
		id: string,
		userId: string,
		userRole: UserRole
	): Promise<PresetDocument> {
		const preset = await this.presetModel.findById(id);
		if (!preset) {
			throw new NotFoundException(`Preset with ID ${id} not found`);
		}

		if (preset.createdBy.toString() !== userId && userRole !== UserRole.ADMIN) {
			throw new BadRequestException("No permission to delete this preset");
		}

		return this.presetModel.findByIdAndDelete(id);
	}

	private async validatePresetData(dto: CreatePresetDto): Promise<void> {
		const availableStages = new Set(dto.rules.allowedStages);
		for (const constraint of dto.constraints) {
			if (!availableStages.has(constraint.stageId)) {
				throw new BadRequestException(
					`Stage ${constraint.stageId} is not in allowedStages`
				);
			}

			const roomIds = new Set(constraint.roomConstraints.map((r) => r.roomId));
			if (roomIds.size !== constraint.roomConstraints.length) {
				throw new BadRequestException(
					`Duplicate room configurations for stage ${constraint.stageId}`
				);
			}
		}

		if (dto.pickableAgents) {
			for (const agentId of dto.pickableAgents) {
				const agent = await this.agentsService.findOne(agentId);
				if (!agent.isReleased) {
					throw new BadRequestException(`Agent ${agent.name} is not released`);
				}
			}
		}

		// Validate cost system if provided
		if (dto.costSystem) {
			await this.costSystemsService.findOne(dto.costSystem);
		}

		// Legacy cost validation (for backward compatibility)
		if (dto.agentCosts) {
			for (const agentCost of dto.agentCosts) {
				const agent = await this.agentsService.findOne(agentCost.agent);
				if (!agent) {
					throw new BadRequestException(`Agent ${agentCost.agent} not found`);
				}

				for (const [mindscape, costValue] of Object.entries(
					agentCost.mindscapeCosts
				)) {
					const mindscapeNum = Number(mindscape);
					const costNum = Number(costValue);

					if (mindscapeNum < 0 || mindscapeNum > 6) {
						throw new BadRequestException(
							`Invalid mindscape level: ${mindscapeNum}`
						);
					}
					if (costNum < 0) {
						throw new BadRequestException(
							`Invalid cost for mindscape ${mindscapeNum}: ${costNum}`
						);
					}
				}
			}
		}

		if (dto.engineCosts) {
			for (const engineCost of dto.engineCosts) {
				const engine = await this.enginesService.findOne(engineCost.engine);
				if (!engine) {
					throw new BadRequestException(
						`Engine ${engineCost.engine} not found`
					);
				}

				for (const [ascension, costValue] of Object.entries(
					engineCost.ascensionCosts
				)) {
					const ascensionNum = Number(ascension);
					const costNum = Number(costValue);

					if (ascensionNum < 1 || ascensionNum > 5) {
						throw new BadRequestException(
							`Invalid ascension level: ${ascensionNum}`
						);
					}
					if (costNum < 0) {
						throw new BadRequestException(
							`Invalid cost for ascension ${ascensionNum}: ${costNum}`
						);
					}
				}
			}
		}
	}

	private validateDraftFlow(draftFlow: any[]): void {
		if (!Array.isArray(draftFlow) || draftFlow.length === 0) {
			throw new BadRequestException("Draft flow must be a non-empty array");
		}

		for (const phase of draftFlow) {
			if (
				!["BAN", "PICK", "PREBANS", "STAGE_BAN", "STAGE_PICK"].includes(
					phase.type
				)
			) {
				throw new BadRequestException(`Invalid phase type: ${phase.type}`);
			}

			if (![1, 2].includes(phase.player)) {
				throw new BadRequestException(`Invalid player: ${phase.player}`);
			}

			if (!Number.isInteger(phase.count) || phase.count < 1) {
				throw new BadRequestException(`Invalid count: ${phase.count}`);
			}

			if (!Number.isInteger(phase.timeLimit) || phase.timeLimit < 1) {
				throw new BadRequestException(`Invalid time limit: ${phase.timeLimit}`);
			}
		}
	}
}
