import { ApiProperty } from "@nestjs/swagger";
import { TournamentFormat } from "@schemas/tournament.schema";
import { Type } from "class-transformer";
import {
	IsArray,
	IsBoolean,
	IsDate,
	IsEnum,
	IsMongoId,
	IsNotEmpty,
	IsNumber,
	IsOptional,
	IsString,
	Max,
	Min,
	MinLength,
	ValidateIf
} from "class-validator";

export class CreateTournamentDto {
	@ApiProperty({
		description: "Name of the tournament",
		example: "Summer Championship 2023"
	})
	@IsString()
	@IsNotEmpty()
	@MinLength(3)
	name: string;

	@ApiProperty({
		description: "Description of the tournament",
		example: "The official summer championship tournament for 2023"
	})
	@IsString()
	@IsOptional()
	description?: string;

	@ApiProperty({
		description: "ID of the draft preset to use for the tournament",
		example: "60d21b4667d0d8992e610c86"
	})
	@IsMongoId()
	draftPresetId: string;

	@ApiProperty({
		description: "Format of the tournament",
		enum: TournamentFormat,
		example: TournamentFormat.SINGLE_ELIMINATION
	})
	@IsEnum(TournamentFormat)
	format: TournamentFormat;

	@ApiProperty({
		description: "Maximum number of participants",
		example: 16,
		minimum: 4
	})
	@IsNumber()
	@Min(4)
	@IsOptional()
	maxParticipants?: number;

	@ApiProperty({
		description: "Best of N games for each match",
		example: 3,
		minimum: 1,
		maximum: 7
	})
	@IsNumber()
	@Min(1)
	@Max(7)
	@IsOptional()
	bestOf?: number;

	@ApiProperty({
		description: "Registration start time",
		example: "2023-06-01T00:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	registrationStartTime: Date;

	@ApiProperty({
		description: "Registration end time",
		example: "2023-06-15T00:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	registrationEndTime: Date;

	@ApiProperty({
		description: "Tournament start time",
		example: "2023-06-20T00:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	tournamentStartTime: Date;

	@ApiProperty({
		description: "Whether check-in is required",
		example: true
	})
	@IsBoolean()
	@IsOptional()
	requireCheckin?: boolean;

	@ApiProperty({
		description: "Check-in start time (required if requireCheckin is true)",
		example: "2023-06-19T18:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@ValidateIf((o) => o.requireCheckin === true)
	@IsNotEmpty()
	checkinStartTime?: Date;

	@ApiProperty({
		description: "Check-in end time (required if requireCheckin is true)",
		example: "2023-06-20T17:30:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@ValidateIf((o) => o.requireCheckin === true)
	@IsNotEmpty()
	checkinEndTime?: Date;

	@ApiProperty({
		description: "Whether the tournament is public",
		example: true
	})
	@IsBoolean()
	@IsOptional()
	isPublic?: boolean;

	@ApiProperty({
		description: "Password for private tournaments",
		example: "secret123"
	})
	@IsString()
	@ValidateIf((o) => o.isPublic === false)
	@IsNotEmpty()
	password?: string;

	@ApiProperty({
		description: "IDs of users to be assigned as moderators",
		type: [String],
		example: ["60d21b4667d0d8992e610c86", "60d21b4667d0d8992e610c87"]
	})
	@IsArray()
	@IsMongoId({ each: true })
	@IsOptional()
	moderatorIds?: string[];
}
