import { ApiProperty } from "@nestjs/swagger";
import { IsMongoId, IsNotEmpty } from "class-validator";

export class RegisterTournamentDto {
	@ApiProperty({
		description: "ID of the agent save to use for the tournament",
		example: "60d21b4667d0d8992e610c86"
	})
	@IsMongoId()
	@IsNotEmpty()
	agentSaveId: string;
}

export class JoinTournamentDto {
	@ApiProperty({
		description: "Password for private tournaments",
		example: "secret123"
	})
	@IsNotEmpty()
	password: string;
}
