import { ApiProperty } from "@nestjs/swagger";
import { Type } from "class-transformer";
import {
	IsBoolean,
	IsDate,
	IsEnum,
	IsMongoId,
	IsOptional
} from "class-validator";

export class UpdateMatchDto {
	@ApiProperty({
		description: "Winner of the match (1 for player1, 2 for player2)",
		example: 1,
		enum: [1, 2]
	})
	@IsEnum([1, 2])
	@IsOptional()
	winner?: number;

	@ApiProperty({
		description: "Whether the match is completed",
		example: true
	})
	@IsBoolean()
	@IsOptional()
	isCompleted?: boolean;

	@ApiProperty({
		description: "Scheduled time for the match",
		example: "2023-07-20T18:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@IsOptional()
	scheduledTime?: Date;

	@ApiProperty({
		description: "ID of the draft session for this match",
		example: "60d21b4667d0d8992e610c86"
	})
	@IsMongoId()
	@IsOptional()
	draftSessionId?: string;
}
