import { ApiProperty } from "@nestjs/swagger";
import { TournamentFormat, TournamentStatus } from "@schemas/tournament.schema";
import { Type } from "class-transformer";
import {
	IsArray,
	IsBoolean,
	IsDate,
	IsEnum,
	IsMongoId,
	IsNumber,
	IsOptional,
	IsString,
	Max,
	Min,
	MinLength,
	ValidateIf
} from "class-validator";

export class UpdateTournamentDto {
	@ApiProperty({
		description: "Name of the tournament",
		example: "Updated Summer Championship 2023"
	})
	@IsString()
	@IsOptional()
	@MinLength(3)
	name?: string;

	@ApiProperty({
		description: "Description of the tournament",
		example: "Updated description for the summer championship"
	})
	@IsString()
	@IsOptional()
	description?: string;

	@ApiProperty({
		description: "ID of the draft preset to use for the tournament",
		example: "60d21b4667d0d8992e610c86"
	})
	@IsMongoId()
	@IsOptional()
	draftPresetId?: string;

	@ApiProperty({
		description: "Status of the tournament",
		enum: TournamentStatus,
		example: TournamentStatus.REGISTRATION
	})
	@IsEnum(TournamentStatus)
	@IsOptional()
	status?: TournamentStatus;

	@ApiProperty({
		description: "Format of the tournament",
		enum: TournamentFormat,
		example: TournamentFormat.SINGLE_ELIMINATION
	})
	@IsEnum(TournamentFormat)
	@IsOptional()
	format?: TournamentFormat;

	@ApiProperty({
		description: "Maximum number of participants",
		example: 32,
		minimum: 4
	})
	@IsNumber()
	@Min(4)
	@IsOptional()
	maxParticipants?: number;

	@ApiProperty({
		description: "Best of N games for each match",
		example: 5,
		minimum: 1,
		maximum: 7
	})
	@IsNumber()
	@Min(1)
	@Max(7)
	@IsOptional()
	bestOf?: number;

	@ApiProperty({
		description: "Registration start time",
		example: "2023-07-01T00:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@IsOptional()
	registrationStartTime?: Date;

	@ApiProperty({
		description: "Registration end time",
		example: "2023-07-15T00:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@IsOptional()
	registrationEndTime?: Date;

	@ApiProperty({
		description: "Tournament start time",
		example: "2023-07-20T00:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@IsOptional()
	tournamentStartTime?: Date;

	@ApiProperty({
		description: "Whether check-in is required",
		example: false
	})
	@IsBoolean()
	@IsOptional()
	requireCheckin?: boolean;

	@ApiProperty({
		description: "Check-in start time",
		example: "2023-07-19T18:00:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@IsOptional()
	checkinStartTime?: Date;

	@ApiProperty({
		description: "Check-in end time",
		example: "2023-07-20T17:30:00.000Z"
	})
	@IsDate()
	@Type(() => Date)
	@IsOptional()
	checkinEndTime?: Date;

	@ApiProperty({
		description: "Whether the tournament is public",
		example: false
	})
	@IsBoolean()
	@IsOptional()
	isPublic?: boolean;

	@ApiProperty({
		description: "Password for private tournaments",
		example: "newsecret123"
	})
	@IsString()
	@ValidateIf((o) => o.isPublic === false)
	@IsOptional()
	password?: string;

	@ApiProperty({
		description: "IDs of users to be assigned as moderators",
		type: [String],
		example: ["60d21b4667d0d8992e610c86", "60d21b4667d0d8992e610c87"]
	})
	@IsArray()
	@IsMongoId({ each: true })
	@IsOptional()
	moderatorIds?: string[];
}
