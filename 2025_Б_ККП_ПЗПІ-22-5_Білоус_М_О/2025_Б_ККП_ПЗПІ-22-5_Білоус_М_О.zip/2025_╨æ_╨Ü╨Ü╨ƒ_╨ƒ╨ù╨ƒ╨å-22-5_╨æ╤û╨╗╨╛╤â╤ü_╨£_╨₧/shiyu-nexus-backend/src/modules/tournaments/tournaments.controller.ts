import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	Query,
	Request,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiQuery, ApiResponse, ApiTags } from "@nestjs/swagger";
import { TournamentStatus } from "@schemas/tournament.schema";
import { Permissions as PermissionsList } from "@shared/constants/permissions.constants";
import { Permissions } from "../users/decorators/permissions.decorator";
import { JwtAuthGuard } from "../users/guards/jwt-auth.guard";
import { PermissionsGuard } from "../users/guards/permissions.guard";
import { CreateTournamentDto } from "./dto/create-tournament.dto";
import { RegisterTournamentDto } from "./dto/register-tournament.dto";
import { UpdateMatchDto } from "./dto/update-match.dto";
import { UpdateTournamentDto } from "./dto/update-tournament.dto";
import { TournamentsService } from "./tournaments.service";

@ApiTags("tournaments")
@Controller("tournaments")
export class TournamentsController {
	constructor(private readonly tournamentsService: TournamentsService) {}

	@Post()
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Create a new tournament" })
	@ApiResponse({ status: 201, description: "Tournament created successfully" })
	create(
		@Request() req: any,
		@Body(ValidationPipe) createTournamentDto: CreateTournamentDto
	) {
		return this.tournamentsService.create(req.user.userId, createTournamentDto);
	}

	@Get()
	@ApiOperation({ summary: "Get all tournaments" })
	@ApiResponse({ status: 200, description: "Returns all tournaments" })
	@ApiQuery({ name: "status", enum: TournamentStatus, required: false })
	@ApiQuery({ name: "organizerId", type: String, required: false })
	findAll(
		@Query("status") status?: TournamentStatus,
		@Query("organizerId") organizerId?: string,
		@Request() req?: any
	) {
		const userId = req?.user?.userId;
		return this.tournamentsService.findAll({ status, organizerId, userId });
	}

	@Get(":id")
	@ApiOperation({ summary: "Get tournament by ID" })
	@ApiResponse({ status: 200, description: "Returns the tournament" })
	@ApiResponse({ status: 404, description: "Tournament not found" })
	findOne(@Param("id") id: string) {
		return this.tournamentsService.findOne(id);
	}

	@Patch(":id")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Update tournament" })
	@ApiResponse({ status: 200, description: "Tournament updated successfully" })
	@ApiResponse({ status: 404, description: "Tournament not found" })
	update(
		@Param("id") id: string,
		@Request() req: any,
		@Body(ValidationPipe) updateTournamentDto: UpdateTournamentDto
	) {
		return this.tournamentsService.update(
			id,
			req.user.userId,
			updateTournamentDto
		);
	}

	@Delete(":id")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Delete tournament" })
	@ApiResponse({ status: 200, description: "Tournament deleted successfully" })
	@ApiResponse({ status: 404, description: "Tournament not found" })
	remove(@Param("id") id: string, @Request() req: any) {
		return this.tournamentsService.remove(id, req.user.userId);
	}

	@Post(":id/register")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Register for a tournament" })
	@ApiResponse({ status: 200, description: "Registered successfully" })
	@ApiResponse({ status: 400, description: "Registration failed" })
	register(
		@Param("id") id: string,
		@Request() req: any,
		@Body(ValidationPipe) registerDto: RegisterTournamentDto
	) {
		return this.tournamentsService.register(id, req.user.userId, registerDto);
	}

	@Post(":id/unregister")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Unregister from a tournament" })
	@ApiResponse({ status: 200, description: "Unregistered successfully" })
	@ApiResponse({ status: 400, description: "Unregistration failed" })
	unregister(@Param("id") id: string, @Request() req: any) {
		return this.tournamentsService.unregister(id, req.user.userId);
	}

	@Post(":id/checkin")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Check in for a tournament" })
	@ApiResponse({ status: 200, description: "Checked in successfully" })
	@ApiResponse({ status: 400, description: "Check-in failed" })
	checkin(@Param("id") id: string, @Request() req: any) {
		return this.tournamentsService.checkin(id, req.user.userId);
	}

	@Post(":id/generate-brackets")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Generate tournament brackets" })
	@ApiResponse({ status: 200, description: "Brackets generated successfully" })
	@ApiResponse({ status: 400, description: "Bracket generation failed" })
	generateBrackets(@Param("id") id: string, @Request() req: any) {
		return this.tournamentsService.generateBrackets(id, req.user.userId);
	}

	@Patch(":id/matches/:matchId")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Update match details" })
	@ApiResponse({ status: 200, description: "Match updated successfully" })
	@ApiResponse({ status: 404, description: "Match not found" })
	updateMatch(
		@Param("id") id: string,
		@Param("matchId") matchId: string,
		@Request() req: any,
		@Body(ValidationPipe) updateMatchDto: UpdateMatchDto
	) {
		return this.tournamentsService.updateMatch(
			id,
			matchId,
			req.user.userId,
			updateMatchDto
		);
	}

	@Post(":id/matches/:matchId/create-draft")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Create draft session for a match" })
	@ApiResponse({
		status: 201,
		description: "Draft session created successfully"
	})
	@ApiResponse({ status: 400, description: "Draft session creation failed" })
	createDraftSession(
		@Param("id") id: string,
		@Param("matchId") matchId: string,
		@Request() req: any
	) {
		return this.tournamentsService.createDraftSession(
			id,
			matchId,
			req.user.userId
		);
	}

	@Get(":id/matches/:matchId/agent-saves")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Get agent saves for a tournament match" })
	@ApiResponse({
		status: 200,
		description: "Returns agent saves for the match"
	})
	getMatchAgentSaves(
		@Param("id") id: string,
		@Param("matchId") matchId: string,
		@Request() req: any
	) {
		return this.tournamentsService.getMatchAgentSaves(
			id,
			matchId,
			req.user.userId
		);
	}

	// Admin routes
	@Get("admin/all")
	@UseGuards(JwtAuthGuard, PermissionsGuard)
	@Permissions(PermissionsList.TOURNAMENT_MANAGE)
	@ApiOperation({ summary: "Get all tournaments (admin)" })
	@ApiResponse({ status: 200, description: "Returns all tournaments" })
	findAllAdmin() {
		return this.tournamentsService.findAll({});
	}
}
