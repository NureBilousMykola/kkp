import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { DraftPreset, DraftPresetSchema } from "@schemas/draft-preset.schema";
import {
	DraftSession,
	DraftSessionSchema
} from "@schemas/draft-session.schema";
import { Tournament, TournamentSchema } from "@schemas/tournament.schema";
import { User, UserSchema } from "@schemas/user.schema";
import { DraftModule } from "../draft/draft.module";
import { UsersModule } from "../users/users.module";
import { TournamentsController } from "./tournaments.controller";
import { TournamentsService } from "./tournaments.service";

@Module({
	imports: [
		MongooseModule.forFeature([
			{ name: Tournament.name, schema: TournamentSchema },
			{ name: User.name, schema: UserSchema },
			{ name: DraftPreset.name, schema: DraftPresetSchema },
			{ name: DraftSession.name, schema: DraftSessionSchema }
		]),
		DraftModule,
		UsersModule
	],
	controllers: [TournamentsController],
	providers: [TournamentsService],
	exports: [TournamentsService]
})
export class TournamentsModule {}
