import {
	BadRequestException,
	ConflictException,
	ForbiddenException,
	Injectable,
	NotFoundException
} from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { DraftPreset } from "@schemas/draft-preset.schema";
import { DraftSession } from "@schemas/draft-session.schema";
import {
	Tournament,
	TournamentFormat,
	TournamentStatus
} from "@schemas/tournament.schema";
import { User } from "@schemas/user.schema";
import { Model, Types } from "mongoose";
import { DraftService } from "../draft/draft.service";
import { UsersService } from "../users/users.service";
import { CreateTournamentDto } from "./dto/create-tournament.dto";
import { RegisterTournamentDto } from "./dto/register-tournament.dto";
import { UpdateMatchDto } from "./dto/update-match.dto";
import { UpdateTournamentDto } from "./dto/update-tournament.dto";

@Injectable()
export class TournamentsService {
	constructor(
		@InjectModel(Tournament.name)
		private tournamentModel: Model<Tournament>,
		@InjectModel(User.name) private userModel: Model<User>,
		@InjectModel(DraftPreset.name) private presetModel: Model<DraftPreset>,
		@InjectModel(DraftSession.name)
		private sessionModel: Model<DraftSession>,
		private draftService: DraftService,
		private usersService: UsersService
	) {}

	async create(
		userId: string,
		createTournamentDto: CreateTournamentDto
	): Promise<Tournament> {
		// Validate draft preset exists
		const preset = await this.presetModel.findById(
			createTournamentDto.draftPresetId
		);
		if (!preset) {
			throw new NotFoundException("Draft preset not found");
		}

		// Validate dates
		const now = new Date();
		if (createTournamentDto.registrationStartTime < now) {
			throw new BadRequestException(
				"Registration start time must be in the future"
			);
		}
		if (
			createTournamentDto.registrationEndTime <=
			createTournamentDto.registrationStartTime
		) {
			throw new BadRequestException(
				"Registration end time must be after registration start time"
			);
		}
		if (
			createTournamentDto.tournamentStartTime <=
			createTournamentDto.registrationEndTime
		) {
			throw new BadRequestException(
				"Tournament start time must be after registration end time"
			);
		}

		// Validate check-in times if required
		if (createTournamentDto.requireCheckin) {
			if (
				!createTournamentDto.checkinStartTime ||
				!createTournamentDto.checkinEndTime
			) {
				throw new BadRequestException(
					"Check-in start and end times are required when check-in is enabled"
				);
			}
			if (
				createTournamentDto.checkinStartTime <=
				createTournamentDto.registrationEndTime
			) {
				throw new BadRequestException(
					"Check-in start time must be after registration end time"
				);
			}
			if (
				createTournamentDto.checkinEndTime <=
				createTournamentDto.checkinStartTime
			) {
				throw new BadRequestException(
					"Check-in end time must be after check-in start time"
				);
			}
			if (
				createTournamentDto.tournamentStartTime <=
				createTournamentDto.checkinEndTime
			) {
				throw new BadRequestException(
					"Tournament start time must be after check-in end time"
				);
			}
		}

		// Validate moderators exist
		if (
			createTournamentDto.moderatorIds &&
			createTournamentDto.moderatorIds.length > 0
		) {
			const moderatorCount = await this.userModel.countDocuments({
				_id: {
					$in: createTournamentDto.moderatorIds.map(
						(id) => new Types.ObjectId(id)
					)
				}
			});
			if (moderatorCount !== createTournamentDto.moderatorIds.length) {
				throw new BadRequestException("One or more moderators not found");
			}
		}

		// Create tournament
		const tournament = new this.tournamentModel({
			...createTournamentDto,
			organizerId: new Types.ObjectId(userId),
			status: TournamentStatus.REGISTRATION,
			moderatorIds: createTournamentDto.moderatorIds?.map(
				(id) => new Types.ObjectId(id)
			),
			maxParticipants: createTournamentDto.maxParticipants || 8,
			bestOf: createTournamentDto.bestOf || 1,
			isPublic: createTournamentDto.isPublic ?? true
		});

		return tournament.save();
	}

	async findAll(query: any = {}): Promise<Tournament[]> {
		const filter: any = {};

		// Filter by status if provided
		if (query.status) {
			filter.status = query.status;
		}

		// Filter by organizer if provided
		if (query.organizerId) {
			filter.organizerId = new Types.ObjectId(query.organizerId.toString());
		}

		// Only show public tournaments or ones where the user is organizer/moderator
		if (query.userId) {
			filter.$or = [
				{ isPublic: true },
				{ organizerId: new Types.ObjectId(query.userId.toString()) },
				{ moderatorIds: new Types.ObjectId(query.userId.toString()) }
			];
		} else {
			filter.isPublic = true;
		}

		return this.tournamentModel
			.find(filter)
			.populate("organizerId", "username")
			.populate("draftPresetId", "name")
			.sort({ tournamentStartTime: -1 })
			.exec();
	}

	async findOne(id: string): Promise<Tournament> {
		const tournament = await this.tournamentModel
			.findById(id)
			.populate("organizerId", "username")
			.populate("moderatorIds", "username")
			.populate("draftPresetId")
			.populate("registrations.userId", "username")
			.populate({
				path: "matches",
				populate: [
					{ path: "player1Id", select: "username" },
					{ path: "player2Id", select: "username" }
				]
			})
			.exec();

		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		return tournament;
	}

	async update(
		id: string,
		userId: string,
		updateTournamentDto: UpdateTournamentDto
	): Promise<Tournament> {
		const tournament = await this.tournamentModel.findById(id);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if user is authorized to update the tournament
		if (
			tournament.organizerId.toString() !== userId &&
			!tournament.moderatorIds?.some((modId) => modId.toString() === userId)
		) {
			throw new ForbiddenException(
				"You are not authorized to update this tournament"
			);
		}

		// Prevent updates to tournaments that have already started
		if (
			tournament.status !== TournamentStatus.REGISTRATION &&
			(updateTournamentDto.format ||
				updateTournamentDto.maxParticipants ||
				updateTournamentDto.draftPresetId)
		) {
			throw new BadRequestException(
				"Cannot update format, max participants, or draft preset after registration has ended"
			);
		}

		// Validate draft preset if changing
		if (updateTournamentDto.draftPresetId) {
			const preset = await this.presetModel.findById(
				updateTournamentDto.draftPresetId
			);
			if (!preset) {
				throw new NotFoundException("Draft preset not found");
			}
		}

		// Validate moderators if changing
		if (
			updateTournamentDto.moderatorIds &&
			updateTournamentDto.moderatorIds.length > 0
		) {
			const moderatorCount = await this.userModel.countDocuments({
				_id: {
					$in: updateTournamentDto.moderatorIds.map(
						(id) => new Types.ObjectId(id)
					)
				}
			});
			if (moderatorCount !== updateTournamentDto.moderatorIds.length) {
				throw new BadRequestException("One or more moderators not found");
			}
		}

		// Update tournament
		Object.assign(tournament, updateTournamentDto);

		// Update moderator IDs if provided
		if (updateTournamentDto.moderatorIds) {
			tournament.moderatorIds = updateTournamentDto.moderatorIds.map(
				(id) => new Types.ObjectId(id) as any
			);
		}

		return tournament.save();
	}

	async remove(id: string, userId: string): Promise<{ message: string }> {
		const tournament = await this.tournamentModel.findById(id);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if user is authorized to delete the tournament
		if (tournament.organizerId.toString() !== userId) {
			throw new ForbiddenException(
				"Only the tournament organizer can delete the tournament"
			);
		}

		// Prevent deletion of tournaments that have already started
		if (
			tournament.status !== TournamentStatus.REGISTRATION &&
			tournament.status !== TournamentStatus.CANCELLED
		) {
			throw new BadRequestException(
				"Cannot delete tournaments that have already started"
			);
		}

		await this.tournamentModel.findByIdAndDelete(id);
		return { message: "Tournament deleted successfully" };
	}

	async register(
		tournamentId: string,
		userId: string,
		registerDto: RegisterTournamentDto
	): Promise<Tournament> {
		const tournament = await this.tournamentModel.findById(tournamentId);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if tournament is in registration phase
		if (tournament.status !== TournamentStatus.REGISTRATION) {
			throw new BadRequestException("Tournament registration is closed");
		}

		// Check if tournament is full
		if (tournament.registrations.length >= tournament.maxParticipants) {
			throw new BadRequestException("Tournament is full");
		}

		// Check if user is already registered
		if (
			tournament.registrations.some((reg) => reg.userId.toString() === userId)
		) {
			throw new ConflictException(
				"You are already registered for this tournament"
			);
		}

		// Validate agent save
		const agentSave = await this.usersService.getAgentSave(
			userId,
			registerDto.agentSaveId
		);
		if (!agentSave) {
			throw new NotFoundException("Agent save not found");
		}

		// Calculate total agent cost
		const preset = await this.presetModel.findById(tournament.draftPresetId);
		if (!preset) {
			throw new NotFoundException("Draft preset not found");
		}

		// Calculate agent cost based on mindscape levels
		const totalAgentCost = await this.calculateAgentSaveCost(
			userId,
			registerDto.agentSaveId,
			preset
		);

		// Register user
		tournament.registrations.push({
			userId: new Types.ObjectId(userId) as any,
			agentSaveId: new Types.ObjectId(registerDto.agentSaveId) as any,
			isCheckedIn: false,
			registeredAt: new Date(),
			totalAgentCost,
			isEliminated: false,
			inLosersBracket: false
		});

		return tournament.save();
	}

	async unregister(tournamentId: string, userId: string): Promise<Tournament> {
		const tournament = await this.tournamentModel.findById(tournamentId);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if tournament is in registration phase
		if (tournament.status !== TournamentStatus.REGISTRATION) {
			throw new BadRequestException("Tournament registration is closed");
		}

		// Check if user is registered
		const registrationIndex = tournament.registrations.findIndex(
			(reg) => reg.userId.toString() === userId
		);

		if (registrationIndex === -1) {
			throw new BadRequestException(
				"You are not registered for this tournament"
			);
		}

		// Remove registration
		tournament.registrations.splice(registrationIndex, 1);
		return tournament.save();
	}

	async checkin(tournamentId: string, userId: string): Promise<Tournament> {
		const tournament = await this.tournamentModel.findById(tournamentId);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if check-in is required and open
		if (!tournament.requireCheckin) {
			throw new BadRequestException(
				"Check-in is not required for this tournament"
			);
		}

		const now = new Date();
		if (now < tournament.checkinStartTime || now > tournament.checkinEndTime) {
			throw new BadRequestException("Check-in is not currently open");
		}

		// Find user registration
		const registration = tournament.registrations.find(
			(reg) => reg.userId.toString() === userId
		);

		if (!registration) {
			throw new BadRequestException(
				"You are not registered for this tournament"
			);
		}

		// Update check-in status
		registration.isCheckedIn = true;
		registration.checkedInAt = now;

		return tournament.save();
	}

	async generateBrackets(
		tournamentId: string,
		userId: string
	): Promise<Tournament> {
		const tournament = await this.tournamentModel.findById(tournamentId);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if user is authorized
		if (
			tournament.organizerId.toString() !== userId &&
			!tournament.moderatorIds?.some((modId) => modId.toString() === userId)
		) {
			throw new ForbiddenException(
				"You are not authorized to generate brackets for this tournament"
			);
		}

		// Check if tournament is in registration phase
		if (tournament.status !== TournamentStatus.REGISTRATION) {
			throw new BadRequestException(
				"Brackets can only be generated during registration phase"
			);
		}

		// Check if there are enough participants
		if (tournament.registrations.length < 4) {
			throw new BadRequestException(
				"At least 4 participants are required to generate brackets"
			);
		}

		// Check if brackets are already generated
		if (tournament.bracketsGenerated) {
			throw new BadRequestException("Brackets have already been generated");
		}

		// Filter participants based on check-in status if required
		const participants = tournament.requireCheckin
			? tournament.registrations.filter((reg) => reg.isCheckedIn)
			: tournament.registrations;

		// Check if there are enough checked-in participants if check-in is required
		if (tournament.requireCheckin && participants.length < 4) {
			throw new BadRequestException(
				"At least 4 checked-in participants are required to generate brackets"
			);
		}

		// Generate brackets based on tournament format
		switch (tournament.format) {
			case "single_elimination":
				await this.generateSingleEliminationBracket(tournament, participants);
				break;
			case "double_elimination":
				await this.generateDoubleEliminationBracket(tournament, participants);
				break;
			case "round_robin":
				await this.generateRoundRobinBracket(tournament, participants);
				break;
			case "swiss":
				await this.generateSwissBracket(tournament, participants);
				break;
			default:
				throw new BadRequestException("Unsupported tournament format");
		}

		// Update tournament status
		tournament.status = TournamentStatus.ONGOING;
		tournament.bracketsGenerated = true;

		return tournament.save();
	}

	private async generateSingleEliminationBracket(
		tournament: Tournament,
		participants: any[]
	): Promise<void> {
		// Shuffle participants for random seeding
		const shuffledParticipants = this.shuffleArray([...participants]);

		// Calculate number of rounds
		const numParticipants = shuffledParticipants.length;
		const numRounds = Math.ceil(Math.log2(numParticipants));

		// Calculate perfect bracket size
		const perfectBracketSize = 2 ** numRounds;

		// Create matches array
		const matches = [];

		// First round matches with players and byes
		let matchNumber = 1;
		let round = 1;

		for (let i = 0; i < perfectBracketSize / 2; i++) {
			const player1Index = i;
			const player2Index = perfectBracketSize - 1 - i;

			const match: any = {
				_id: new Types.ObjectId(),
				matchNumber,
				round,
				isBye: false,
				isCompleted: false
			};

			// Assign player 1 if available
			if (player1Index < numParticipants) {
				match.player1Id = shuffledParticipants[player1Index].userId;
			}

			// Assign player 2 if available, otherwise it's a bye
			if (player2Index < numParticipants) {
				match.player2Id = shuffledParticipants[player2Index].userId;
			} else if (match.player1Id) {
				match.isBye = true;
				match.winner = 1;
				match.isCompleted = true;
			}

			matches.push(match);
			matchNumber++;
		}

		// Create remaining rounds of empty matches
		for (let r = 2; r <= numRounds; r++) {
			round = r;
			const roundMatches = 2 ** (numRounds - r);

			for (let i = 0; i < roundMatches; i++) {
				matches.push({
					_id: new Types.ObjectId(),
					matchNumber,
					round,
					isBye: false,
					isCompleted: false
				});
				matchNumber++;
			}
		}

		// Assign matches to tournament
		tournament.matches = matches;
	}

	private async generateDoubleEliminationBracket(
		tournament: Tournament,
		participants: any[]
	): Promise<void> {
		// Implementation for double elimination bracket
		const shuffledParticipants = this.shuffleArray([...participants]);
		const numParticipants = shuffledParticipants.length;
		const numRounds = Math.ceil(Math.log2(numParticipants));
		const perfectBracketSize = 2 ** numRounds;

		// Create matches array
		const matches = [];
		let matchNumber = 1;

		// Generate winners bracket (first round)
		let round = 1;
		for (let i = 0; i < perfectBracketSize / 2; i++) {
			const player1Index = i;
			const player2Index = perfectBracketSize - 1 - i;

			const match: any = {
				_id: new Types.ObjectId(),
				matchNumber,
				round,
				bracket: "winners",
				isBye: false,
				isCompleted: false
			};

			// Assign player 1 if available
			if (player1Index < numParticipants) {
				match.player1Id = shuffledParticipants[player1Index].userId;
			}

			// Assign player 2 if available, otherwise it's a bye
			if (player2Index < numParticipants) {
				match.player2Id = shuffledParticipants[player2Index].userId;
			} else if (match.player1Id) {
				match.isBye = true;
				match.winner = 1;
				match.isCompleted = true;
			}

			matches.push(match);
			matchNumber++;
		}

		// Create remaining rounds of winners bracket
		for (let r = 2; r <= numRounds; r++) {
			round = r;
			const roundMatches = 2 ** (numRounds - r);

			for (let i = 0; i < roundMatches; i++) {
				matches.push({
					_id: new Types.ObjectId(),
					matchNumber,
					round,
					bracket: "winners",
					isBye: false,
					isCompleted: false
				});
				matchNumber++;
			}
		}

		// Generate losers bracket
		// In a double elimination bracket, the losers bracket has 2*log2(n)-1 rounds
		const numLoserRounds = 2 * numRounds - 1;

		// First round of losers bracket receives losers from winners bracket round 1
		let loserRound = 1;
		const firstRoundWinnerMatches = matches.filter(
			(m) => m.round === 1 && m.bracket === "winners"
		);
		const numFirstRoundLoserMatches = Math.floor(
			firstRoundWinnerMatches.length / 2
		);

		for (let i = 0; i < numFirstRoundLoserMatches; i++) {
			matches.push({
				_id: new Types.ObjectId(),
				matchNumber,
				round: loserRound,
				bracket: "losers",
				isBye: false,
				isCompleted: false
				// Players will be filled in as matches in winners bracket are completed
			});
			matchNumber++;
		}

		// Remaining rounds of losers bracket
		for (let r = 2; r <= numLoserRounds; r++) {
			loserRound = r;
			// Alternating rounds: one round gets losers from winners bracket, next round is consolidation
			const isConsolidationRound = r % 2 === 0;
			const numMatchesInRound = isConsolidationRound
				? Math.floor(
						matches.filter((m) => m.round === r - 1 && m.bracket === "losers")
							.length / 2
					)
				: Math.floor(
						matches.filter(
							(m) =>
								m.round === Math.floor(r / 2) + 1 && m.bracket === "winners"
						).length / 2
					);

			for (let i = 0; i < numMatchesInRound; i++) {
				matches.push({
					_id: new Types.ObjectId(),
					matchNumber,
					round: loserRound,
					bracket: "losers",
					isBye: false,
					isCompleted: false
				});
				matchNumber++;
			}
		}

		// Final match (grand finals)
		matches.push({
			_id: new Types.ObjectId(),
			matchNumber,
			round: numRounds + 1, // One round after winners bracket final
			bracket: "finals",
			isBye: false,
			isCompleted: false
		});

		// Potential reset match if losers bracket winner wins the first finals match
		matches.push({
			_id: new Types.ObjectId(),
			matchNumber: matchNumber + 1,
			round: numRounds + 2, // Two rounds after winners bracket final
			bracket: "finals",
			isBye: false,
			isCompleted: false,
			isResetMatch: true
		});

		// Assign matches to tournament
		tournament.matches = matches;
	}

	private async generateRoundRobinBracket(
		tournament: Tournament,
		participants: any[]
	): Promise<void> {
		// Implementation for round robin format
		const matches = [];
		let matchNumber = 1;

		// Each participant plays against every other participant
		for (let i = 0; i < participants.length; i++) {
			for (let j = i + 1; j < participants.length; j++) {
				matches.push({
					_id: new Types.ObjectId(),
					matchNumber,
					round: 1, // All matches are considered round 1 in round robin
					player1Id: participants[i].userId,
					player2Id: participants[j].userId,
					isBye: false,
					isCompleted: false
				});
				matchNumber++;
			}
		}

		tournament.matches = matches;
	}

	private async generateSwissBracket(
		tournament: Tournament,
		participants: any[]
	): Promise<void> {
		// Implementation for Swiss format
		// Swiss system pairs players with similar records against each other

		const matches = [];
		let matchNumber = 1;

		// Determine number of rounds - typically log2(n) rounded up
		// For Swiss, we can do fewer rounds than single elimination
		const numParticipants = participants.length;
		const numRounds = Math.min(
			Math.ceil(Math.log2(numParticipants)),
			Math.floor(numParticipants / 2)
		);

		// Initialize player records for Swiss pairing
		const playerRecords = new Map();
		for (const participant of participants) {
			playerRecords.set(participant.userId.toString(), {
				userId: participant.userId,
				wins: 0,
				losses: 0,
				byes: 0,
				opponents: [],
				score: 0
			});
		}

		// Create first round matches - random pairing for first round
		const shuffledParticipants = this.shuffleArray([...participants]);
		this.createSwissRoundMatches(
			matches,
			shuffledParticipants,
			1,
			matchNumber,
			playerRecords
		);
		matchNumber += Math.ceil(numParticipants / 2);

		// Create placeholder matches for future rounds
		// In a real implementation, these would be generated dynamically as rounds progress
		for (let round = 2; round <= numRounds; round++) {
			// For demonstration, we'll create empty matches for future rounds
			// In a real implementation, these would be filled based on results from previous rounds
			const roundMatches = Math.floor(numParticipants / 2);

			for (let i = 0; i < roundMatches; i++) {
				matches.push({
					_id: new Types.ObjectId(),
					matchNumber: matchNumber + i,
					round,
					isBye: false,
					isCompleted: false
					// Players will be assigned when previous round completes
				});
			}

			// Handle odd number of players with a bye
			if (numParticipants % 2 !== 0) {
				matches.push({
					_id: new Types.ObjectId(),
					matchNumber: matchNumber + roundMatches,
					round,
					isBye: true,
					isCompleted: false
					// Player will be assigned when previous round completes
				});
			}

			matchNumber += Math.ceil(numParticipants / 2);
		}

		tournament.matches = matches;

		// Store player records in tournament metadata for future round pairings
		tournament.swissRecords = Array.from(playerRecords.values());
	}

	private createSwissRoundMatches(
		matches: any[],
		participants: any[],
		round: number,
		startMatchNumber: number,
		playerRecords: Map<string, any>
	): void {
		let matchNumber = startMatchNumber;

		// Create matches for this round
		for (let i = 0; i < participants.length; i += 2) {
			if (i + 1 < participants.length) {
				// Create a match between two players
				const player1Id = participants[i].userId;
				const player2Id = participants[i + 1].userId;

				matches.push({
					_id: new Types.ObjectId(),
					matchNumber,
					round,
					player1Id,
					player2Id,
					isBye: false,
					isCompleted: false
				});

				// Update player records to track opponents
				const player1Record = playerRecords.get(player1Id.toString());
				const player2Record = playerRecords.get(player2Id.toString());

				if (player1Record) player1Record.opponents.push(player2Id.toString());
				if (player2Record) player2Record.opponents.push(player1Id.toString());

				matchNumber++;
			} else {
				// Odd number of players, last player gets a bye
				const playerId = participants[i].userId;

				matches.push({
					_id: new Types.ObjectId(),
					matchNumber,
					round,
					player1Id: playerId,
					isBye: true,
					winner: 1,
					isCompleted: true
				});

				// Update player record with a bye
				const playerRecord = playerRecords.get(playerId.toString());
				if (playerRecord) {
					playerRecord.byes += 1;
					playerRecord.score += 1; // Typically a bye counts as a win
				}

				matchNumber++;
			}
		}
	}

	async updateMatch(
		tournamentId: string,
		matchId: string,
		userId: string,
		updateMatchDto: UpdateMatchDto
	): Promise<Tournament> {
		const tournament = await this.tournamentModel.findById(tournamentId);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if user is authorized
		if (
			tournament.organizerId.toString() !== userId &&
			!tournament.moderatorIds?.some((modId) => modId.toString() === userId)
		) {
			throw new ForbiddenException(
				"You are not authorized to update matches in this tournament"
			);
		}

		// Find the match
		const match = tournament.matches.find((m) => m._id.toString() === matchId);
		if (!match) {
			throw new NotFoundException("Match not found");
		}

		// Update match fields
		if (updateMatchDto.winner !== undefined) {
			match.winner = updateMatchDto.winner;
		}

		if (updateMatchDto.isCompleted !== undefined) {
			match.isCompleted = updateMatchDto.isCompleted;
		}

		if (updateMatchDto.scheduledTime !== undefined) {
			match.scheduledTime = updateMatchDto.scheduledTime;
		}

		if (updateMatchDto.draftSessionId !== undefined) {
			// Verify draft session exists
			const draftSession = await this.sessionModel.findById(
				updateMatchDto.draftSessionId
			);
			if (!draftSession) {
				throw new NotFoundException("Draft session not found");
			}
			match.draftSessionId = new Types.ObjectId(
				updateMatchDto.draftSessionId
			) as any;
		}

		// If match is completed with a winner, update next round matches
		if (match.isCompleted && match.winner) {
			await this.advanceWinnerToNextRound(tournament, match);

			// Check if tournament is completed
			const isCompleted = tournament.matches.every((m) => m.isCompleted);
			if (isCompleted) {
				tournament.status = TournamentStatus.COMPLETED;
				tournament.tournamentEndTime = new Date();
			}
		}

		return tournament.save();
	}

	private async advanceWinnerToNextRound(
		tournament: Tournament,
		match: any
	): Promise<void> {
		// Only applicable for elimination formats
		if (
			tournament.format !== TournamentFormat.SINGLE_ELIMINATION &&
			tournament.format !== TournamentFormat.DOUBLE_ELIMINATION
		) {
			return;
		}

		// Find the next match in the bracket
		const nextRound = match.round + 1;
		const matchesInCurrentRound = tournament.matches.filter(
			(m) => m.round === match.round
		);
		const matchIndexInRound = matchesInCurrentRound.findIndex(
			(m) => m._id.toString() === match._id.toString()
		);

		// Calculate the index of the next match
		const nextMatchIndex = Math.floor(matchIndexInRound / 2);

		// Find the next match
		const nextMatch = tournament.matches.find(
			(m) =>
				m.round === nextRound &&
				tournament.matches.filter((nm) => nm.round === nextRound).indexOf(m) ===
					nextMatchIndex
		);

		if (!nextMatch) {
			return; // No next match (final match)
		}

		// Determine if winner goes to player1 or player2 slot
		const isEvenIndexInRound = matchIndexInRound % 2 === 0;
		const winnerId = match.winner === 1 ? match.player1Id : match.player2Id;

		if (isEvenIndexInRound) {
			nextMatch.player1Id = winnerId;
		} else {
			nextMatch.player2Id = winnerId;
		}

		// If both players are assigned, the match is ready
		if (nextMatch.player1Id && nextMatch.player2Id) {
			// Match is ready to be played
			// Update match status to indicate it's ready for play
			nextMatch.isReady = true;

			// If this is a double elimination tournament, handle losers bracket advancement
			if (
				tournament.format === "double_elimination" &&
				match.bracket === "winners"
			) {
				// Find the appropriate losers bracket match to send the loser to
				await this.advanceLoserToLosersBracket(tournament, match);
			}

			// If this is a Swiss tournament, update player records
			if (
				(tournament.format as TournamentFormat) === TournamentFormat.SWISS &&
				tournament.swissRecords
			) {
				await this.updateSwissPlayerRecords(tournament, match);
			}
		}
	}

	async getMatchAgentSaves(
		tournamentId: string,
		matchId: string,
		userId: string
	): Promise<any> {
		const tournament = await this.tournamentModel.findById(tournamentId);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Find the match
		const match = tournament.matches.find((m) => m._id.toString() === matchId);
		if (!match) {
			throw new NotFoundException("Match not found");
		}

		// Check if user is authorized (player in the match, organizer, or moderator)
		const isPlayer =
			match.player1Id?.toString() === userId ||
			match.player2Id?.toString() === userId;
		const isOrganizer = tournament.organizerId.toString() === userId;
		const isModerator = tournament.moderatorIds?.some(
			(modId) => modId.toString() === userId
		);

		if (!isPlayer && !isOrganizer && !isModerator) {
			throw new ForbiddenException(
				"You are not authorized to view agent saves for this match"
			);
		}

		// Get player registrations to find their agent saves
		const player1Reg = tournament.registrations.find(
			(reg) => reg.userId.toString() === match.player1Id?.toString()
		);

		const player2Reg = tournament.registrations.find(
			(reg) => reg.userId.toString() === match.player2Id?.toString()
		);

		// Get agent save details
		const player1AgentSave = player1Reg?.agentSaveId
			? await this.usersService.getAgentSave(
					match.player1Id.toString(),
					player1Reg.agentSaveId.toString()
				)
			: null;

		const player2AgentSave = player2Reg?.agentSaveId
			? await this.usersService.getAgentSave(
					match.player2Id.toString(),
					player2Reg.agentSaveId.toString()
				)
			: null;

		return {
			player1: {
				userId: match.player1Id,
				agentSave: player1AgentSave
			},
			player2: {
				userId: match.player2Id,
				agentSave: player2AgentSave
			}
		};
	}

	async createDraftSession(
		tournamentId: string,
		matchId: string,
		userId: string
	): Promise<DraftSession> {
		const tournament = await this.tournamentModel.findById(tournamentId);
		if (!tournament) {
			throw new NotFoundException("Tournament not found");
		}

		// Check if user is authorized
		if (
			tournament.organizerId.toString() !== userId &&
			!tournament.moderatorIds?.some((modId) => modId.toString() === userId)
		) {
			throw new ForbiddenException(
				"You are not authorized to create draft sessions for this tournament"
			);
		}

		// Find the match
		const match = tournament.matches.find((m) => m._id.toString() === matchId);
		if (!match) {
			throw new NotFoundException("Match not found");
		}

		// Check if match has both players
		if (!match.player1Id || !match.player2Id) {
			throw new BadRequestException(
				"Match must have two players to create a draft session"
			);
		}

		// Check if match already has a draft session
		if (match.draftSessionId) {
			throw new ConflictException("Match already has a draft session");
		}

		// Get player registrations to find their agent saves
		const player1Reg = tournament.registrations.find(
			(reg) => reg.userId.toString() === match.player1Id.toString()
		);

		const player2Reg = tournament.registrations.find(
			(reg) => reg.userId.toString() === match.player2Id.toString()
		);

		if (!player1Reg || !player2Reg) {
			throw new BadRequestException(
				"Could not find registrations for both players"
			);
		}

		// Get agent saves for both players
		const player1AgentSave = player1Reg.agentSaveId;
		const player2AgentSave = player2Reg.agentSaveId;

		// Create draft session with player 1's agent save
		const draftSession = await this.draftService.createSession(userId, {
			name: `Tournament: ${tournament.name} - Match ${match.matchNumber}`,
			presetId: tournament.draftPresetId.toString(),
			numberOfGames: tournament.bestOf,
			allowSpectators: true,
			requireJudge: false,
			agentSaveId: player1AgentSave ? player1AgentSave.toString() : undefined
		});

		// Add the second player to the session with their agent save
		if (player2AgentSave) {
			await this.draftService.joinSession(
				draftSession._id.toString(),
				match.player2Id.toString(),
				{
					team: 2,
					password: "",
					agentSaveId: player2AgentSave.toString()
				}
			);
		} else {
			await this.draftService.joinSession(
				draftSession._id.toString(),
				match.player2Id.toString(),
				{
					team: 2,
					password: ""
				}
			);
		}

		// The draft service will calculate agent costs during the preban phase

		// Update match with draft session ID
		match.draftSessionId = draftSession._id as any;
		await tournament.save();

		return draftSession;
	}

	private async advanceLoserToLosersBracket(
		tournament: Tournament,
		match: any
	): Promise<void> {
		// Only applicable for double elimination tournaments
		if (
			tournament.format !== TournamentFormat.DOUBLE_ELIMINATION ||
			match.bracket !== "winners"
		) {
			return;
		}

		// Get the loser of the match
		if (!match.isCompleted || !match.winner) {
			return; // Match not completed or no winner yet
		}

		const loserId = match.winner === 1 ? match.player2Id : match.player1Id;
		if (!loserId) {
			return; // No loser (probably a bye)
		}

		// Find the appropriate losers bracket match based on the round and position
		const winnerRound = match.round;

		// In double elimination, losers from winners round N go to different losers bracket rounds
		// depending on the structure. This is a simplified implementation.
		const loserRound = Math.ceil(winnerRound / 2) * 2 - 1;

		// Find matches in the target losers round that don't have both players assigned
		const loserMatches = tournament.matches.filter(
			(m) =>
				m.bracket === "losers" &&
				m.round === loserRound &&
				(!m.player1Id || !m.player2Id)
		);

		if (loserMatches.length === 0) {
			return; // No available matches in losers bracket
		}

		// Assign the loser to the first available slot in the first available match
		const targetMatch = loserMatches[0];

		if (!targetMatch.player1Id) {
			targetMatch.player1Id = loserId;
		} else if (!targetMatch.player2Id) {
			targetMatch.player2Id = loserId;
		}

		// If both players are now assigned, mark the match as ready
		if (targetMatch.player1Id && targetMatch.player2Id) {
			targetMatch.isReady = true;
		}

		// Update the player's status in registrations to indicate they're in losers bracket
		const playerReg = tournament.registrations.find(
			(reg) => reg.userId.toString() === loserId.toString()
		);

		if (playerReg) {
			playerReg.inLosersBracket = true;
		}
	}

	private async updateSwissPlayerRecords(
		tournament: Tournament,
		match: any
	): Promise<void> {
		// Only applicable for Swiss tournaments
		if (
			tournament.format !== TournamentFormat.SWISS ||
			!tournament.swissRecords
		) {
			return;
		}

		// Get the winner and loser of the match
		if (!match.isCompleted || !match.winner) {
			return; // Match not completed or no winner yet
		}

		const winnerId = match.winner === 1 ? match.player1Id : match.player2Id;
		const loserId = match.winner === 1 ? match.player2Id : match.player1Id;

		// Update player records
		const swissRecords = tournament.swissRecords || [];

		// Update winner's record
		const winnerRecord = swissRecords.find(
			(record) => record.userId.toString() === winnerId.toString()
		);

		if (winnerRecord) {
			winnerRecord.wins += 1;
			winnerRecord.score += 1;
		}

		// Update loser's record
		const loserRecord = swissRecords.find(
			(record) => record.userId.toString() === loserId.toString()
		);

		if (loserRecord) {
			loserRecord.losses += 1;
		}

		// Sort players by score for next round pairings
		swissRecords.sort((a, b) => b.score - a.score);

		// Store updated records
		tournament.swissRecords = swissRecords;

		// Check if all matches in the current round are completed
		const currentRound = match.round;
		const allMatchesCompleted = tournament.matches
			.filter((m) => m.round === currentRound)
			.every((m) => m.isCompleted);

		// If all matches in the round are completed, generate pairings for the next round
		if (allMatchesCompleted) {
			await this.generateNextSwissRound(tournament, currentRound + 1);
		}
	}

	private async generateNextSwissRound(
		tournament: Tournament,
		nextRound: number
	): Promise<void> {
		// Find matches for the next round
		const nextRoundMatches = tournament.matches.filter(
			(m) => m.round === nextRound
		);

		if (nextRoundMatches.length === 0) {
			return; // No matches for next round
		}

		// Get player records sorted by score
		const swissRecords = tournament.swissRecords || [];
		if (swissRecords.length === 0) {
			return; // No player records
		}

		// Create pairings based on Swiss system rules
		// Players with similar scores play against each other
		// Players should not play against the same opponent twice

		// Group players by score
		const playersByScore = {};
		for (const record of swissRecords) {
			const score = record.score;
			if (!playersByScore[score]) {
				playersByScore[score] = [];
			}
			playersByScore[score].push(record);
		}

		// Create pairings
		const pairings = [];
		const pairedPlayers = new Set();

		// Start with highest score and work down
		const scores = Object.keys(playersByScore).sort(
			(a, b) => Number(b) - Number(a)
		);

		for (const score of scores) {
			const players = playersByScore[score].filter(
				(p: any) => !pairedPlayers.has(p.userId.toString())
			);

			// Pair players with the same score
			for (let i = 0; i < players.length; i += 2) {
				if (i + 1 < players.length) {
					pairings.push({
						player1Id: players[i].userId,
						player2Id: players[i + 1].userId
					});

					pairedPlayers.add(players[i].userId.toString());
					pairedPlayers.add(players[i + 1].userId.toString());
				}
			}
		}

		// Handle unpaired players (if any)
		const unpairedPlayers = swissRecords
			.filter((record) => !pairedPlayers.has(record.userId.toString()))
			.map((record) => record.userId);

		// Assign pairings to next round matches
		for (
			let i = 0;
			i < Math.min(pairings.length, nextRoundMatches.length);
			i++
		) {
			const match = nextRoundMatches[i];
			match.player1Id = pairings[i].player1Id;
			match.player2Id = pairings[i].player2Id;
			match.isReady = true;
		}

		// Handle bye for odd number of players
		if (unpairedPlayers.length === 1) {
			const byeMatch = nextRoundMatches.find(
				(m) => !m.player1Id && !m.player2Id
			);
			if (byeMatch) {
				byeMatch.player1Id = unpairedPlayers[0];
				byeMatch.isBye = true;
				byeMatch.winner = 1;
				byeMatch.isCompleted = true;

				// Update player record with a bye
				const playerRecord = swissRecords.find(
					(record) => record.userId.toString() === unpairedPlayers[0].toString()
				);

				if (playerRecord) {
					playerRecord.byes += 1;
					playerRecord.score += 1;
				}
			}
		}
	}

	/**
	 * Calculate the cost of an agent save based on the agents' mindscape levels
	 * @param userId The user ID
	 * @param agentSaveId The agent save ID
	 * @param preset The draft preset containing cost information
	 * @returns The total cost of the agent save
	 */
	private async calculateAgentSaveCost(
		userId: string,
		agentSaveId: string,
		preset: DraftPreset
	): Promise<number> {
		// Get the user with owned agents and agent save
		const user = await this.userModel
			.findById(userId)
			.populate("ownedAgents.agent");

		if (!user) {
			return 0;
		}

		// Find the agent save
		const agentSave = user.agentSaves.find(
			(save: any) => save._id.toString() === agentSaveId
		);

		if (!agentSave) {
			return 0;
		}

		// Calculate total agent cost
		let totalAgentCost = 0;

		for (const agentId of agentSave.agents) {
			// Find the agent cost configuration in the preset
			const agentCost = preset.agentCosts.find(
				(ac) => ac.agent.toString() === agentId.toString()
			);

			if (agentCost) {
				// Find the user's owned agent to get the mindscape level
				const ownedAgent = user.ownedAgents.find(
					(oa) => oa.agent._id.toString() === agentId.toString()
				);

				if (ownedAgent) {
					// Get the cost for this mindscape level from the preset
					const mindscapeLevel = ownedAgent.mindscape;
					// Map is typed as Map<number, number> but we need to convert the key to number
					const cost = agentCost.mindscapeCosts.get(mindscapeLevel) || 0;
					totalAgentCost += cost;
				} else {
					// If the user doesn't own the agent (shouldn't happen in normal flow),
					// use the base cost (mindscape level 0)
					const cost = agentCost.mindscapeCosts.get(0) || 0;
					totalAgentCost += cost;
				}
			}
		}

		return totalAgentCost;
	}

	// Helper method to shuffle an array (Fisher-Yates algorithm)
	private shuffleArray(array: any[]): any[] {
		for (let i = array.length - 1; i > 0; i--) {
			const j = Math.floor(Math.random() * (i + 1));
			[array[i], array[j]] = [array[j], array[i]];
		}
		return array;
	}
}
