import {
	Body,
	Controller,
	Get,
	Post,
	Req,
	Res,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { AuthGuard } from "@nestjs/passport";
import { ApiOperation, ApiResponse, ApiTags } from "@nestjs/swagger";
import { Response } from "express";
import { LoginDto } from "./dto/login.dto";
import { RegisterDto } from "./dto/register.dto";
import { UsersService } from "./users.service";

@ApiTags("auth")
@Controller("auth")
export class AuthController {
	constructor(
		private readonly usersService: UsersService,
		private configService: ConfigService
	) {}

	@Post("register")
	@ApiOperation({ summary: "Register a new user" })
	@ApiResponse({ status: 201, description: "User successfully registered" })
	@ApiResponse({
		status: 400,
		description: "Invalid input or user already exists"
	})
	register(@Body(ValidationPipe) registerDto: RegisterDto) {
		return this.usersService.register(registerDto);
	}

	@Post("login")
	@ApiOperation({ summary: "Login with username and password" })
	@ApiResponse({ status: 200, description: "Login successful" })
	@ApiResponse({ status: 401, description: "Invalid credentials" })
	async login(
		@Body(ValidationPipe) loginDto: LoginDto,
		@Res({ passthrough: true }) response: Response
	) {
		const { user, token } = await this.usersService.login(loginDto);

		response.cookie("auth_token", token, {
			httpOnly: true,
			secure: process.env.NODE_ENV === "production", // cookies only over HTTPS in prod
			sameSite:
				process.env.NODE_ENV === "production" // ↑
					? "none" // allow cookie on cross-site requests in prod
					: "lax", // in dev (localhost), `lax` is fine if same‐origin or top‐level nav
			maxAge: 7 * 24 * 60 * 60 * 1000,
			path: "/"
		});

		return { user, token };
	}

	@Get("discord")
	@UseGuards(AuthGuard("discord"))
	@ApiOperation({ summary: "Initiate Discord OAuth flow" })
	async discordAuth() {
		// This route initiates the Discord OAuth flow
		// The guard will automatically redirect to Discord
	}

	@Get("discord/callback")
	@UseGuards(AuthGuard("discord"))
	@ApiOperation({ summary: "Handle Discord OAuth callback" })
	async discordAuthCallback(@Req() req, @Res() response: Response) {
		// Get the frontend URL from config
		const frontendUrl =
			this.configService.get("FRONTEND_URL") || "http://localhost:3000";

		// After successful authentication, set cookie and redirect
		const { user, token } = req.user;

		// Create a URL for redirect (without token in query params)
		const redirectUrl = new URL("/profile", frontendUrl);
		redirectUrl.searchParams.append("userId", user._id);
		redirectUrl.searchParams.append("username", user.username);
		redirectUrl.searchParams.append("token", token);

		// Set cookie
		response.cookie("auth_token", token, {
			httpOnly: true,
			secure: process.env.NODE_ENV === "production", // cookies only over HTTPS in prod
			sameSite:
				process.env.NODE_ENV === "production" // ↑
					? "none" // allow cookie on cross-site requests in prod
					: "lax", // in dev (localhost), `lax` is fine if same‐origin or top‐level nav
			maxAge: 7 * 24 * 60 * 60 * 1000,
			path: "/"
		});

		// Redirect to the frontend callback
		return response.redirect(redirectUrl.toString());
	}

	@Post("logout")
	@ApiOperation({ summary: "Logout user" })
	@ApiResponse({ status: 200, description: "Logout successful" })
	logout(@Res({ passthrough: true }) response: Response) {
		response.clearCookie("auth_token", {
			httpOnly: true,
			secure: process.env.NODE_ENV === "production",
			sameSite: "lax",
			path: "/"
		});

		return { message: "Logout successful" };
	}
}
