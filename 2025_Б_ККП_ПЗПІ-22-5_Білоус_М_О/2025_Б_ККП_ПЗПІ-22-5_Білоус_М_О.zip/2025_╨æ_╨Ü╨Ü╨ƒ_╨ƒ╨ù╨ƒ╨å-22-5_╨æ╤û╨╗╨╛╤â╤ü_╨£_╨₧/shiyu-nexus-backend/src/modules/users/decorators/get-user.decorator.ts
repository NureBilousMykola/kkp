import { ExecutionContext, createParamDecorator } from "@nestjs/common";
import { JwtUser } from "../interfaces/user.interface";

export const GetUser = createParamDecorator(
	(data: string | undefined, ctx: ExecutionContext): JwtUser => {
		const request = ctx.switchToHttp().getRequest();
		const user = request.user;

		return data ? user?.[data] : user;
	}
);
