import { ApiProperty } from "@nestjs/swagger";
import {
	IsArray,
	IsMongoId,
	IsNotEmpty,
	IsOptional,
	IsString,
	MaxLength,
	MinLength
} from "class-validator";

export class CreateAgentSaveDto {
	@ApiProperty({
		description: "Name of the agent save",
		example: "My Fire Team"
	})
	@IsString()
	@IsNotEmpty()
	@MinLength(3)
	@MaxLength(50)
	name: string;

	@ApiProperty({
		description: "Description of the agent save",
		example: "A team of fire-based agents for stage 3"
	})
	@IsString()
	@IsNotEmpty()
	@MaxLength(200)
	description: string;

	@ApiProperty({
		description: "Array of agent IDs to include in the save",
		type: [String],
		example: ["60d21b4667d0d8992e610c86", "60d21b4667d0d8992e610c87"]
	})
	@IsArray()
	@IsMongoId({ each: true })
	agentIds: string[];
}

export class UpdateAgentSaveDto {
	@ApiProperty({
		description: "Name of the agent save",
		example: "My Updated Fire Team"
	})
	@IsString()
	@IsOptional()
	@MinLength(3)
	@MaxLength(50)
	name?: string;

	@ApiProperty({
		description: "Description of the agent save",
		example: "An updated team of fire-based agents for stage 3"
	})
	@IsString()
	@IsOptional()
	@MaxLength(200)
	description?: string;

	@ApiProperty({
		description: "Array of agent IDs to include in the save",
		type: [String],
		example: [
			"60d21b4667d0d8992e610c86",
			"60d21b4667d0d8992e610c87",
			"60d21b4667d0d8992e610c88"
		]
	})
	@IsArray()
	@IsMongoId({ each: true })
	@IsOptional()
	agentIds?: string[];
}
