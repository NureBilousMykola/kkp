import { Type } from "class-transformer";
import {
	IsMongoId,
	IsNumber,
	Max,
	Min,
	IsArray,
	ValidateNested
} from "class-validator";

export class AddOwnedAgentDto {
	@IsMongoId()
	agentId: string;

	@IsNumber()
	@Min(1)
	@Max(60)
	level: number;

	@IsNumber()
	@Min(0)
	@Max(6)
	mindscape: number;
}

export class UpdateOwnedAgentDto {
	@IsNumber()
	@Min(1)
	@Max(60)
	level: number;

	@IsNumber()
	@Min(0)
	@Max(6)
	mindscape: number;
}

export class AddOwnedEngineDto {
	@IsMongoId()
	engineId: string;

	@IsNumber()
	@Min(1)
	@Max(60)
	level: number;

	@IsNumber()
	@Min(1)
	@Max(5)
	ascension: number;
}

export class UpdateOwnedEngineDto {
	@IsNumber()
	@Min(1)
	@Max(60)
	level: number;

	@IsNumber()
	@Min(1)
	@Max(5)
	ascension: number;
}

export class AddOwnedBangbooDto {
	@IsMongoId()
	bangbooId: string;

	@IsNumber()
	@Min(1)
	@Max(60)
	level: number;

	@IsNumber()
	@Min(1)
	@Max(5)
	ascension: number;
}

export class UpdateOwnedBangbooDto {
	@IsNumber()
	@Min(1)
	@Max(60)
	level: number;

	@IsNumber()
	@Min(1)
	@Max(5)
	ascension: number;
}

// Add new DTOs for bulk operations
export class AddMultipleOwnedAgentsDto {
	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => AddOwnedAgentDto)
	agents: AddOwnedAgentDto[];
}

export class AddMultipleOwnedEnginesDto {
	@IsArray()
	@ValidateNested({ each: true })
	@Type(() => AddOwnedEngineDto)
	engines: AddOwnedEngineDto[];
}
