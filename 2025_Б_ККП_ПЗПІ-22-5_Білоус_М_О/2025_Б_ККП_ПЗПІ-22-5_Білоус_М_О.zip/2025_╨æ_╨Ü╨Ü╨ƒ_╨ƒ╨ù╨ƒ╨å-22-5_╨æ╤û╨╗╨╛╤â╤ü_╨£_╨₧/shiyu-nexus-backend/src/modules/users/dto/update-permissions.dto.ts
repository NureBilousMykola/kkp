import { ApiProperty } from "@nestjs/swagger";
import { IsArray, IsString } from "class-validator";

export class UpdatePermissionsDto {
	@ApiProperty({
		description: "List of permissions to assign to the user",
		type: [String],
		example: ["user:view", "content:view", "content:update"]
	})
	@IsArray()
	@IsString({ each: true })
	permissions: string[];
}
