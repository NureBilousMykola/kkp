import { ApiProperty } from "@nestjs/swagger";
import { UserRole } from "@shared/enums/user-role.enum";
import { IsEnum } from "class-validator";

export class UpdateRoleDto {
	@ApiProperty({
		description: "The role to assign to the user",
		enum: UserRole,
		example: UserRole.MODERATOR
	})
	@IsEnum(UserRole)
	role: UserRole;
}
