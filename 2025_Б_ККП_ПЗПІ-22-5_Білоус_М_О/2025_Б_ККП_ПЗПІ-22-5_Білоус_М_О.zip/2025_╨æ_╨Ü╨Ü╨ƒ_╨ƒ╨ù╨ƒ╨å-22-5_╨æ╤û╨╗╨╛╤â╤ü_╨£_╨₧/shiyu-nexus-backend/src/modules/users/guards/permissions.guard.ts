import { CanActivate, ExecutionContext, Injectable } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { UserRole } from "../../../shared/enums/user-role.enum";

@Injectable()
export class PermissionsGuard implements CanActivate {
	constructor(private reflector: Reflector) {}

	canActivate(context: ExecutionContext): boolean {
		const requiredPermissions = this.reflector.getAllAndOverride<string[]>(
			"permissions",
			[context.getHandler(), context.getClass()]
		);

		if (!requiredPermissions) {
			return true;
		}

		const { user } = context.switchToHttp().getRequest();

		// Admins have all permissions
		if (user.role === UserRole.ADMIN) {
			return true;
		}

		return requiredPermissions.every((permission) =>
			user.permissions?.includes(permission)
		);
	}
}
