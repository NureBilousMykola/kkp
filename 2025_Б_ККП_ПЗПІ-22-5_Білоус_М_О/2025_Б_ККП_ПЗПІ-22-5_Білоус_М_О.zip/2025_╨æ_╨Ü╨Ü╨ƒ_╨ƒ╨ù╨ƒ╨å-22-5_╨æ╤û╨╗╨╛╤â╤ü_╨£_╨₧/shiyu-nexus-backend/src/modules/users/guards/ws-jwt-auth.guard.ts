import { CanActivate, ExecutionContext, Injectable } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { WsException } from "@nestjs/websockets";
import { Socket } from "socket.io";

@Injectable()
export class WsJwtAuthGuard implements CanActivate {
	constructor(private jwtService: JwtService) {}

	async canActivate(context: ExecutionContext): Promise<boolean> {
		try {
			const client: Socket = context.switchToWs().getClient();
			console.log(
				"WS JWT Guard - Checking authorization for socket:",
				client.id
			);

			const token = this.extractTokenFromHeader(client);
			console.log(
				"WS JWT Guard - Token extracted:",
				token ? "present" : "missing"
			);

			if (!token) {
				console.log("WS JWT Guard - No token found");
				throw new WsException("Unauthorized");
			}

			const payload = await this.jwtService.verifyAsync(token);
			console.log("WS JWT Guard - Token verified, payload:", payload);

			// Attach user to socket data for later use
			client.data.user = payload;
			console.log("WS JWT Guard - User attached to socket data");

			return true;
		} catch (error) {
			console.error("WS JWT Guard - Authentication failed:", error);
			throw new WsException("Unauthorized");
		}
	}

	private extractTokenFromHeader(client: Socket): string | undefined {
		console.log("WS JWT Guard - All headers:", client.handshake.headers);
		console.log("WS JWT Guard - Auth object:", client.handshake.auth);

		// Try to get token from auth object first (Socket.io auth)
		if (client.handshake.auth?.token) {
			console.log("WS JWT Guard - Token found in auth object");
			return client.handshake.auth.token;
		}

		// Fallback to Authorization header
		const auth = client.handshake.headers.authorization;
		console.log("WS JWT Guard - Authorization header:", auth);

		if (!auth) {
			console.log("WS JWT Guard - No authorization header found");
			return undefined;
		}

		const [type, token] = auth.split(" ");
		console.log("WS JWT Guard - Auth type:", type, "Token present:", !!token);

		return type === "Bearer" ? token : undefined;
	}
}
