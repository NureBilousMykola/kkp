import { UserRole } from "@shared/enums/user-role.enum";

export interface JwtUser {
	id: string;
	username: string;
	email: string;
	role: UserRole;
	permissions: string[];
	discordId?: string;
}
