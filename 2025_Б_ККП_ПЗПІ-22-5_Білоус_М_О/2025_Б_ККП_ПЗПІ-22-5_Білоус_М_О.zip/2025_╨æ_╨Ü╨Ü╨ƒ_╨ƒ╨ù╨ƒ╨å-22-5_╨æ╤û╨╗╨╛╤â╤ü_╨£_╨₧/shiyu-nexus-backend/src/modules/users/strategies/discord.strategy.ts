import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { PassportStrategy } from "@nestjs/passport";
import { Strategy } from "passport-discord";
import { DiscordAuthDto } from "../dto/discord-auth.dto";
import { UsersService } from "../users.service";

@Injectable()
export class DiscordStrategy extends PassportStrategy(Strategy) {
	constructor(
		private configService: ConfigService,
		private usersService: UsersService
	) {
		super({
			clientID: configService.get("DISCORD_CLIENT_ID"),
			clientSecret: configService.get("DISCORD_CLIENT_SECRET"),
			callbackURL: configService.get("DISCORD_CALLBACK_URL"),
			scope: ["identify", "email"],
			passReqToCallback: true
		});
	}

	async validate(
		request: Request,
		accessToken: string,
		refreshToken: string,
		profile: any
	): Promise<any> {
		const discordUser: DiscordAuthDto = {
			id: profile.id,
			email: profile.email,
			username: profile.username,
			avatar: profile.avatar,
			accessToken,
			refreshToken
		};

		// Process the user and return user data with a token
		const user = await this.usersService.handleDiscordAuth(discordUser);
		const token = await this.usersService.generateToken(user);

		return {
			user,
			token
		};
	}
}
