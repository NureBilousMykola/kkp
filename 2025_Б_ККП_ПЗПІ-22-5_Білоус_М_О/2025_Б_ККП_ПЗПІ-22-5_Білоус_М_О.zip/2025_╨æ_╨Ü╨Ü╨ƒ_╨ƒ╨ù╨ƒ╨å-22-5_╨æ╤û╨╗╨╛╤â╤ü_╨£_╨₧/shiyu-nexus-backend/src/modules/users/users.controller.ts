import {
	AddMultipleOwnedEnginesDto,
	AddOwnedBangbooDto,
	UpdateOwnedAgentDto,
	UpdateOwnedBangbooDto,
	UpdateOwnedEngineDto
} from "@modules/users/dto/owned-items.dto";
import { AddMultipleOwnedAgentsDto } from "@modules/users/dto/owned-items.dto";
import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	Patch,
	Post,
	UseGuards,
	ValidationPipe
} from "@nestjs/common";
import { ApiOperation, ApiResponse, ApiTags } from "@nestjs/swagger";
import { Permissions as PermissionsList } from "@shared/constants/permissions.constants";
import { UserRole } from "@shared/enums/user-role.enum";
import { GetUser } from "./decorators/get-user.decorator";
import { Permissions } from "./decorators/permissions.decorator";
import { Roles } from "./decorators/roles.decorator";
import { CreateAgentSaveDto, UpdateAgentSaveDto } from "./dto/agent-save.dto";
import { UpdatePermissionsDto } from "./dto/update-permissions.dto";
import { UpdateRoleDto } from "./dto/update-role.dto";
import { UpdateUserDto } from "./dto/update-user.dto";
import { JwtAuthGuard } from "./guards/jwt-auth.guard";
import { PermissionsGuard } from "./guards/permissions.guard";
import { RolesGuard } from "./guards/roles.guard";
import { JwtUser } from "./interfaces/user.interface";
import { UsersService } from "./users.service";

@ApiTags("users")
@Controller("users")
export class UsersController {
	constructor(private readonly usersService: UsersService) {}

	// Profile Management
	@Get("profile")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Get current user profile" })
	@ApiResponse({ status: 200, description: "Returns the user profile" })
	getProfile(@GetUser() user: JwtUser) {
		return this.usersService.getProfile(user.id);
	}

	@Patch("profile")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Update current user profile" })
	@ApiResponse({ status: 200, description: "Profile updated successfully" })
	updateProfile(
		@GetUser() user: JwtUser,
		@Body(ValidationPipe) updateUserDto: UpdateUserDto
	) {
		return this.usersService.updateProfile(user.id, updateUserDto);
	}

	// Inventory Management - Owned Agents
	@Post("inventory/agents")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Add an agent to user inventory" })
	@ApiResponse({ status: 201, description: "Agents added to inventory" })
	@ApiResponse({
		status: 400,
		description: "Invalid request"
	})
	@ApiResponse({ status: 409, description: "All agents already owned" })
	addOwnedAgent(
		@GetUser() user: JwtUser,
		@Body(ValidationPipe) dto: AddMultipleOwnedAgentsDto
	) {
		return this.usersService.addMultipleOwnedAgents(user.id, dto);
	}

	@Patch("inventory/agents/:agentId")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Update an agent in user inventory" })
	@ApiResponse({ status: 200, description: "Agent updated in inventory" })
	updateOwnedAgent(
		@GetUser() user: JwtUser,
		@Param("agentId") agentId: string,
		@Body(ValidationPipe) dto: UpdateOwnedAgentDto
	) {
		return this.usersService.updateOwnedAgent(user.id, agentId, dto);
	}

	@Delete("inventory/agents/:agentId")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Remove an agent from user inventory" })
	@ApiResponse({ status: 200, description: "Agent removed from inventory" })
	removeOwnedAgent(
		@GetUser() user: JwtUser,
		@Param("agentId") agentId: string
	) {
		return this.usersService.removeOwnedAgent(user.id, agentId);
	}

	// Inventory Management - Owned Engines
	@Post("inventory/engines")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Add an engine to user inventory" })
	@ApiResponse({ status: 201, description: "Engine added to inventory" })
	addOwnedEngine(
		@GetUser() user: JwtUser,
		@Body(ValidationPipe) dto: AddMultipleOwnedEnginesDto
	) {
		return this.usersService.addMultipleOwnedEngines(user.id, dto);
	}

	@Patch("inventory/engines/:engineId")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Update an engine in user inventory" })
	@ApiResponse({ status: 200, description: "Engine updated in inventory" })
	updateOwnedEngine(
		@GetUser() user: JwtUser,
		@Param("engineId") engineId: string,
		@Body(ValidationPipe) dto: UpdateOwnedEngineDto
	) {
		return this.usersService.updateOwnedEngine(user.id, engineId, dto);
	}

	@Delete("inventory/engines/:engineId")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Remove an engine from user inventory" })
	@ApiResponse({ status: 200, description: "Engine removed from inventory" })
	removeOwnedEngine(
		@GetUser() user: JwtUser,
		@Param("engineId") engineId: string
	) {
		return this.usersService.removeOwnedEngine(user.id, engineId);
	}

	// Inventory Management - Owned Bangboos
	@Post("inventory/bangboos")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Add a bangboo to user inventory" })
	@ApiResponse({ status: 201, description: "Bangboo added to inventory" })
	addOwnedBangboo(
		@GetUser() user: JwtUser,
		@Body(ValidationPipe) dto: AddOwnedBangbooDto
	) {
		return this.usersService.addOwnedBangboo(user.id, dto);
	}

	@Patch("inventory/bangboos/:bangbooId")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Update a bangboo in user inventory" })
	@ApiResponse({ status: 200, description: "Bangboo updated in inventory" })
	updateOwnedBangboo(
		@GetUser() user: JwtUser,
		@Param("bangbooId") bangbooId: string,
		@Body(ValidationPipe) dto: UpdateOwnedBangbooDto
	) {
		return this.usersService.updateOwnedBangboo(user.id, bangbooId, dto);
	}

	@Delete("inventory/bangboos/:bangbooId")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Remove a bangboo from user inventory" })
	@ApiResponse({ status: 200, description: "Bangboo removed from inventory" })
	removeOwnedBangboo(
		@GetUser() user: JwtUser,
		@Param("bangbooId") bangbooId: string
	) {
		return this.usersService.removeOwnedBangboo(user.id, bangbooId);
	}

	// Agent Saves Management
	@Post("agent-saves")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Create a new agent save" })
	@ApiResponse({ status: 201, description: "Agent save created successfully" })
	createAgentSave(
		@GetUser() user: JwtUser,
		@Body(ValidationPipe) createAgentSaveDto: CreateAgentSaveDto
	) {
		return this.usersService.createAgentSave(user.id, createAgentSaveDto);
	}

	@Get("agent-saves")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Get all agent saves for the current user" })
	@ApiResponse({ status: 200, description: "Returns all agent saves" })
	getAgentSaves(@GetUser() user: JwtUser) {
		return this.usersService.getAgentSaves(user.id);
	}

	@Get("agent-saves/:id")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Get a specific agent save by ID" })
	@ApiResponse({ status: 200, description: "Returns the agent save" })
	@ApiResponse({ status: 404, description: "Agent save not found" })
	getAgentSave(@GetUser() user: JwtUser, @Param("id") id: string) {
		return this.usersService.getAgentSave(user.id, id);
	}

	@Patch("agent-saves/:id")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Update an agent save" })
	@ApiResponse({ status: 200, description: "Agent save updated successfully" })
	@ApiResponse({ status: 404, description: "Agent save not found" })
	updateAgentSave(
		@GetUser() user: JwtUser,
		@Param("id") id: string,
		@Body(ValidationPipe) updateAgentSaveDto: UpdateAgentSaveDto
	) {
		return this.usersService.updateAgentSave(user.id, id, updateAgentSaveDto);
	}

	@Delete("agent-saves/:id")
	@UseGuards(JwtAuthGuard)
	@ApiOperation({ summary: "Delete an agent save" })
	@ApiResponse({ status: 200, description: "Agent save deleted successfully" })
	@ApiResponse({ status: 404, description: "Agent save not found" })
	deleteAgentSave(@GetUser() user: JwtUser, @Param("id") id: string) {
		return this.usersService.deleteAgentSave(user.id, id);
	}

	// Admin and Moderator routes
	@Get()
	@UseGuards(JwtAuthGuard, PermissionsGuard)
	@Permissions(PermissionsList.USER_VIEW)
	@ApiOperation({ summary: "Get all users (admin/moderator)" })
	@ApiResponse({ status: 200, description: "Returns all users" })
	findAll() {
		return this.usersService.findAll();
	}

	@Get(":id")
	@UseGuards(JwtAuthGuard, PermissionsGuard)
	@Permissions(PermissionsList.USER_VIEW)
	@ApiOperation({ summary: "Get user by ID (admin/moderator)" })
	@ApiResponse({ status: 200, description: "Returns the user" })
	findOne(@Param("id") id: string) {
		return this.usersService.getProfile(id);
	}

	@Patch(":id/role")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update user role (admin only)" })
	@ApiResponse({ status: 200, description: "Role updated successfully" })
	updateRole(
		@Param("id") id: string,
		@Body(ValidationPipe) updateRoleDto: UpdateRoleDto
	) {
		return this.usersService.updateUserRole(id, updateRoleDto.role);
	}

	@Patch(":id/permissions")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Update user permissions (admin only)" })
	@ApiResponse({ status: 200, description: "Permissions updated successfully" })
	updatePermissions(
		@Param("id") id: string,
		@Body(ValidationPipe) updatePermissionsDto: UpdatePermissionsDto
	) {
		return this.usersService.updateUserPermissions(
			id,
			updatePermissionsDto.permissions
		);
	}

	@Delete(":id")
	@UseGuards(JwtAuthGuard, RolesGuard)
	@Roles(UserRole.ADMIN)
	@ApiOperation({ summary: "Delete a user (admin only)" })
	@ApiResponse({ status: 200, description: "User deleted successfully" })
	remove(@Param("id") id: string) {
		return this.usersService.remove(id);
	}
}
