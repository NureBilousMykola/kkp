import { User, UserSchema } from "@/schemas/user.schema";
import { Module } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { JwtModule } from "@nestjs/jwt";
import { MongooseModule } from "@nestjs/mongoose";
import { PassportModule } from "@nestjs/passport";
import { AuthController } from "./auth.controller";
import { DiscordStrategy } from "./strategies/discord.strategy";
import { JwtStrategy } from "./strategies/jwt.strategy";
import { UsersController } from "./users.controller";
import { UsersService } from "./users.service";

@Module({
	imports: [
		MongooseModule.forFeature([{ name: User.name, schema: UserSchema }]),
		PassportModule,
		JwtModule.registerAsync({
			imports: [ConfigModule],
			useFactory: (configService: ConfigService) => ({
				secret: configService.get("JWT_SECRET"),
				signOptions: { expiresIn: "7d" }
			}),
			inject: [ConfigService]
		})
	],
	controllers: [UsersController, AuthController],
	providers: [UsersService, JwtStrategy, DiscordStrategy],
	exports: [UsersService]
})
export class UsersModule {}
