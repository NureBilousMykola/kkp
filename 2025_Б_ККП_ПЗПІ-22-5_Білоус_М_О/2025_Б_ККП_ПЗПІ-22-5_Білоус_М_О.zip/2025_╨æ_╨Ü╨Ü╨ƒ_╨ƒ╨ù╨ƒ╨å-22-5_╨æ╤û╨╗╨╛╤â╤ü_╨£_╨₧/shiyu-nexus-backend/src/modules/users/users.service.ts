import { User, UserDocument } from "@/schemas/user.schema";
import {
	CreateAgentSaveDto,
	UpdateAgentSaveDto
} from "@modules/users/dto/agent-save.dto";
import { DiscordAuthDto } from "@modules/users/dto/discord-auth.dto";
import { LoginDto } from "@modules/users/dto/login.dto";
import {
	AddMultipleOwnedAgentsDto,
	AddMultipleOwnedEnginesDto,
	AddOwnedAgentDto,
	AddOwnedBangbooDto,
	UpdateOwnedAgentDto,
	UpdateOwnedBangbooDto,
	UpdateOwnedEngineDto
} from "@modules/users/dto/owned-items.dto";
import { RegisterDto } from "@modules/users/dto/register.dto";
import { UpdateUserDto } from "@modules/users/dto/update-user.dto";
import {
	BadRequestException,
	ConflictException,
	Injectable,
	NotFoundException,
	UnauthorizedException
} from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { InjectModel } from "@nestjs/mongoose";
import { RolePermissions } from "@shared/constants/permissions.constants";
import { UserRole } from "@shared/enums/user-role.enum";
import * as bcrypt from "bcrypt";
import { Model, Types } from "mongoose";

@Injectable()
export class UsersService {
	constructor(
		@InjectModel(User.name) private userModel: Model<UserDocument>,
		private jwtService: JwtService
	) {}

	async register(registerDto: RegisterDto): Promise<UserDocument> {
		const { email, username, password } = registerDto;
		await this.validateUniqueFields(email, username);

		const hashedPassword = await this.hashPassword(password);
		const user = new this.userModel({
			email,
			username,
			passwordHash: hashedPassword,
			role: UserRole.USER,
			permissions: RolePermissions[UserRole.USER] || []
		});

		await user.save();
		return user;
	}

	async login(loginDto: LoginDto) {
		const { username, password } = loginDto;
		const user = await this.userModel.findOne({ username });

		if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
			throw new UnauthorizedException("Invalid credentials");
		}

		const token = this._createToken(user);
		return { user, token };
	}

	async handleDiscordAuth(discordUser: DiscordAuthDto): Promise<UserDocument> {
		let user: UserDocument = await this.userModel.findOne({
			discordId: discordUser.id
		});

		if (!user) {
			const uniqueUsername = await this.generateUniqueUsername(
				discordUser.username
			);
			user = await this.createDiscordUser(discordUser, uniqueUsername);
		} else {
			user = await this.updateDiscordUser(user, discordUser);
		}

		return user;
	}

	async loginWithDiscord(user: UserDocument) {
		const token = this._createToken(user);
		return { user, token };
	}

	async getProfile(userId: string) {
		const user = await this.userModel
			.findById(userId)
			.select("-passwordHash -discordAccessToken -discordRefreshToken")
			.populate({
				path: "ownedAgents.agent",
				select:
					"name fullName normalizedName rarity specialty attribute imageUrl iconUrl"
			})
			.populate({
				path: "ownedEngines.engine",
				select:
					"name normalizedName rarity specialty isCraftable isEventLimited maxAscension imageUrl signatureAgentId"
			})
			.exec();

		if (!user) throw new NotFoundException("User not found");
		return user;
	}

	async updateProfile(userId: string, updateUserDto: UpdateUserDto) {
		if (updateUserDto.email || updateUserDto.username) {
			const existingUser = await this.userModel.findOne({
				$or: [
					{ email: updateUserDto.email },
					{ username: updateUserDto.username }
				],
				_id: { $ne: userId }
			});

			if (existingUser) {
				throw new ConflictException("Email or username already exists");
			}
		}

		const user = await this.userModel.findByIdAndUpdate(userId, updateUserDto, {
			new: true
		});

		if (!user) throw new NotFoundException("User not found");
		return user;
	}

	private async validateUniqueFields(
		email: string,
		username: string
	): Promise<void> {
		const existing = await this.userModel.findOne({
			$or: [{ email }, { username }]
		});
		if (existing) {
			throw new ConflictException(
				existing.email === email
					? "Email already exists"
					: "Username already exists"
			);
		}
	}

	private async generateUniqueUsername(baseUsername: string): Promise<string> {
		let username = baseUsername;
		let counter = 1;
		while (await this.userModel.findOne({ username })) {
			username = `${baseUsername}${counter++}`;
		}
		return username;
	}

	private async createDiscordUser(
		discordUser: DiscordAuthDto,
		username: string
	): Promise<UserDocument> {
		const user = new this.userModel({
			email: discordUser.email,
			username,
			discordId: discordUser.id,
			discordUsername: discordUser.username,
			discordAvatar: discordUser.avatar,
			discordAccessToken: discordUser.accessToken,
			discordRefreshToken: discordUser.refreshToken,
			role: UserRole.USER,
			permissions: RolePermissions[UserRole.USER] || []
		});
		return user.save();
	}

	private async updateDiscordUser(
		user: UserDocument,
		discordUser: DiscordAuthDto
	): Promise<UserDocument> {
		user.discordUsername = discordUser.username;
		user.discordAvatar = discordUser.avatar;
		user.discordAccessToken = discordUser.accessToken;
		user.discordRefreshToken = discordUser.refreshToken;
		if (!user.email) user.email = discordUser.email;
		return user.save();
	}

	private async hashPassword(password: string): Promise<string> {
		const salt = await bcrypt.genSalt();
		return bcrypt.hash(password, salt);
	}

	// Owned Items Management
	async addOwnedAgent(userId: string, dto: AddOwnedAgentDto) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const exists = user.ownedAgents.some(
			(oa) => oa.agent.toString() === dto.agentId
		);
		if (exists) throw new ConflictException("Agent already owned");

		user.ownedAgents.push({
			agent: new Types.ObjectId(dto.agentId) as any,
			level: dto.level,
			mindscape: dto.mindscape
		});

		await user.save();
		return this.getProfile(userId);
	}

	async updateOwnedAgent(
		userId: string,
		agentId: string,
		dto: UpdateOwnedAgentDto
	) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const agentIndex = user.ownedAgents.findIndex(
			(oa) => oa.agent.toString() === agentId
		);
		if (agentIndex === -1) throw new NotFoundException("Owned agent not found");

		user.ownedAgents[agentIndex].level = dto.level;
		user.ownedAgents[agentIndex].mindscape = dto.mindscape;

		await user.save();
		return this.getProfile(userId);
	}

	async removeOwnedAgent(userId: string, agentId: string) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		user.ownedAgents = user.ownedAgents.filter(
			(oa) => oa.agent.toString() !== agentId
		);

		await user.save();
		return this.getProfile(userId);
	}

	// Engine management
	async updateOwnedEngine(
		userId: string,
		engineId: string,
		dto: UpdateOwnedEngineDto
	) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const engineIndex = user.ownedEngines.findIndex(
			(oe) => oe.engine.toString() === engineId
		);
		if (engineIndex === -1)
			throw new NotFoundException("Owned engine not found");

		user.ownedEngines[engineIndex].level = dto.level;
		user.ownedEngines[engineIndex].ascension = dto.ascension;

		await user.save();
		return this.getProfile(userId);
	}

	async removeOwnedEngine(userId: string, engineId: string) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		user.ownedEngines = user.ownedEngines.filter(
			(oe) => oe.engine.toString() !== engineId
		);

		await user.save();
		return this.getProfile(userId);
	}

	// Bangboo management
	async addOwnedBangboo(userId: string, dto: AddOwnedBangbooDto) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const exists = user.ownedBangboos.some(
			(ob) => ob.bangboo.toString() === dto.bangbooId
		);
		if (exists) throw new ConflictException("Bangboo already owned");

		user.ownedBangboos.push({
			bangboo: new Types.ObjectId(dto.bangbooId) as any,
			level: dto.level,
			ascension: dto.ascension
		});

		await user.save();
		return this.getProfile(userId);
	}

	async updateOwnedBangboo(
		userId: string,
		bangbooId: string,
		dto: UpdateOwnedBangbooDto
	) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const bangbooIndex = user.ownedBangboos.findIndex(
			(ob) => ob.bangboo.toString() === bangbooId
		);
		if (bangbooIndex === -1)
			throw new NotFoundException("Owned bangboo not found");

		user.ownedBangboos[bangbooIndex].level = dto.level;
		user.ownedBangboos[bangbooIndex].ascension = dto.ascension;

		await user.save();
		return this.getProfile(userId);
	}

	async removeOwnedBangboo(userId: string, bangbooId: string) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		user.ownedBangboos = user.ownedBangboos.filter(
			(ob) => ob.bangboo.toString() !== bangbooId
		);

		await user.save();
		return this.getProfile(userId);
	}

	// Admin methods
	async findAll() {
		return this.userModel
			.find()
			.select("-passwordHash -discordAccessToken -discordRefreshToken");
	}

	async remove(id: string) {
		const user = await this.userModel.findByIdAndDelete(id);
		if (!user) throw new NotFoundException("User not found");
		return user;
	}

	async findByDiscordId(discordId: string): Promise<UserDocument | null> {
		return this.userModel.findOne({ discordId }).exec();
	}

	private _createToken(user: UserDocument) {
		const payload = {
			sub: user._id.toString(),
			email: user.email,
			username: user.username,
			role: user.role,
			permissions: user.permissions,
			discordId: user.discordId
		};
		return this.jwtService.sign(payload);
	}

	async generateToken(user: UserDocument): Promise<string> {
		const payload = {
			sub: user._id.toString(),
			username: user.username,
			email: user.email,
			role: user.role,
			permissions: user.permissions,
			discordId: user.discordId
		};

		return this.jwtService.sign(payload);
	}

	// Role and Permission Management
	async updateUserRole(userId: string, role: UserRole) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		// Get the default permissions for the new role
		const roleKey = role.toLowerCase();
		const permissions = RolePermissions[roleKey] || [];

		user.role = role;
		user.permissions = permissions;

		await user.save();
		return user;
	}

	async updateUserPermissions(userId: string, permissions: string[]) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		user.permissions = permissions;
		await user.save();
		return user;
	}

	async hasPermission(userId: string, permission: string): Promise<boolean> {
		const user = await this.userModel.findById(userId);
		if (!user) return false;

		// Admins have all permissions
		if (user.role.toLowerCase() === "admin") return true;

		// Check if the user has the specific permission
		return user.permissions.includes(permission);
	}

	// Agent Saves Management
	async createAgentSave(
		userId: string,
		createAgentSaveDto: CreateAgentSaveDto
	) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		// Verify that all agents exist in the user's owned agents
		const ownedAgentIds = user.ownedAgents.map((oa) => oa.agent.toString());
		const allAgentsOwned = createAgentSaveDto.agentIds.every((agentId) =>
			ownedAgentIds.includes(agentId)
		);

		if (!allAgentsOwned) {
			throw new ConflictException("You can only save agents that you own");
		}

		// Create the agent save
		const agentSave = {
			_id: new Types.ObjectId(),
			name: createAgentSaveDto.name,
			description: createAgentSaveDto.description,
			agents: createAgentSaveDto.agentIds.map(
				(id) => new Types.ObjectId(id) as any
			),
			createdAt: new Date(),
			updatedAt: new Date()
		};

		user.agentSaves.push(agentSave as any);
		await user.save();

		return user;
	}

	async getAgentSaves(userId: string) {
		const user = await this.userModel
			.findById(userId)
			.populate({
				path: "agentSaves.agents",
				select:
					"name fullName normalizedName rarity specialty attribute imageUrl iconUrl"
			})
			.exec();

		if (!user) throw new NotFoundException("User not found");
		return user.agentSaves;
	}

	async getAgentSave(userId: string, saveId: string) {
		const user = await this.userModel.findById(userId).exec();

		if (!user) throw new NotFoundException("User not found");

		const agentSave = user.agentSaves.find(
			(save) => save._id.toString() === saveId
		);
		if (!agentSave) throw new NotFoundException("Agent save not found");

		return agentSave;
	}

	async updateAgentSave(
		userId: string,
		saveId: string,
		updateAgentSaveDto: UpdateAgentSaveDto
	) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const saveIndex = user.agentSaves.findIndex(
			(save) => save._id.toString() === saveId
		);
		if (saveIndex === -1) throw new NotFoundException("Agent save not found");

		// If updating agent IDs, verify that all agents exist in the user's owned agents
		if (updateAgentSaveDto.agentIds) {
			const ownedAgentIds = user.ownedAgents.map((oa) => oa.agent.toString());
			const allAgentsOwned = updateAgentSaveDto.agentIds.every((agentId) =>
				ownedAgentIds.includes(agentId)
			);

			if (!allAgentsOwned) {
				throw new ConflictException("You can only save agents that you own");
			}

			user.agentSaves[saveIndex].agents = updateAgentSaveDto.agentIds.map(
				(id) => new Types.ObjectId(id) as any
			);
		}

		if (updateAgentSaveDto.name) {
			user.agentSaves[saveIndex].name = updateAgentSaveDto.name;
		}

		if (updateAgentSaveDto.description) {
			user.agentSaves[saveIndex].description = updateAgentSaveDto.description;
		}

		user.agentSaves[saveIndex].updatedAt = new Date();

		await user.save();
		return this.getAgentSave(userId, saveId);
	}

	async deleteAgentSave(userId: string, saveId: string) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const initialLength = user.agentSaves.length;
		user.agentSaves = user.agentSaves.filter(
			(save) => save._id.toString() !== saveId
		);

		if (user.agentSaves.length === initialLength) {
			throw new NotFoundException("Agent save not found");
		}

		await user.save();
		return { message: "Agent save deleted successfully" };
	}

	async addMultipleOwnedAgents(userId: string, dto: AddMultipleOwnedAgentsDto) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		const uniqueAgentIds = new Set(dto.agents.map((a) => a.agentId));
		if (uniqueAgentIds.size !== dto.agents.length) {
			throw new BadRequestException("Duplicate agents in request");
		}

		const existingAgentIds = user.ownedAgents.map((oa) => oa.agent.toString());
		const newAgents = dto.agents.filter(
			(a) => !existingAgentIds.includes(a.agentId)
		);

		if (newAgents.length === 0) {
			throw new ConflictException("All agents are already owned");
		}

		user.ownedAgents.push(
			...newAgents.map((a) => ({
				agent: new Types.ObjectId(a.agentId) as any,
				level: a.level,
				mindscape: a.mindscape
			}))
		);

		await user.save();
		return this.getProfile(userId);
	}

	async addMultipleOwnedEngines(
		userId: string,
		dto: AddMultipleOwnedEnginesDto
	) {
		const user = await this.userModel.findById(userId);
		if (!user) throw new NotFoundException("User not found");

		// For engines, we allow multiple of the same type
		for (const engine of dto.engines) {
			user.ownedEngines.push({
				engine: new Types.ObjectId(engine.engineId) as any,
				level: engine.level,
				ascension: engine.ascension
			});
		}

		await user.save();
		return this.getProfile(userId);
	}
}
