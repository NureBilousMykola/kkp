import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document, Schema as MongooseSchema } from "mongoose";
import { Faction } from "./faction.schema";

export type AgentDocument = Agent & Document;

@Schema({ timestamps: true })
export class Agent {
	@Prop({ type: MongooseSchema.Types.ObjectId, auto: true })
	_id: MongooseSchema.Types.ObjectId;

	@Prop({ required: true })
	name: string;

	@Prop({ required: true })
	fullName: string;

	@Prop({ required: true })
	normalizedName: string;

	@Prop({ required: true, default: false })
	isReleased: boolean;

	@Prop({ required: true, default: false })
	isLimited: boolean;

	@Prop({ required: true, enum: ["S", "A"] })
	rarity: string;

	@Prop({
		required: true,
		enum: ["attack", "anomaly", "defense", "stun", "support"]
	})
	specialty: string;

	@Prop({
		required: true,
		enum: ["physical", "fire", "ice", "ether", "electric", "frost"]
	})
	attribute: string;

	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "Faction", required: true })
	faction: Faction;

	@Prop({ required: true, default: false })
	hasEngineCostException: boolean;

	@Prop()
	imageUrl?: string;

	@Prop()
	iconUrl?: string;
}

export const AgentSchema = SchemaFactory.createForClass(Agent);
