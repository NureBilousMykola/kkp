import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

export type BangbooDocument = Bangboo & Document;

@Schema({ timestamps: true })
export class Bangboo {
	@Prop({ required: true })
	name: string;

	@Prop({ required: true })
	normalizedName: string;

	@Prop({ required: true, enum: ["S", "A"] })
	rarity: string;

	@Prop()
	imageUrl?: string;
}

export const BangbooSchema = SchemaFactory.createForClass(Bangboo);
