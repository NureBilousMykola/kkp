import { Prop, Schema } from "@nestjs/mongoose";
import { Types } from "mongoose";

@Schema()
export class RoomConstraint {
	@Prop({ required: true, min: 1, max: 2 })
	roomId: number;

	@Prop({ type: [{ type: Types.ObjectId, ref: "Agent" }] })
	bannedAgents: Types.ObjectId[];

	@Prop({
		type: [String],
		enum: ["attack", "anomaly", "defense", "stun", "support"]
	})
	bannedSpecialties?: string[];

	@Prop({
		type: [String],
		enum: ["physical", "fire", "ice", "ether", "electric", "frost"]
	})
	bannedAttributes?: string[];
}

@Schema()
export class StageConstraint {
	@Prop({ required: true, min: 1, max: 7 })
	stageId: number;

	@Prop({ type: [RoomConstraint], required: true })
	roomConstraints: RoomConstraint[];
}
