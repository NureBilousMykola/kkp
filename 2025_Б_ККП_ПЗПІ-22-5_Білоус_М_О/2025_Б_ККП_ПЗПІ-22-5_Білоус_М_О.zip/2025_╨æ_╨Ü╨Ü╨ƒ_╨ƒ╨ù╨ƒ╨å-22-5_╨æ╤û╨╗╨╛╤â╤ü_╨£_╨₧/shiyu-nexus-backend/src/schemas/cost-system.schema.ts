import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document, Types } from "mongoose";

export type CostSystemDocument = CostSystem & Document;

@Schema()
export class AgentCost {
	@Prop({ type: Types.ObjectId, ref: "Agent", required: true })
	agent: Types.ObjectId;

	@Prop({ type: Map, of: Number, required: true })
	mindscapeCosts: Map<number, number>;
}

@Schema()
export class EngineCost {
	@Prop({ type: Types.ObjectId, ref: "Engine", required: true })
	engine: Types.ObjectId;

	@Prop({ type: Map, of: Number, required: true })
	ascensionCosts: Map<number, number>;
}

@Schema({ timestamps: true })
export class CostSystem {
	@Prop({ required: true, unique: true })
	name: string;

	@Prop()
	description?: string;

	@Prop({ type: [AgentCost], default: [] })
	agentCosts: AgentCost[];

	@Prop({ type: [EngineCost], default: [] })
	engineCosts: EngineCost[];

	@Prop({ default: false })
	isDefault: boolean;

	@Prop({ type: Types.ObjectId, ref: "User", required: true })
	createdBy: Types.ObjectId;
}

export const CostSystemSchema = SchemaFactory.createForClass(CostSystem);
export const AgentCostSchema = SchemaFactory.createForClass(AgentCost);
export const EngineCostSchema = SchemaFactory.createForClass(EngineCost);
