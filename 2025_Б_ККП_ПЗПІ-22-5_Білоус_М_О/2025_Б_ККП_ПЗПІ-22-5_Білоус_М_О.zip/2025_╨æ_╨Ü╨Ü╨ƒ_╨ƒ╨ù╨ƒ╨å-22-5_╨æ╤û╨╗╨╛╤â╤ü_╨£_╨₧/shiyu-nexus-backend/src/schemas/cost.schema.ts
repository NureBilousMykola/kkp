import { Prop, Schema } from "@nestjs/mongoose";
import { Types } from "mongoose";

@Schema()
export class AgentCost {
	@Prop({ type: Types.ObjectId, ref: "Agent", required: true })
	agent: Types.ObjectId;

	@Prop({ type: Map, of: Number, required: true })
	mindscapeCosts: Map<number, number>; // M0-M6 costs
}

@Schema()
export class EngineCost {
	@Prop({ type: Types.ObjectId, ref: "Engine", required: true })
	engine: Types.ObjectId;

	@Prop({ type: Map, of: Number, required: true })
	ascensionCosts: Map<number, number>; // R1-R5 costs
}
