import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { StageConstraint } from "@schemas/constraint.schema";
import { AgentCost, EngineCost } from "@schemas/cost.schema";
import { Document, Types } from "mongoose";

export type PresetDocument = DraftPreset & Document;

@Schema()
class GeneralRules {
	@Prop({ required: true, min: 1 })
	minCharacters: number;

	@Prop({ required: true })
	maxCharacters: number;

	@Prop({ required: true, min: 0 })
	minCost: number;

	@Prop({ required: true })
	maxCost: number;

	@Prop({ type: [Number], required: true })
	allowedStages: number[];

	@Prop({ required: true })
	costDifferenceForPreban: number;

	@Prop({ default: false })
	allowMirrorPicks: boolean;

	@Prop({
		type: {
			freeRestarts: { type: Number, required: true },
			paidRestarts: { type: Number, required: true },
			timePenalty: { type: Number, required: true }
		},
		required: true
	})
	restarts: {
		freeRestarts: number;
		paidRestarts: number;
		timePenalty: number; // in seconds
	};
}

@Schema()
export class DraftPhase {
	@Prop({
		required: true,
		enum: ["BAN", "PICK", "PREBANS", "STAGE_BAN", "STAGE_PICK"]
	})
	type: string;

	@Prop({ required: true, enum: [1, 2] })
	player: number;

	@Prop({ required: true, min: 1 })
	count: number;

	@Prop({ required: true })
	timeLimit: number; // in seconds
}

@Schema({ timestamps: true })
export class DraftPreset {
	@Prop({ required: true })
	name: string;

	@Prop()
	description?: string;

	@Prop({ type: GeneralRules, required: true })
	rules: GeneralRules;

	@Prop({ type: [StageConstraint], required: true })
	constraints: StageConstraint[];

	@Prop({ type: [{ type: Types.ObjectId, ref: "Agent" }] })
	pickableAgents?: Types.ObjectId[];

	@Prop({ type: Types.ObjectId, ref: "CostSystem" })
	costSystem?: Types.ObjectId;

	@Prop({ type: [AgentCost] })
	agentCosts?: AgentCost[];

	@Prop({ type: [EngineCost] })
	engineCosts?: EngineCost[];

	@Prop({ type: [DraftPhase], required: true })
	draftFlow: DraftPhase[];

	@Prop({ type: Types.ObjectId, ref: "User" })
	createdBy?: Types.ObjectId;

	@Prop({ required: true, default: 1 })
	version: number;
}

export const DraftPresetSchema = SchemaFactory.createForClass(DraftPreset);
