import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document, Schema as MongooseSchema } from "mongoose";
import { DraftPreset } from "./draft-preset.schema";
import { User } from "./user.schema";

export enum SessionStatus {
	WAITING = "waiting",
	STAGE_BANNING = "stage_banning",
	PREBANNING = "prebanning",
	IN_PROGRESS = "in_progress",
	FINISHED = "finished",
	CANCELLED = "cancelled"
}

export enum DraftPhaseType {
	STAGE_BAN = "stage_ban",
	PREBAN = "preban",
	BAN = "ban",
	PICK = "pick",
	ROOM_ASSIGNMENT = "room_assignment",
	ENGINE_ASSIGNMENT = "engine_assignment",
	READY_CHECK = "ready_check",
	GAME_RESULTS = "game_results"
}

@Schema()
class GameResult {
	@Prop({ required: true, min: 1 })
	gameNumber: number;

	@Prop({ required: true, min: 1, max: 7 })
	stageId: number;

	@Prop({ required: true, enum: [1, 2, 0] }) // 0 for draw
	winner: number;

	@Prop({ required: true, min: 0 })
	timeElapsed: number; // in seconds

	@Prop({ required: true, default: 0, min: 0 })
	freeRestartsUsed: number;

	@Prop({ required: true, default: 0, min: 0 })
	paidRestartsUsed: number;

	@Prop()
	notes?: string;
}

@Schema()
class SessionPlayer {
	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User", required: true })
	userId: User;

	@Prop({ required: true, enum: [1, 2] })
	team: number;

	@Prop({ required: true, default: false })
	isReady: boolean;

	@Prop({
		type: [{ type: MongooseSchema.Types.ObjectId, ref: "Agent" }],
		default: []
	})
	selectedCharacters: string[];

	@Prop({
		type: [{ type: MongooseSchema.Types.ObjectId, ref: "Engine" }],
		default: []
	})
	selectedEngines: string[];

	@Prop({
		type: Map,
		of: [{ type: MongooseSchema.Types.ObjectId, ref: "Agent" }]
	})
	roomAssignments: Map<number, string[]>;

	@Prop({
		type: [{ type: MongooseSchema.Types.ObjectId, ref: "Agent" }],
		default: []
	})
	banList: string[];

	@Prop({
		type: [Number],
		default: []
	})
	bannedStages: number[];

	@Prop({
		type: [{ type: MongooseSchema.Types.ObjectId, ref: "Agent" }],
		default: []
	})
	prebannedAgents: string[];

	@Prop({
		type: Map,
		of: { type: MongooseSchema.Types.ObjectId, ref: "Engine" }
	})
	engineAssignments: Map<string, string>; // Map agent ID to engine ID

	@Prop({ type: Number, default: 0 })
	totalAgentCost: number; // Used for preban calculations

	@Prop({ type: MongooseSchema.Types.ObjectId })
	agentSaveId?: MongooseSchema.Types.ObjectId; // Reference to the agent save being used

	@Prop({
		type: [{ type: MongooseSchema.Types.ObjectId, ref: "Agent" }],
		default: []
	})
	agentSaveAgents?: string[]; // List of agents from the agent save
}

@Schema({ timestamps: true })
export class DraftSession extends Document {
	@Prop({ required: true })
	name: string;

	@Prop({
		type: MongooseSchema.Types.ObjectId,
		ref: "DraftPreset",
		required: true
	})
	presetId: DraftPreset;

	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User" })
	hostId?: User;

	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User" })
	judgeId?: User;

	@Prop({ required: true, default: SessionStatus.WAITING })
	status: SessionStatus;

	@Prop({ required: true, default: 0 })
	currentPhase: number;

	@Prop({ required: true, default: 1 })
	currentTeam: number;

	@Prop({ required: true })
	timeLeft: number;

	@Prop({ type: [SessionPlayer], default: [] })
	players: SessionPlayer[];

	@Prop({
		type: [{ type: MongooseSchema.Types.ObjectId, ref: "User" }],
		default: []
	})
	spectators: string[];

	@Prop()
	password?: string;

	@Prop({ required: false })
	currentStage?: number;

	@Prop({ required: true, default: true })
	allowSpectators: boolean;

	@Prop({ required: true, default: false })
	requireJudge: boolean;

	@Prop({ required: true, default: 1, min: 1 })
	numberOfGames: number; // BO1, BO2, BO3, etc.

	@Prop({ required: true, default: 1, min: 1 })
	currentGameNumber: number;

	@Prop({ type: [Number], default: [] })
	availableStages: number[]; // Stages that are still available after banning

	@Prop({ type: [GameResult], default: [] })
	gameResults: GameResult[];

	@Prop({ required: true, default: false })
	prebansCalculated: boolean;

	@Prop({ required: true, default: false })
	engineAssignmentComplete: boolean;

	@Prop({ required: true, default: false })
	readyForNextGame: boolean;

	@Prop({ type: String, enum: Object.values(DraftPhaseType) })
	currentPhaseType?: DraftPhaseType;

	@Prop()
	startTime?: Date;

	@Prop()
	endTime?: Date;
}

export const DraftSessionSchema = SchemaFactory.createForClass(DraftSession);
