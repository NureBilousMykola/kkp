import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

export type EnemyDocument = Enemy & Document;

@Schema({ timestamps: true })
export class Enemy {
	@Prop({ required: true })
	name: string;

	@Prop({ required: true })
	normalizedName: string;

	@Prop({
		required: true,
		enum: ["ether_mutants", "thugs", "corrupted", "rebel_soldiers", "special"]
	})
	category: string;

	@Prop()
	description?: string;

	@Prop({ type: [String], default: [] })
	weaknessAttributes: string[];

	@Prop({ type: [String], default: [] })
	resistanceAttributes: string[];

	@Prop()
	imageUrl?: string;
}

export const EnemySchema = SchemaFactory.createForClass(Enemy);
