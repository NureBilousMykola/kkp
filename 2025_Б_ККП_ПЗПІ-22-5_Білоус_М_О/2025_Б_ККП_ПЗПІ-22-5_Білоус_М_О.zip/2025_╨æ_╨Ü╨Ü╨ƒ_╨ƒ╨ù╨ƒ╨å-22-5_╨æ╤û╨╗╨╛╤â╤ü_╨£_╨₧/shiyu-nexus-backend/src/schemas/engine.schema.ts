import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document, Schema as MongooseSchema } from "mongoose";
import { Agent } from "./agent.schema";

export type EngineDocument = Engine & Document;

@Schema({ timestamps: true })
export class Engine {
	@Prop({ type: MongooseSchema.Types.ObjectId, auto: true })
	_id: MongooseSchema.Types.ObjectId;

	@Prop({ required: true })
	name: string;

	@Prop({ required: true })
	normalizedName: string;

	@Prop({ required: true, enum: ["S", "A", "B"] })
	rarity: string;

	@Prop({
		required: true,
		enum: ["attack", "anomaly", "defense", "stun", "support"]
	})
	specialty: string;

	@Prop({ required: true, default: false })
	isCraftable: boolean;

	@Prop({ required: true, default: false })
	isEventLimited: boolean;

	@Prop({
		type: MongooseSchema.Types.ObjectId,
		ref: "Agent",
		required: false
	})
	signatureAgent?: Agent;

	@Prop({ min: 1, max: 5, required: true, default: 1 })
	maxAscension: number;

	@Prop()
	imageUrl?: string;
}

export const EngineSchema = SchemaFactory.createForClass(Engine);
