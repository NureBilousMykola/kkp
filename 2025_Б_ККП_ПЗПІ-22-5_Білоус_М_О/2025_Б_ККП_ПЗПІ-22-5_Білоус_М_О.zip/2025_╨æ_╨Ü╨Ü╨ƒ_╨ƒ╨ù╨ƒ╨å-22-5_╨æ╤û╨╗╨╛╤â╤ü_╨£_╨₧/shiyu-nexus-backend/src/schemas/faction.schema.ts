import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document } from "mongoose";

export type FactionDocument = Faction & Document;

@Schema({ timestamps: true })
export class Faction {
	@Prop({ required: true })
	name: string;

	@Prop({ required: true, unique: true })
	normalizedName: string;

	@Prop()
	iconUrl?: string;
}

export const FactionSchema = SchemaFactory.createForClass(Faction);
