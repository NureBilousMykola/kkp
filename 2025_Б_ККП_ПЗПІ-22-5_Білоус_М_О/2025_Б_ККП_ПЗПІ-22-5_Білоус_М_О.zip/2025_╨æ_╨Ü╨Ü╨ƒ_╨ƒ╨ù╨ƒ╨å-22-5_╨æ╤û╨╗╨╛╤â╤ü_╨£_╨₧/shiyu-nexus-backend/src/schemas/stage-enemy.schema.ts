import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { Document } from "mongoose";

export type StageEnemyDocument = StageEnemy & Document;

@Schema({ timestamps: true })
export class StageEnemy {
	@Prop({ required: true, min: 1, max: 7 })
	stageId: number;

	@Prop({ required: true, min: 1, max: 2 })
	roomId: number;

	@Prop([
		{
			enemyId: {
				type: mongoose.Schema.Types.ObjectId,
				ref: "Enemy",
				required: true
			},
			level: { type: Number, required: true }
		}
	])
	enemies: Array<{
		enemyId: mongoose.Schema.Types.ObjectId;
		level: number;
	}>;
}

export const StageEnemySchema = SchemaFactory.createForClass(StageEnemy);

// Add virtual field for population
StageEnemySchema.virtual("enemies.enemy", {
	ref: "Enemy",
	localField: "enemies.enemyId",
	foreignField: "_id",
	justOne: true
});

// Ensure virtual fields are serialized
StageEnemySchema.set("toJSON", { virtuals: true });
StageEnemySchema.set("toObject", { virtuals: true });
