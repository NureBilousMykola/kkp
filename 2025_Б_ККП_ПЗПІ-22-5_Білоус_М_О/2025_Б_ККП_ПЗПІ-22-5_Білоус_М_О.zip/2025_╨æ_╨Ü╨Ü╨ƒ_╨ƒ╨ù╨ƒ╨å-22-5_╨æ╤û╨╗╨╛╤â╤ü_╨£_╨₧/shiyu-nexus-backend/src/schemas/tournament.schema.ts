import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Document, Schema as MongooseSchema } from "mongoose";
import { DraftPreset } from "./draft-preset.schema";
import { User } from "./user.schema";

export enum TournamentStatus {
	REGISTRATION = "registration",
	ONGOING = "ongoing",
	COMPLETED = "completed",
	CANCELLED = "cancelled"
}

export enum TournamentFormat {
	SINGLE_ELIMINATION = "single_elimination",
	DOUBLE_ELIMINATION = "double_elimination",
	ROUND_ROBIN = "round_robin",
	SWISS = "swiss"
}

@Schema()
class TournamentRegistration {
	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User", required: true })
	userId: User;

	@Prop({ type: MongooseSchema.Types.ObjectId, required: true })
	agentSaveId: MongooseSchema.Types.ObjectId;

	@Prop({ required: true, default: false })
	isCheckedIn: boolean;

	@Prop({ default: Date.now })
	registeredAt: Date;

	@Prop()
	checkedInAt?: Date;

	@Prop({ type: Number, default: 0 })
	totalAgentCost: number;

	@Prop({ default: false })
	isEliminated: boolean;

	@Prop({ default: false })
	inLosersBracket: boolean;
}

@Schema()
class TournamentMatch {
	@Prop({ type: MongooseSchema.Types.ObjectId, auto: true })
	_id: MongooseSchema.Types.ObjectId;

	@Prop({ required: true, min: 1 })
	matchNumber: number;

	@Prop({ required: true, min: 1 })
	round: number;

	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User" })
	player1Id?: User;

	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User" })
	player2Id?: User;

	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "DraftSession" })
	draftSessionId?: MongooseSchema.Types.ObjectId;

	@Prop({ enum: [1, 2, null], default: null })
	winner?: number;

	@Prop({ default: false })
	isBye: boolean;

	@Prop({ default: false })
	isCompleted: boolean;

	@Prop({ default: false })
	isReady: boolean;

	@Prop({ enum: ["winners", "losers", "finals", null], default: null })
	bracket?: string;

	@Prop({ default: false })
	isResetMatch?: boolean;

	@Prop()
	scheduledTime?: Date;

	@Prop()
	startTime?: Date;

	@Prop()
	endTime?: Date;
}

@Schema()
class SwissPlayerRecord {
	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User", required: true })
	userId: User;

	@Prop({ default: 0 })
	wins: number;

	@Prop({ default: 0 })
	losses: number;

	@Prop({ default: 0 })
	byes: number;

	@Prop({ default: 0 })
	score: number;

	@Prop({ type: [{ type: MongooseSchema.Types.ObjectId, ref: "User" }] })
	opponents: User[];
}

@Schema({ timestamps: true })
export class Tournament extends Document {
	@Prop({ required: true })
	name: string;

	@Prop()
	description?: string;

	@Prop({
		type: MongooseSchema.Types.ObjectId,
		ref: "DraftPreset",
		required: true
	})
	draftPresetId: DraftPreset;

	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "User", required: true })
	organizerId: User;

	@Prop({ type: [{ type: MongooseSchema.Types.ObjectId, ref: "User" }] })
	moderatorIds?: User[];

	@Prop({
		required: true,
		enum: Object.values(TournamentStatus),
		default: TournamentStatus.REGISTRATION
	})
	status: TournamentStatus;

	@Prop({
		required: true,
		enum: Object.values(TournamentFormat),
		default: TournamentFormat.SINGLE_ELIMINATION
	})
	format: TournamentFormat;

	@Prop({ required: true, min: 4, default: 8 })
	maxParticipants: number;

	@Prop({ required: true, min: 1, default: 1 })
	bestOf: number; // BO1, BO3, BO5, etc.

	@Prop({ required: true })
	registrationStartTime: Date;

	@Prop({ required: true })
	registrationEndTime: Date;

	@Prop({ required: true })
	tournamentStartTime: Date;

	@Prop()
	tournamentEndTime?: Date;

	@Prop({ type: [TournamentRegistration], default: [] })
	registrations: TournamentRegistration[];

	@Prop({ type: [TournamentMatch], default: [] })
	matches: TournamentMatch[];

	@Prop({ default: false })
	bracketsGenerated: boolean;

	@Prop({ default: false })
	requireCheckin: boolean;

	@Prop()
	checkinStartTime?: Date;

	@Prop()
	checkinEndTime?: Date;

	@Prop({ default: false })
	isPublic: boolean;

	@Prop()
	password?: string;

	@Prop({ type: [SwissPlayerRecord], default: [] })
	swissRecords?: SwissPlayerRecord[];
}

export const TournamentSchema = SchemaFactory.createForClass(Tournament);
