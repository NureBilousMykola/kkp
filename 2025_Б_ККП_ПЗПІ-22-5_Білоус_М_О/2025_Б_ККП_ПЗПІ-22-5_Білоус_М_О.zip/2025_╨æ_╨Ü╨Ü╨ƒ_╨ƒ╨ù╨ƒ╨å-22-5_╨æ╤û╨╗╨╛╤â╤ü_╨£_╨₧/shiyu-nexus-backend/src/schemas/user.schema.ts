import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { Schema as MongooseSchema } from "mongoose";
import { Agent } from "./agent.schema";
import { Bangboo } from "./bangboo.schema";
import { Engine } from "./engine.schema";

export interface UserDocument extends User, Document {
	_id: string;
	discordUsername?: string;
	discordAvatar?: string;
	discordAccessToken?: string;
	discordRefreshToken?: string;
	save: () => Promise<UserDocument>;
}

@Schema()
class OwnedAgent {
	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "Agent" })
	agent: Agent;

	@Prop({ required: true, min: 1, max: 60 })
	level: number;

	@Prop({ required: true, min: 0, max: 6 })
	mindscape: number;
}

@Schema()
class AgentSave {
	@Prop({ type: MongooseSchema.Types.ObjectId, auto: true })
	_id: MongooseSchema.Types.ObjectId;

	@Prop({ required: true })
	name: string;

	@Prop({ required: true })
	description: string;

	@Prop({ type: [{ type: MongooseSchema.Types.ObjectId, ref: "Agent" }] })
	agents: Agent[];

	@Prop({ default: Date.now })
	createdAt: Date;

	@Prop({ default: Date.now })
	updatedAt: Date;
}

@Schema()
class OwnedEngine {
	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "Engine" })
	engine: Engine;

	@Prop({ required: true, min: 1, max: 60 })
	level: number;

	@Prop({ required: true, min: 1, max: 5 })
	ascension: number;
}

@Schema()
class OwnedBangboo {
	@Prop({ type: MongooseSchema.Types.ObjectId, ref: "Bangboo" })
	bangboo: Bangboo;

	@Prop({ required: true, min: 1, max: 60 })
	level: number;

	@Prop({ required: true, min: 1, max: 5 })
	ascension: number;
}

@Schema({ timestamps: true })
export class User {
	@Prop({ required: true, unique: true })
	email: string;

	@Prop({ required: true, unique: true })
	username: string;

	@Prop()
	passwordHash?: string;

	@Prop()
	discordId?: string;

	@Prop()
	discordUsername?: string;

	@Prop()
	discordAvatar?: string;

	@Prop()
	discordAccessToken?: string;

	@Prop()
	discordRefreshToken?: string;

	@Prop({
		required: true,
		enum: ["user", "moderator", "admin"],
		default: "user"
	})
	role: string;

	@Prop({ type: [String], default: [] })
	permissions: string[];

	@Prop({ type: [OwnedAgent], default: [] })
	ownedAgents: OwnedAgent[];

	@Prop({ type: [OwnedEngine], default: [] })
	ownedEngines: OwnedEngine[];

	@Prop({ type: [OwnedBangboo], default: [] })
	ownedBangboos: OwnedBangboo[];

	@Prop({ type: [AgentSave], default: [] })
	agentSaves: AgentSave[];
}

export const UserSchema = SchemaFactory.createForClass(User);
