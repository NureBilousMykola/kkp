export const ATTRIBUTES = {
	PHYSICAL: "physical",
	FIRE: "fire",
	ICE: "ice",
	ETHER: "ether",
	ELECTRIC: "electric",
	FROST: "frost"
} as const;

export const SPECIALTIES = {
	ATTACK: "attack",
	ANOMALY: "anomaly",
	DEFENSE: "defense",
	STUN: "stun",
	SUPPORT: "support"
} as const;

// For easier iteration
export const AttributeValues = Object.values(ATTRIBUTES);
export const SpecialtyValues = Object.values(SPECIALTIES);
