/**
 * Permission constants for the application
 * These are used to define what actions different roles can perform
 */
export const Permissions = {
	// User management permissions
	USER_VIEW: "user:view",
	USER_CREATE: "user:create",
	USER_UPDATE: "user:update",
	USER_DELETE: "user:delete",

	// Content management permissions
	CONTENT_VIEW: "content:view",
	CONTENT_CREATE: "content:create",
	CONTENT_UPDATE: "content:update",
	CONTENT_DELETE: "content:delete",

	// Agent management permissions
	AGENT_VIEW: "agent:view",
	AGENT_CREATE: "agent:create",
	AGENT_UPDATE: "agent:update",
	AGENT_DELETE: "agent:delete",

	// Engine management permissions
	ENGINE_VIEW: "engine:view",
	ENGINE_CREATE: "engine:create",
	ENGINE_UPDATE: "engine:update",
	ENGINE_DELETE: "engine:delete",

	// Bangboo management permissions
	BANGBOO_VIEW: "bangboo:view",
	BANGBOO_CREATE: "bangboo:create",
	BANGBOO_UPDATE: "bangboo:update",
	BANGBOO_DELETE: "bangboo:delete",

	// Enemy management permissions
	ENEMY_VIEW: "enemy:view",
	ENEMY_CREATE: "enemy:create",
	ENEMY_UPDATE: "enemy:update",
	ENEMY_DELETE: "enemy:delete",

	// Faction management permissions
	FACTION_VIEW: "faction:view",
	FACTION_CREATE: "faction:create",
	FACTION_UPDATE: "faction:update",
	FACTION_DELETE: "faction:delete",

	// Draft management permissions
	DRAFT_MANAGE: "draft:manage",

	// Preset management permissions
	PRESET_MANAGE: "preset:manage",

	// Tournament management permissions
	TOURNAMENT_MANAGE: "tournament:manage"
};

/**
 * Default permissions for each role
 */
export const RolePermissions = {
	// Regular users have minimal permissions
	user: [],

	// Moderators can view all content and update some content
	moderator: [
		Permissions.USER_VIEW,
		Permissions.CONTENT_VIEW,
		Permissions.CONTENT_UPDATE,
		Permissions.AGENT_VIEW,
		Permissions.AGENT_UPDATE,
		Permissions.ENGINE_VIEW,
		Permissions.ENGINE_UPDATE,
		Permissions.BANGBOO_VIEW,
		Permissions.BANGBOO_UPDATE,
		Permissions.ENEMY_VIEW,
		Permissions.ENEMY_UPDATE,
		Permissions.FACTION_VIEW,
		Permissions.FACTION_UPDATE,
		Permissions.DRAFT_MANAGE,
		Permissions.PRESET_MANAGE,
		Permissions.TOURNAMENT_MANAGE
	],

	// Admins have all permissions
	admin: ["*"] // Wildcard for all permissions
};
