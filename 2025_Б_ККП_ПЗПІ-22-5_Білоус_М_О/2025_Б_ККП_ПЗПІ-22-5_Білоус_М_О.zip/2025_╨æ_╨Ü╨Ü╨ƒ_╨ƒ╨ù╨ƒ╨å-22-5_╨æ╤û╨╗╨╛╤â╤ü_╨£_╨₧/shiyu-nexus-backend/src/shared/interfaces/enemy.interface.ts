export interface EnemyResponse {
	id: string;
	name: string;
	description?: string;
	imageUrl?: string;
	weaknessAttributes: string[];
	resistanceAttributes: string[];
	createdAt: Date;
	updatedAt: Date;
}

export interface StageEnemyResponse {
	id: string;
	stageId: number;
	roomId: number;
	level: number;
	enemy: EnemyResponse;
	createdAt: Date;
	updatedAt: Date;
}
