import { EnemyResponse } from "./enemy.interface";

export interface StageConfiguration {
	stageId: number;
	rooms: RoomConfiguration[];
}

export interface RoomConfiguration {
	roomId: number;
	enemy: EnemyResponse;
	level: number;
}
