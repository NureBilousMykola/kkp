import { ATTRIBUTES, SPECIALTIES } from "../constants/constants";

export type AttributeType = (typeof ATTRIBUTES)[keyof typeof ATTRIBUTES];
export type SpecialtyType = (typeof SPECIALTIES)[keyof typeof SPECIALTIES];
