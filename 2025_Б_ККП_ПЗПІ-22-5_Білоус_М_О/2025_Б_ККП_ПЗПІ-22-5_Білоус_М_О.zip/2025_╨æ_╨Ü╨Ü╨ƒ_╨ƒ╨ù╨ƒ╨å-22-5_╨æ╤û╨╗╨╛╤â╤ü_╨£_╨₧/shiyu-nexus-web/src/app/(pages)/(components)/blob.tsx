"use client";

import useMousePosition from "@/lib/hooks/useMousePosition";
import { useEffect, useState, useRef, useCallback } from "react";

export const Blob = () => {
	const { x, y } = useMousePosition();
	const [displaySize, setDisplaySize] = useState("420px");
	const [targetSize, setTargetSize] = useState("420px");

	const currentPosRef = useRef({ x: 0, y: 0 });
	const targetPosRef = useRef({ x: 0, y: 0 });
	const divRef = useRef<HTMLDivElement>(null);
	const animationRef = useRef<number | null>(null);

	const animate = useCallback(() => {
		const lerp = (start: number, end: number, factor: number) => {
			return start * (1 - factor) + end * factor;
		};

		// Get current target position based on cursor or stuck element
		targetPosRef.current = { x, y };

		// Update current position with lerp
		currentPosRef.current.x = lerp(
			currentPosRef.current.x,
			targetPosRef.current.x,
			0.05
		);
		currentPosRef.current.y = lerp(
			currentPosRef.current.y,
			targetPosRef.current.y,
			0.05
		);

		// Also lerp the size
		const currentSizeValue = Number.parseFloat(displaySize);
		const targetSizeValue = Number.parseFloat(targetSize);

		const newSize = lerp(currentSizeValue, targetSizeValue, 0.01);
		setDisplaySize(`${newSize}px`);

		// Apply the position if the div exists
		if (divRef.current) {
			divRef.current.style.left = `${currentPosRef.current.x}px`;
			divRef.current.style.top = `${currentPosRef.current.y}px`;
		}

		// Continue the animation loop
		animationRef.current = requestAnimationFrame(animate);
	}, [x, y, displaySize, targetSize]);

	useEffect(() => {
		animationRef.current = requestAnimationFrame(animate);

		return () => {
			if (animationRef.current) {
				cancelAnimationFrame(animationRef.current);
			}
		};
	}, [animate]);

	useEffect(() => {
		const nodes = document.querySelectorAll("[data-highlight-cursor]");

		for (const node of nodes) {
			node.addEventListener("mouseenter", () => {
				const rect = node.getBoundingClientRect();
				const elementSize = Math.max(rect.width, rect.height);
				setTargetSize(`${elementSize}px`);
			});

			node.addEventListener("mouseleave", () => {
				setTargetSize("420px");
			});
		}

		return () => {
			for (const node of nodes) {
				node.removeEventListener("mouseenter", () => {});
				node.removeEventListener("mouseleave", () => {});
			}
		};
	}, []);

	return (
		<div
			ref={divRef}
			style={{
				height: displaySize,
				width: displaySize,
				transform: "translate(-50%, -50%)",
				position: "fixed"
			}}
		>
			<div className="aspect-square animate-spin rounded-full bg-gradient-to-l from-fire to-ether [animation-duration:10s]" />
		</div>
	);
};
