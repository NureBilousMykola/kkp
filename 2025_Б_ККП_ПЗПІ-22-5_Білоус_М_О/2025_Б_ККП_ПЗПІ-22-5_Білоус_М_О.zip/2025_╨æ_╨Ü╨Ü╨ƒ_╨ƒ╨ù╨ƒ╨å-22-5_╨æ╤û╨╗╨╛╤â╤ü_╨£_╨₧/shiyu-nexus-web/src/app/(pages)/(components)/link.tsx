"use client";

import { cn } from "@/lib/utils";
import { Grid, GridPatternBlock } from "./grid";
import { useEffect, useRef, useState } from "react";
import Image from "next/image";

const baseLinkStyle =
	"group relative flex duration-500 hover:shadow-[0px_0px_125px_0px_rgba(254,66,126,0.2)] hover:border-white/20 aspect-square hover md:aspect-video lg:aspect-square items-center justify-center rounded-xl overflow-hidden border-4 border-transparent p-4 text-center md:text-4xl font-bold border-white/10 transition-all";

interface HomepageLinkProps {
	href: string;
	text: string;
	img: string;
	className?: string;
}

export const HomepageLink: React.FC<HomepageLinkProps> = ({
	href,
	text,
	img,
	className
}) => {
	const [gridCellSize, setGridCellSize] = useState(0);
	const linkRef = useRef<HTMLAnchorElement>(null);

	// Generate all grid coordinates
	const [allBlocks, setAllBlocks] = useState<
		[number, number, string, string][]
	>([]);

	useEffect(() => {
		setGridCellSize((linkRef.current?.offsetWidth || 0) / 10);
		const blocks: [number, number, string, string][] = [];
		for (let row = 0; row < 15; row++) {
			for (let column = 0; column < 15; column++) {
				const delay = `${Math.random() * 5}s`;
				const duration = `${5 + Math.random()}s`; // between 5s and 6s
				blocks.push([row, column, delay, duration]);
			}
		}
		setAllBlocks(blocks);
	}, []);

	return (
		<a
			ref={linkRef}
			href={href}
			data-highlight-cursor
			className={cn(className, baseLinkStyle)}
		>
			<Grid
				offsetX={0}
				offsetY={0}
				size={gridCellSize}
				className="group -inset-x-0.5 -top-1/4 absolute h-[150%] w-full skew-y-12 stroke-[2] stroke-foreground/10 [mask-image:radial-gradient(white,transparent_70%)]"
			>
				{allBlocks.map(([row, column, delay, duration]) => {
					return (
						<GridPatternBlock
							key={`block-${row}-${column}`}
							row={row}
							column={column}
							className={cn("animate-pulse not-dark:invert")}
							style={{
								animationDelay: delay,
								animationDuration: duration
							}}
						/>
					);
				})}
			</Grid>
			<div className="-z-10 absolute inset-0 backdrop-blur-[5vmax] backdrop-filter" />

			<div className="absolute inset-0 z-10">
				<Image
					src={img}
					className="-translate-y-full xl:-translate-y-1/2 -translate-x-1/2 absolute top-1/2 left-1/2 aspect-square w-16 object-contain transition-all group-hover:opacity-100 xl:w-32 xl:opacity-0"
					alt={text}
					width={200}
					height={200}
				/>
				<div className="xl:-translate-y-1/2 -translate-x-1/2 absolute top-1/2 left-1/2 transition-all group-hover:translate-y-16">
					{text}
				</div>
			</div>
		</a>
	);
};
