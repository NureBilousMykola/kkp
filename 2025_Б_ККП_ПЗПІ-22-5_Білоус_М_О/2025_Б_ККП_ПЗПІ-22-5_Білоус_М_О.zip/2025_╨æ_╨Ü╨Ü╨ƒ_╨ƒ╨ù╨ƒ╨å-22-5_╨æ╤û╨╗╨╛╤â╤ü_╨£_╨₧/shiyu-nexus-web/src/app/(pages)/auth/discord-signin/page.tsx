"use client";

import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function DiscordSignIn() {
	const router = useRouter();

	useEffect(() => {
		// The page automatically attempts to sign in with the token stored in cookies
		const signInWithDiscordToken = async () => {
			try {
				const result = await signIn("discord-signin-token", {
					redirect: false
				});

				if (result?.error) {
					// Handle error
					console.error("Sign in error:", result.error);
					router.push("/auth/login?error=AuthenticationError");
				} else {
					// Success - redirect to home or dashboard
					router.push("/home");
				}
			} catch (error) {
				console.error("Sign in exception:", error);
				router.push("/auth/login?error=AuthenticationError");
			}
		};

		void signInWithDiscordToken();
	}, [router]);

	return (
		<div className="flex min-h-screen items-center justify-center">
			<div className="text-center">
				<h1 className="mb-4 font-bold text-2xl">Completing Discord Sign In</h1>
				<p className="text-muted-foreground">
					Please wait, you'll be redirected shortly...
				</p>
				{/* You can add a spinner here */}
				<div className="mx-auto mt-4 h-8 w-8 animate-spin rounded-full border-4 border-current border-r-transparent border-solid" />
			</div>
		</div>
	);
}
