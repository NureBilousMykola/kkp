"use client";

import { Button } from "@/components/ui/button";
import { signup } from "@/lib/actions/auth/signup";
import { DiscordLoginButton } from "@components/auth/discord-login-button";
import { useActionState } from "react";

export default function SignupForm() {
	const [state, action, pending] = useActionState(signup, undefined);

	return (
		<div className="mx-8 grid w-full max-w-md gap-6">
			<form action={action} className="space-y-4">
				<div>
					<label
						htmlFor="username"
						className="block font-medium text-gray-700 text-sm"
					>
						Username
					</label>
					<input
						id="username"
						name="username"
						type="text"
						placeholder="Enter your username"
						className="mt-1 block w-full rounded-md border bg-background px-3 py-2 text-accent-foreground shadow-sm focus:border-primary focus:outline-none focus:ring-primary"
					/>
					{state?.errors?.username && (
						<p className="mt-1 text-destructive text-sm">
							{state.errors.username}
						</p>
					)}
				</div>

				<div>
					<label
						htmlFor="email"
						className="block font-medium text-gray-700 text-sm"
					>
						Password
					</label>
					<input
						id="email"
						name="email"
						type="email"
						placeholder="Enter your email"
						className="mt-1 block w-full rounded-md border bg-background px-3 py-2 text-accent-foreground shadow-sm focus:border-primary focus:outline-none focus:ring-primary"
					/>
					{state?.errors?.password && (
						<div className="mt-1 text-destructive text-sm">
							<p>Password must:</p>
							<ul className="list-inside list-disc">
								{state.errors.password.map((error: string) => (
									<li key={error}>{error}</li>
								))}
							</ul>
						</div>
					)}
				</div>

				<div>
					<label
						htmlFor="password"
						className="block font-medium text-gray-700 text-sm"
					>
						Password
					</label>
					<input
						id="password"
						name="password"
						type="password"
						placeholder="Enter your password"
						className="mt-1 block w-full rounded-md border bg-background px-3 py-2 text-accent-foreground shadow-sm focus:border-primary focus:outline-none focus:ring-primary"
					/>
					{state?.errors?.password && (
						<div className="mt-1 text-destructive text-sm">
							<p>Password must:</p>
							<ul className="list-inside list-disc">
								{state.errors.password.map((error: string) => (
									<li key={error}>{error}</li>
								))}
							</ul>
						</div>
					)}
				</div>

				<Button
					type="submit"
					disabled={pending}
					className="w-full cursor-pointer"
				>
					{pending ? "Signing in..." : "Sign In"}
				</Button>
			</form>

			<div className="relative z-10 mt-4">
				<span className="z-11 mx-auto block w-fit bg-background px-2">
					Or continue with
				</span>

				<hr className="-translate-y-1/2 -z-10 absolute inset-0 top-1/2" />
			</div>

			<DiscordLoginButton />
		</div>
	);
}
