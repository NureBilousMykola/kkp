import { verifySession } from "@/lib/utils/dal";
import { DraftGameProviders } from "./providers";

export default async function ProfileLayout({
	children
}: { children: React.ReactNode }) {
	const session = await verifySession();

	return (
		<DraftGameProviders token={session.token}>{children}</DraftGameProviders>
	);
}
