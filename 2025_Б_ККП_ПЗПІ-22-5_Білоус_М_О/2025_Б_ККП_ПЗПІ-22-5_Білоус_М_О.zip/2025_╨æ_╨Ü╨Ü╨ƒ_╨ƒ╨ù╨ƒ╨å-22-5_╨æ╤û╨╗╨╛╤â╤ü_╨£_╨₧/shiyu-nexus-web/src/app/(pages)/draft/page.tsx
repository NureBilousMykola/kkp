"use client";

import { useGameInfo } from "@/lib/contexts/gameContext";
import { useState, useEffect } from "react";
import { gameSessionService } from "@/lib/api/services/game/service";
import { presetService } from "@/lib/api/services/presets/service";

import type { IDraftPreset } from "@/lib/api/models/game/IDraftPreset";
import type { IGameSession } from "@/lib/api/models/game/IGameSession";
import { Button } from "@/components/ui/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Copy, Users, Eye, Play, Plus, Gamepad2 } from "lucide-react";

interface CreateSessionFormData {
	presetId: string;
	title: string;
	description: string;
	password: string;
	numberOfGames: number;
	allowSpectators: boolean;
}

export default function DraftPage() {
	const gameInfo = useGameInfo();
	const { token } = gameInfo;

	const [presets, setPresets] = useState<IDraftPreset[]>([]);
	const [activeSessions, setActiveSessions] = useState<IGameSession[]>([]);
	const [createdSession, setCreatedSession] = useState<IGameSession | null>(
		null
	);
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState<string>("");

	const [formData, setFormData] = useState<CreateSessionFormData>({
		presetId: "",
		title: "",
		description: "",
		password: "",
		numberOfGames: 1,
		allowSpectators: true
	});

	// Load data on mount
	useEffect(() => {
		if (!token) return;

		const loadData = async () => {
			try {
				const [presetsResponse, sessionsResponse] = await Promise.all([
					presetService.getPresets(),
					gameSessionService.getAllSessions(token)
				]);

				if (presetsResponse.ok) setPresets(presetsResponse.data || []);
				if (sessionsResponse.ok) setActiveSessions(sessionsResponse.data || []);
			} catch (error) {
				console.error("Failed to load data:", error);
				setError("Failed to load draft data");
			}
		};

		loadData();
	}, [token]);

	const handleCreateSession = async (e: React.FormEvent) => {
		e.preventDefault();
		if (!formData.presetId) {
			setError("Please select a preset");
			return;
		}

		if (!token) {
			setError("Authentication required. Please log in.");
			return;
		}

		setIsLoading(true);
		setError("");

		console.log("Creating session with token:", token ? "present" : "missing");
		console.log("Session data:", {
			presetId: formData.presetId,
			name: formData.title || "Draft Session",
			password: formData.password || undefined,
			numberOfGames: formData.numberOfGames,
			allowSpectators: formData.allowSpectators
		});

		try {
			const response = await gameSessionService.createSession(token, {
				presetId: formData.presetId,
				name: formData.title || "Draft Session",
				password: formData.password || undefined,
				numberOfGames: formData.numberOfGames,
				allowSpectators: formData.allowSpectators
			});

			if (response.ok && response.data) {
				setCreatedSession(response.data);

				// Refresh active sessions
				const sessionsResponse = await gameSessionService.getAllSessions(token);
				if (sessionsResponse.ok) setActiveSessions(sessionsResponse.data || []);
			} else {
				console.error("Session creation failed:", response);
				setError(
					`Failed to create session: ${response.error || "Unknown error"}`
				);
			}
		} catch (error) {
			console.error("Error creating session:", error);
			setError("Failed to create draft session");
		} finally {
			setIsLoading(false);
		}
	};

	const copyToClipboard = async (text: string, type: string) => {
		try {
			await navigator.clipboard.writeText(text);
			// Simple alert for now instead of toast
			alert(`${type} link copied to clipboard!`);
		} catch (error) {
			alert("Failed to copy to clipboard");
		}
	};

	const getSessionLink = (
		sessionId: string,
		role: "player1" | "player2" | "spectator"
	) => {
		const baseUrl = window.location.origin;
		return `${baseUrl}/draft/session/${sessionId}?role=${role}`;
	};

	const selectedPreset = presets.find((p) => p._id === formData.presetId);

	return (
		<div className="container mx-auto p-6 space-y-8">
			<div className="text-center space-y-2">
				<h1 className="text-4xl font-bold">Draft Hub</h1>
				<p className="text-muted-foreground">
					Create and manage draft sessions
				</p>
			</div>

			{error && (
				<div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
					{error}
				</div>
			)}

			<div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
				{/* Create Session Form */}
				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Plus className="h-5 w-5" />
							Create New Draft Session
						</CardTitle>
						<CardDescription>
							Set up a new draft session for players to compete
						</CardDescription>
					</CardHeader>
					<CardContent>
						<form onSubmit={handleCreateSession} className="space-y-4">
							<div className="space-y-2">
								<Label htmlFor="preset">Draft Preset</Label>
								<Select
									value={formData.presetId}
									onValueChange={(value) =>
										setFormData((prev) => ({ ...prev, presetId: value }))
									}
								>
									<SelectTrigger>
										<SelectValue placeholder="Select a draft preset" />
									</SelectTrigger>
									<SelectContent>
										{presets.map((preset) => (
											<SelectItem key={preset._id} value={preset._id}>
												{preset.name}
											</SelectItem>
										))}
									</SelectContent>
								</Select>
								{selectedPreset && (
									<p className="text-sm text-muted-foreground">
										{selectedPreset.description}
									</p>
								)}
							</div>

							<div className="space-y-2">
								<Label htmlFor="title">Session Title (Optional)</Label>
								<Input
									id="title"
									placeholder="Epic Draft Battle"
									value={formData.title}
									onChange={(e) =>
										setFormData((prev) => ({ ...prev, title: e.target.value }))
									}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="description">Description (Optional)</Label>
								<Textarea
									id="description"
									placeholder="Tournament semifinals match..."
									value={formData.description}
									onChange={(e) =>
										setFormData((prev) => ({
											...prev,
											description: e.target.value
										}))
									}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="password">Password (Optional)</Label>
								<Input
									id="password"
									type="password"
									placeholder="Leave empty for public session"
									value={formData.password}
									onChange={(e) =>
										setFormData((prev) => ({
											...prev,
											password: e.target.value
										}))
									}
								/>
							</div>

							<div className="space-y-2">
								<Label htmlFor="numberOfGames">Number of Games</Label>
								<Select
									value={formData.numberOfGames.toString()}
									onValueChange={(value) =>
										setFormData((prev) => ({
											...prev,
											numberOfGames: Number.parseInt(value)
										}))
									}
								>
									<SelectTrigger>
										<SelectValue />
									</SelectTrigger>
									<SelectContent>
										{[1, 3, 5, 7].map((num) => (
											<SelectItem key={num} value={num.toString()}>
												{num === 1 ? "1 Game" : `Best of ${num}`}
											</SelectItem>
										))}
									</SelectContent>
								</Select>
							</div>

							<div className="flex items-center space-x-2">
								<Switch
									id="allowSpectators"
									checked={formData.allowSpectators}
									onCheckedChange={(checked) =>
										setFormData((prev) => ({
											...prev,
											allowSpectators: checked
										}))
									}
								/>
								<Label htmlFor="allowSpectators">Allow Spectators</Label>
							</div>

							<Button type="submit" className="w-full" disabled={isLoading}>
								{isLoading ? "Creating..." : "Create Draft Session"}
							</Button>
						</form>
					</CardContent>
				</Card>

				{/* Session Links */}
				{createdSession && (
					<Card>
						<CardHeader>
							<CardTitle className="flex items-center gap-2">
								<Gamepad2 className="h-5 w-5" />
								Session Created!
							</CardTitle>
							<CardDescription>
								Share these links with players and spectators
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-4">
							<div className="text-center p-4 border rounded-lg bg-muted/50">
								<h3 className="font-semibold">
									{createdSession.title || "Draft Session"}
								</h3>
								<p className="text-sm text-muted-foreground">
									ID: {createdSession._id}
								</p>
							</div>

							<div className="space-y-3">
								<div>
									<Label className="text-sm font-medium flex items-center gap-2 mb-2">
										<Users className="h-4 w-4 text-blue-500" />
										Player 1 Link
									</Label>
									<div className="flex gap-2">
										<Input
											readOnly
											value={getSessionLink(createdSession._id, "player1")}
											className="text-xs"
										/>
										<Button
											size="sm"
											variant="outline"
											onClick={() =>
												copyToClipboard(
													getSessionLink(createdSession._id, "player1"),
													"Player 1"
												)
											}
										>
											<Copy className="h-4 w-4" />
										</Button>
									</div>
								</div>

								<div>
									<Label className="text-sm font-medium flex items-center gap-2 mb-2">
										<Users className="h-4 w-4 text-green-500" />
										Player 2 Link
									</Label>
									<div className="flex gap-2">
										<Input
											readOnly
											value={getSessionLink(createdSession._id, "player2")}
											className="text-xs"
										/>
										<Button
											size="sm"
											variant="outline"
											onClick={() =>
												copyToClipboard(
													getSessionLink(createdSession._id, "player2"),
													"Player 2"
												)
											}
										>
											<Copy className="h-4 w-4" />
										</Button>
									</div>
								</div>

								{createdSession.allowSpectators && (
									<div>
										<Label className="text-sm font-medium flex items-center gap-2 mb-2">
											<Eye className="h-4 w-4 text-purple-500" />
											Spectator Link
										</Label>
										<div className="flex gap-2">
											<Input
												readOnly
												value={getSessionLink(createdSession._id, "spectator")}
												className="text-xs"
											/>
											<Button
												size="sm"
												variant="outline"
												onClick={() =>
													copyToClipboard(
														getSessionLink(createdSession._id, "spectator"),
														"Spectator"
													)
												}
											>
												<Copy className="h-4 w-4" />
											</Button>
										</div>
									</div>
								)}
							</div>

							<Separator />

							<Button
								className="w-full"
								onClick={() =>
									window.open(
										`/draft/session/${createdSession._id}?role=host`,
										"_blank"
									)
								}
							>
								<Play className="h-4 w-4 mr-2" />
								Enter as Host
							</Button>
						</CardContent>
					</Card>
				)}
			</div>

			{/* Active Sessions */}
			{activeSessions.length > 0 && (
				<Card>
					<CardHeader>
						<CardTitle>Active Draft Sessions</CardTitle>
						<CardDescription>
							Currently running sessions you can join
						</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
							{activeSessions.map((session) => (
								<Card key={session._id} className="border-2">
									<CardHeader className="pb-3">
										<CardTitle className="text-lg">
											{session.title || "Draft Session"}
										</CardTitle>
										<CardDescription className="text-xs">
											{session.description ||
												`Game ${session.currentGameNumber}/${session.numberOfGames}`}
										</CardDescription>
									</CardHeader>
									<CardContent className="pt-0 space-y-3">
										<div className="flex items-center justify-between">
											<Badge
												variant={
													session.status === "waiting" ? "secondary" : "default"
												}
											>
												{session.status}
											</Badge>
											<span className="text-xs text-muted-foreground">
												{session.players.length}/2 players
											</span>
										</div>

										<Button
											size="sm"
											className="w-full"
											onClick={() =>
												window.open(`/draft/session/${session._id}`, "_blank")
											}
										>
											View Session
										</Button>
									</CardContent>
								</Card>
							))}
						</div>
					</CardContent>
				</Card>
			)}
		</div>
	);
}
