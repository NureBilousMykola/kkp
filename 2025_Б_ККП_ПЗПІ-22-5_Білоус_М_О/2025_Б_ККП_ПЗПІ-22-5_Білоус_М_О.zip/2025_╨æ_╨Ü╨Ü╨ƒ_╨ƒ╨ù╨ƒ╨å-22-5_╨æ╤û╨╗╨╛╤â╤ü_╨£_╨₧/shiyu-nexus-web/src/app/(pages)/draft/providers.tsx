import { GameProvider } from "@/lib/contexts/gameContext";

export function DraftGameProviders({
	token,
	children
}: {
	children: React.ReactNode;
	token: string;
}) {
	return <GameProvider token={token}>{children}</GameProvider>;
}
