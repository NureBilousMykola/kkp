"use client";

import { useGameInfo } from "@/lib/contexts/gameContext";
import { useState, useEffect } from "react";
import { useParams, useSearchParams } from "next/navigation";
import { gameSessionService } from "@/lib/api/services/game/service";

import type { IGameSession } from "@/lib/api/models/game/IGameSession";
import { Button } from "@/components/ui/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Users, Eye, Crown, Gamepad2, Clock, Play } from "lucide-react";

type UserRole = "player1" | "player2" | "spectator" | "host";

export default function DraftSessionPage() {
	const gameInfo = useGameInfo();
	const { token } = gameInfo;
	const params = useParams();
	const searchParams = useSearchParams();

	const sessionId = params.id as string;
	const role = (searchParams.get("role") as UserRole) || "spectator";

	const [session, setSession] = useState<IGameSession | null>(null);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState<string>("");
	const [hasJoined, setHasJoined] = useState(false);

	// Load session and user data
	useEffect(() => {
		if (!token) return;

		const loadData = async () => {
			try {
				const response = await gameSessionService.getSession(token, sessionId);
				if (response.ok && response.data) {
					setSession(response.data);
				} else {
					setError("Session not found");
				}
			} catch (error) {
				console.error("Failed to load session:", error);
				setError("Failed to load session");
			} finally {
				setIsLoading(false);
			}
		};

		loadData();
	}, [sessionId, token]);

	// Connect to websocket when session is loaded
	useEffect(() => {
		if (session && !gameInfo.session) {
			console.log(
				"Connecting to WebSocket for session:",
				sessionId,
				"with token:",
				token ? "present" : "missing"
			);
			gameInfo.connect(sessionId);
		}
	}, [session, sessionId, gameInfo, token]);

	// Update session when websocket provides updates
	useEffect(() => {
		if (gameInfo.session) {
			setSession(gameInfo.session);
		}
	}, [gameInfo.session]);

	const handleJoinSession = async () => {
		if (!session || !token) return;

		try {
			const teamNumber = role === "player1" ? 1 : role === "player2" ? 2 : null;

			if (role === "spectator") {
				const response = await gameSessionService.addSpectator(
					token,
					sessionId
				);
				if (response.ok) {
					setHasJoined(true);
				}
			} else if (teamNumber) {
				const response = await gameSessionService.joinSession(
					token,
					sessionId,
					{
						team: teamNumber,
						password: session.password || undefined
					}
				);
				if (response.ok) {
					setHasJoined(true);
				}
			}
		} catch (error) {
			console.error("Failed to join session:", error);
			setError("Failed to join session");
		}
	};

	const handleSetReady = async () => {
		if (!token) return;

		try {
			await gameSessionService.setReady(token, sessionId);
		} catch (error) {
			console.error("Failed to set ready:", error);
			setError("Failed to set ready");
		}
	};

	const getRoleIcon = (userRole: UserRole) => {
		switch (userRole) {
			case "host":
				return <Crown className="h-4 w-4" />;
			case "player1":
				return <Users className="h-4 w-4 text-blue-500" />;
			case "player2":
				return <Users className="h-4 w-4 text-green-500" />;
			case "spectator":
				return <Eye className="h-4 w-4 text-purple-500" />;
			default:
				return <Gamepad2 className="h-4 w-4" />;
		}
	};

	const getRoleLabel = (userRole: UserRole) => {
		switch (userRole) {
			case "host":
				return "Host";
			case "player1":
				return "Player 1";
			case "player2":
				return "Player 2";
			case "spectator":
				return "Spectator";
			default:
				return "Unknown";
		}
	};

	if (isLoading) {
		return (
			<div className="container mx-auto p-6">
				<div className="text-center">
					<div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto" />
					<p className="mt-4 text-muted-foreground">Loading session...</p>
				</div>
			</div>
		);
	}

	if (error || !session) {
		return (
			<div className="container mx-auto p-6">
				<Card>
					<CardContent className="p-6 text-center">
						<h2 className="text-xl font-semibold text-red-600 mb-2">Error</h2>
						<p className="text-muted-foreground">
							{error || "Session not found"}
						</p>
						<Button
							className="mt-4"
							onClick={() => {
								window.location.href = "/draft";
							}}
						>
							Back to Draft Hub
						</Button>
					</CardContent>
				</Card>
			</div>
		);
	}

	return (
		<div className="container mx-auto p-6 space-y-6">
			{/* Session Header */}
			<Card>
				<CardHeader>
					<div className="flex items-center justify-between">
						<div>
							<CardTitle className="flex items-center gap-2">
								<Gamepad2 className="h-6 w-6" />
								{session.title || "Draft Session"}
							</CardTitle>
							<CardDescription>
								{session.description ||
									`Game ${session.currentGameNumber}/${session.numberOfGames}`}
							</CardDescription>
						</div>
						<div className="flex items-center gap-2">
							{getRoleIcon(role)}
							<Badge variant="outline">{getRoleLabel(role)}</Badge>
						</div>
					</div>
				</CardHeader>
				<CardContent className="space-y-4">
					<div className="grid grid-cols-2 md:grid-cols-4 gap-4">
						<div className="text-center">
							<div className="text-2xl font-bold">{session.status}</div>
							<div className="text-sm text-muted-foreground">Status</div>
						</div>
						<div className="text-center">
							<div className="text-2xl font-bold">
								{session.players.length}/2
							</div>
							<div className="text-sm text-muted-foreground">Players</div>
						</div>
						<div className="text-center">
							<div className="text-2xl font-bold">
								{session.spectators?.length || 0}
							</div>
							<div className="text-sm text-muted-foreground">Spectators</div>
						</div>
						<div className="text-center">
							<div className="text-2xl font-bold flex items-center justify-center gap-1">
								<Clock className="h-5 w-5" />
								{session.timeLeft}s
							</div>
							<div className="text-sm text-muted-foreground">Time Left</div>
						</div>
					</div>

					{session.status === "waiting" && !hasJoined && role !== "host" && (
						<div className="text-center space-y-4">
							<Separator />
							<div>
								<h3 className="font-semibold mb-2">
									Join as {getRoleLabel(role)}
								</h3>
								<Button
									onClick={handleJoinSession}
									className="w-full md:w-auto"
								>
									<Play className="h-4 w-4 mr-2" />
									Join Session
								</Button>
							</div>
						</div>
					)}

					{hasJoined && role !== "spectator" && (
						<div className="text-center space-y-4">
							<Separator />
							<Button onClick={handleSetReady} variant="outline">
								Mark Ready
							</Button>
						</div>
					)}
				</CardContent>
			</Card>

			{/* Players Section */}
			<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Users className="h-5 w-5 text-blue-500" />
							Team 1
						</CardTitle>
					</CardHeader>
					<CardContent>
						{session.players.find((p) => p.team === 1) ? (
							<div className="space-y-2">
								<div className="flex items-center justify-between">
									<span>Player 1</span>
									<Badge
										variant={
											session.players.find((p) => p.team === 1)?.isReady
												? "default"
												: "secondary"
										}
									>
										{session.players.find((p) => p.team === 1)?.isReady
											? "Ready"
											: "Not Ready"}
									</Badge>
								</div>
								<div className="text-sm text-muted-foreground">
									Characters:{" "}
									{session.players.find((p) => p.team === 1)?.selectedCharacters
										.length || 0}
								</div>
							</div>
						) : (
							<div className="text-center text-muted-foreground py-4">
								Waiting for Player 1...
							</div>
						)}
					</CardContent>
				</Card>

				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Users className="h-5 w-5 text-green-500" />
							Team 2
						</CardTitle>
					</CardHeader>
					<CardContent>
						{session.players.find((p) => p.team === 2) ? (
							<div className="space-y-2">
								<div className="flex items-center justify-between">
									<span>Player 2</span>
									<Badge
										variant={
											session.players.find((p) => p.team === 2)?.isReady
												? "default"
												: "secondary"
										}
									>
										{session.players.find((p) => p.team === 2)?.isReady
											? "Ready"
											: "Not Ready"}
									</Badge>
								</div>
								<div className="text-sm text-muted-foreground">
									Characters:{" "}
									{session.players.find((p) => p.team === 2)?.selectedCharacters
										.length || 0}
								</div>
							</div>
						) : (
							<div className="text-center text-muted-foreground py-4">
								Waiting for Player 2...
							</div>
						)}
					</CardContent>
				</Card>
			</div>

			{/* Current Phase */}
			<Card>
				<CardHeader>
					<CardTitle>Current Phase</CardTitle>
				</CardHeader>
				<CardContent>
					<div className="text-center space-y-2">
						<div className="text-lg font-semibold">
							{session.currentPhaseType}
						</div>
						<div className="text-sm text-muted-foreground">
							Phase {session.currentPhase + 1} • Team {session.currentTeam} Turn
						</div>
						{session.timeLeft > 0 && (
							<div className="text-sm">
								Time remaining:{" "}
								<span className="font-mono">{session.timeLeft}s</span>
							</div>
						)}
					</div>
				</CardContent>
			</Card>

			{/* Connection Status */}
			<Card>
				<CardHeader>
					<CardTitle>Connection Status</CardTitle>
				</CardHeader>
				<CardContent>
					<div className="flex items-center gap-2">
						<div
							className={`w-3 h-3 rounded-full ${gameInfo.connected ? "bg-green-500" : "bg-red-500"}`}
						/>
						<span>
							{gameInfo.connected ? "Connected to session" : "Disconnected"}
						</span>
					</div>
					{gameInfo.error && (
						<p className="text-red-600 text-sm mt-2">{gameInfo.error}</p>
					)}
				</CardContent>
			</Card>
		</div>
	);
}
