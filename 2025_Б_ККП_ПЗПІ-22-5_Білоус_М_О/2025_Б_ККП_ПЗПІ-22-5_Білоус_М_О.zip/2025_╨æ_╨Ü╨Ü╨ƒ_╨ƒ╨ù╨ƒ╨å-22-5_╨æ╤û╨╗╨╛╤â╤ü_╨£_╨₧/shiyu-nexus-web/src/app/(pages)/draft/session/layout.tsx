import { verifySession } from "@/lib/utils/dal";
import { GameProvider } from "@/lib/contexts/gameContext";

export default async function DraftSessionLayout({
	children
}: { children: React.ReactNode }) {
	const session = await verifySession();

	return <GameProvider token={session.token}>{children}</GameProvider>;
}
