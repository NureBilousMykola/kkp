import { Footer } from "@/components/footer";
import { Blob } from "./(components)/blob";
import { HomepageLink } from "./(components)/link";

export default async function Home() {
	return (
		<>
			<Blob />
			<div className="fixed inset-0 backdrop-blur-[12vmax] backdrop-filter" />
			<main className="relative z-10 grid grid-cols-1 gap-4 p-4 lg:grid-cols-2">
				<HomepageLink
					text="Draft"
					img="/home/draft.png"
					href="/draft"
					className="md:aspect-video md:h-full"
				/>

				<div className="grid grid-cols-2 gap-4">
					<HomepageLink href="/db" text="Database" img="/home/database.png" />
					<HomepageLink
						href="/profile"
						text="Profile"
						img="/home/profile.png"
					/>
					<HomepageLink href="/users" text="Users" img="/home/users.png" />
					<HomepageLink
						href="/tournament"
						text="Tournament"
						img="/home/tournament.png"
					/>
				</div>
			</main>

			<Footer />
		</>
	);
}
