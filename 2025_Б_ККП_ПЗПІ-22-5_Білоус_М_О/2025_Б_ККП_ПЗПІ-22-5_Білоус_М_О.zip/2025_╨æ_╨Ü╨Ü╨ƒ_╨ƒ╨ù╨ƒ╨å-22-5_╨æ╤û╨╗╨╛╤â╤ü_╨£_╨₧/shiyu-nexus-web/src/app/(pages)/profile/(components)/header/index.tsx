import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { getDiscordAvatarUrl } from "@/lib/utils/images";
import Link from "next/link";
import { memo } from "react";
import { LogoutButton } from "./logout";
import { myUserService } from "@/lib/api/services/users/service";

interface ProfileHeaderProps {
	username: string;
	email: string;
	discordId?: string;
	token: string;
}

export const ProfileHeader: React.FC<ProfileHeaderProps> = memo(
	async ({ username, email, discordId, token }) => {
		let image = "";
		if (discordId) {
			const userRequest = await myUserService.getMyUser(token);
			image = getDiscordAvatarUrl(discordId, userRequest.data?.discordAvatar);
		}

		return (
			<div className="mb-8 flex flex-col items-center justify-between gap-8 md:flex-row">
				<div className="flex w-full items-center gap-6">
					<Avatar className="h-24 w-24">
						<AvatarImage src={image} crossOrigin="anonymous" />
						<AvatarFallback className="capitalize">
							{username.charAt(0)}
						</AvatarFallback>
					</Avatar>

					<div>
						<h1 className="font-bold text-2xl">{username}</h1>
						<p className="text-muted-foreground">{email}</p>
						<LogoutButton />
					</div>
				</div>
				<div className="flex w-full gap-2 md:w-auto">
					<Button variant="outline" asChild>
						<Link href="/profile/agents">Agents</Link>
					</Button>
					<Button variant="outline" asChild>
						<Link href="/profile/engines">Engines</Link>
					</Button>
					<Button variant="outline" asChild>
						<Link href="/profile/saves">Saves</Link>
					</Button>
				</div>
			</div>
		);
	}
);
