"use client";

import { Button } from "@/components/ui/button";
import { logout } from "@/lib/actions/logout";

export const LogoutButton: React.FC = () => {
	return (
		<Button size={"sm"} variant={"destructive"} onClick={logout}>
			Log Out
		</Button>
	);
};
