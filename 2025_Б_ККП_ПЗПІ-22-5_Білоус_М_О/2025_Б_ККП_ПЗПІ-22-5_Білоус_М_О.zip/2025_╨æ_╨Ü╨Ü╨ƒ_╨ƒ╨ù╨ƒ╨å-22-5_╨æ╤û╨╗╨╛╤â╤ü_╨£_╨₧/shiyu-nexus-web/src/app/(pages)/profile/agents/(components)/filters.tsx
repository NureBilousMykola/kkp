import { Input } from "@/components/ui/input";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import type { IAgent } from "@/lib/api/models/IAgent";
import { memo } from "react";

interface AgentGridFiltersProps {
	allAgents: IAgent[];
	setSearchTerm: (searchTerm: string) => void;
	setFilterRarity: (filterRarity: string) => void;
	setFilterSpecialty: (filterSpecialty: string) => void;
	setFilterAttribute: (filterAttribute: string) => void;
}

export const AgentGridFilters: React.FC<AgentGridFiltersProps> = memo(
	({
		allAgents,
		setSearchTerm,
		setFilterRarity,
		setFilterSpecialty,
		setFilterAttribute
	}) => {
		const specialties = allAgents
			? [...new Set(allAgents.map((agent) => agent.specialty))]
			: [];
		const attributes = allAgents
			? [...new Set(allAgents.map((agent) => agent.attribute))]
			: [];

		return (
			<div className="mb-4 flex items-center justify-between">
				<div className="flex flex-1 flex-wrap items-center gap-2">
					<Input
						placeholder="Search agents..."
						onChange={(e) => {
							setSearchTerm(e.target.value);
						}}
						className="m-0 w-full md:max-w-xs"
					/>

					<Select defaultValue="all" onValueChange={setFilterRarity}>
						<SelectTrigger className="w-full md:w-48">
							<SelectValue placeholder="Rarity" />
						</SelectTrigger>
						<SelectContent>
							<SelectItem value="all">All rarities</SelectItem>
							<SelectItem value="S">S</SelectItem>
							<SelectItem value="A">A</SelectItem>
						</SelectContent>
					</Select>

					<Select defaultValue="all" onValueChange={setFilterSpecialty}>
						<SelectTrigger className="w-full md:w-48">
							<SelectValue placeholder="Specialty" />
						</SelectTrigger>
						<SelectContent className="!capitalize">
							<SelectItem value="all">All specialties</SelectItem>
							{specialties.map((specialty) => (
								<SelectItem key={specialty} value={specialty}>
									{specialty}
								</SelectItem>
							))}
						</SelectContent>
					</Select>

					<Select defaultValue="all" onValueChange={setFilterAttribute}>
						<SelectTrigger className="w-full md:w-48">
							<SelectValue placeholder="Attribute" />
						</SelectTrigger>
						<SelectContent className="capitalize">
							<SelectItem value="all">All attributes</SelectItem>
							{attributes.map((attribute) => (
								<SelectItem key={attribute} value={attribute}>
									{attribute}
								</SelectItem>
							))}
						</SelectContent>
					</Select>
				</div>
			</div>
		);
	}
);
