"use client";

import type { IUser } from "@/lib/api/models/IUser";
import { myUserService } from "@/lib/api/services/users/service";
import { useAgents } from "@/lib/contexts/dataProviders";
import { cn } from "@/lib/utils";
import { AttributeColors } from "@/lib/utils/colors";
import { useCallback, useMemo, useState } from "react";
import { AgentCard } from "./agentCard";
import { AgentGridFilters } from "./filters";

export interface AgentsGridProps {
	user: IUser;
	token: string;
}

export const AgentsGrid: React.FC<AgentsGridProps> = ({ user, token }) => {
	const [ownedAgents, setOwnedAgents] = useState(user.ownedAgents);

	// State for filters
	const [searchTerm, setSearchTerm] = useState<string>("");
	const [filterRarity, setFilterRarity] = useState<string>("all");
	const [filterSpecialty, setFilterSpecialty] = useState<string>("all");
	const [filterAttribute, setFilterAttribute] = useState<string>("all");

	const [isAdding, setIsAdding] = useState<boolean>(false);
	const [agentsToAdd, setAgentsToAdd] = useState<string[]>([]);

	const { data: allAgents, loading } = useAgents();

	const myFilteredAgents = useMemo(() => {
		return ownedAgents.filter((myAgent) => {
			const agent = myAgent.agent;

			// Apply search filter
			const matchesSearch =
				searchTerm === "" ||
				agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
				agent.fullName.toLowerCase().includes(searchTerm.toLowerCase());

			// Apply rarity filter
			const matchesRarity =
				filterRarity === "all" || agent.rarity === filterRarity;

			// Apply specialty filter
			const matchesSpecialty =
				filterSpecialty === "all" || agent.specialty === filterSpecialty;

			// Apply attribute filter
			const matchesAttribute =
				filterAttribute === "all" || agent.attribute === filterAttribute;

			// Return agents that match all filters
			return (
				matchesSearch && matchesRarity && matchesSpecialty && matchesAttribute
			);
		});
	}, [ownedAgents, searchTerm, filterRarity, filterSpecialty, filterAttribute]);

	const allFilteredAgents = useMemo(() => {
		return (allAgents || []).filter((agent) => {
			if (ownedAgents.find((myAgent) => myAgent.agent._id === agent._id))
				return false;

			// Apply search filter
			const matchesSearch =
				searchTerm === "" ||
				agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
				agent.fullName.toLowerCase().includes(searchTerm.toLowerCase());

			// Apply rarity filter
			const matchesRarity =
				filterRarity === "all" || agent.rarity === filterRarity;

			// Apply specialty filter
			const matchesSpecialty =
				filterSpecialty === "all" || agent.specialty === filterSpecialty;

			// Apply attribute filter
			const matchesAttribute =
				filterAttribute === "all" || agent.attribute === filterAttribute;

			// Return agents that match all filters
			return (
				matchesSearch && matchesRarity && matchesSpecialty && matchesAttribute
			);
		});
	}, [
		ownedAgents,
		allAgents,
		searchTerm,
		filterRarity,
		filterSpecialty,
		filterAttribute
	]);

	const toggleAgentToAdd = useCallback(
		(agentId: string) => {
			const index = agentsToAdd.indexOf(agentId);
			if (index > -1) {
				const newAgents = [...agentsToAdd];
				newAgents.splice(index, 1);
				setAgentsToAdd(newAgents);
			} else {
				setAgentsToAdd([...agentsToAdd, agentId]);
			}
		},
		[agentsToAdd]
	);

	const addAgents = useCallback(() => {
		myUserService.addMyAgents(token, {
			agents: agentsToAdd.map((agentId) => ({
				agentId,
				level: 1,
				mindscape: 0
			}))
		});

		setOwnedAgents([
			...ownedAgents,
			...(allAgents || [])
				.filter((agent) => agentsToAdd.includes(agent._id))
				.map((agent) => ({
					agent,
					level: 1,
					mindscape: 0
				}))
		]);

		setAgentsToAdd([]);
		setIsAdding(false);
	}, [allAgents, agentsToAdd, ownedAgents, token]);

	const removeAgent = useCallback(
		(agentId: string) => {
			myUserService.removeMyAgent(token, agentId);
			setOwnedAgents(
				ownedAgents.filter((agent) => agent.agent._id !== agentId)
			);
		},
		[ownedAgents, token]
	);

	const editAgent = useCallback(
		(agentId: string, level: number, mindscape: number) => {
			myUserService.updateMyAgent(token, agentId, { level, mindscape });
			setOwnedAgents(
				ownedAgents.map((agent) =>
					agent.agent._id === agentId ? { ...agent, level, mindscape } : agent
				)
			);
		},
		[ownedAgents, token]
	);

	return (
		<div className="space-y-4">
			<AgentGridFilters
				allAgents={allAgents || []}
				setSearchTerm={setSearchTerm}
				setFilterRarity={setFilterRarity}
				setFilterSpecialty={setFilterSpecialty}
				setFilterAttribute={setFilterAttribute}
			/>

			<button
				type="button"
				className={cn(
					"hidden h-92 w-full py-8 text-center text-muted-foreground",
					{
						block: ownedAgents.length === 0 && !isAdding
					}
				)}
				onClick={() => setIsAdding(true)}
			>
				You don't have any agents in your collection yet. Click to add some!
			</button>

			<div
				className={cn(
					"grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
					{
						hidden: ownedAgents.length === 0 && !isAdding
					}
				)}
			>
				{isAdding ? (
					<div className="flex w-full flex-1 border-4 border-card">
						<button
							type="button"
							className={cn(
								"flex-1 rounded p-8",
								agentsToAdd.length === 0 && "text-muted"
							)}
							onClick={addAgents}
							inert={agentsToAdd.length === 0}
						>
							Add selected
						</button>
						<span className="h-full w-1 bg-card" />
						<button
							type="button"
							className="flex-1 rounded p-8"
							onClick={() => {
								setIsAdding(false);
								setAgentsToAdd([]);
							}}
						>
							Cancel
						</button>
					</div>
				) : (
					<button
						type="button"
						className="cursor-pointer rounded border-2 border-card text-4xl"
						onClick={() => setIsAdding(true)}
					>
						+
					</button>
				)}

				{myFilteredAgents.map((ownedAgent) => {
					return (
						<AgentCard
							key={`my-agents-${ownedAgent.agent._id}`}
							agent={ownedAgent.agent}
							level={ownedAgent.level}
							mindscape={ownedAgent.mindscape}
							onClick={removeAgent}
							onEdit={editAgent}
							clickText="Remove"
							className={cn({
								hidden: isAdding
							})}
						/>
					);
				})}
				{allFilteredAgents.map((agent) => {
					const attributeColor = AttributeColors[agent.attribute].border;
					return (
						<AgentCard
							key={`agents-${agent._id}`}
							agent={agent}
							onClick={toggleAgentToAdd}
							clickText={agentsToAdd.includes(agent._id) ? "Remove" : "Add"}
							className={cn({
								[attributeColor]: agentsToAdd.includes(agent._id),
								hidden: !isAdding
							})}
						/>
					);
				})}
			</div>
		</div>
	);
};
