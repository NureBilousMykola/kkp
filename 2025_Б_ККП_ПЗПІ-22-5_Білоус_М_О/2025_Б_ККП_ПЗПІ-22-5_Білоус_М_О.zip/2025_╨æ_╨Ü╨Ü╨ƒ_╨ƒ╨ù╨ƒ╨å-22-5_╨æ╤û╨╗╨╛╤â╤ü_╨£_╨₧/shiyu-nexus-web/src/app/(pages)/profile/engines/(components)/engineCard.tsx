import Level from "@/components/icons/level";
import Stars from "@/components/icons/stars";
import {
	Select,
	SelectContent,
	SelectGroup,
	SelectItem,
	SelectLabel,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import type { IEngine } from "@/lib/api/models/IEngine";
import { cn } from "@/lib/utils";
import { RarityColors } from "@/lib/utils/colors";
import { SpecialtyIcons } from "@/lib/utils/icons";
import { useState } from "react";

interface EngineGridCardProps {
	engine: IEngine;
	level?: number;
	ascension?: number;
	clickText?: string;
	onClick?: (id: string, level: number, mindscape: number) => void;
	onEdit?: (id: string, level: number, mindscape: number) => void;
	className?: string;
}

export const EngineCard: React.FC<EngineGridCardProps> = ({
	engine,
	level: _level = 1,
	ascension: _ascension = 1,
	clickText,
	onClick = () => {},
	onEdit = () => {},
	className = ""
}) => {
	const [level, setLevel] = useState(_level);
	const [ascension, setAscension] = useState(_ascension);

	const handleOnLevelChange = (_level: string) => {
		setLevel(Number.parseInt(_level) * 10);
		onEdit(engine._id, Number.parseInt(_level) * 10, ascension);
	};

	const handleOnMindscapeChange = (_ascension: string) => {
		setAscension(Number.parseInt(_ascension));
		onEdit(engine._id, level, Number.parseInt(_ascension));
	};

	return (
		<div
			className={cn(
				"rounded-md border-2 border-transparent bg-card capitalize",
				className
			)}
		>
			<div className="flex items-center justify-between gap-4 p-4 sm:flex-col sm:items-start xl:flex-row xl:items-center">
				<div className="flex flex-col items-start">
					<p>{engine.name}</p>
				</div>
				<div className="flex gap-2">
					<img
						src={SpecialtyIcons[engine.specialty]}
						alt={engine.specialty}
						className="flex aspect-square h-full w-8 items-center justify-center rounded font-bold"
					/>
					<div
						className={cn(
							"flex aspect-square h-full w-8 items-center justify-center rounded font-bold",
							RarityColors[engine.rarity].background
						)}
					>
						{engine.rarity}
					</div>
				</div>
			</div>

			<button
				type="button"
				className={cn(
					"group relative h-48 w-full overflow-hidden",
					onClick !== undefined && "cursor-pointer"
				)}
				onClick={() => {
					onClick(engine._id, level, ascension);
				}}
			>
				{onClick !== undefined && (
					<div className="absolute inset-0 z-10 flex items-center justify-center bg-background/50 opacity-0 transition-opacity group-hover:opacity-100">
						{clickText}
					</div>
				)}
				<img
					src={engine.imageUrl}
					alt={engine.name}
					className="mx-auto h-48 w-48 object-cover"
					width={400}
					height={200}
				/>
			</button>

			<div className="z-20 flex h-12 justify-between">
				<div className="flex flex-1">
					<Select
						defaultValue={Math.floor(_level / 10).toString() || ""}
						onValueChange={handleOnLevelChange}
					>
						<SelectTrigger className="!h-12 w-full border-0">
							<SelectValue />
						</SelectTrigger>
						<SelectContent className="border-0">
							<SelectGroup>
								<SelectLabel>Level</SelectLabel>
								{new Array(7).fill(0).map((_, i) => (
									<SelectItem
										key={`${engine._id}-level-${i}`}
										value={i.toString()}
									>
										{i === 6 ? "60" : i === 0 ? "1+" : `${i * 10}+`}
									</SelectItem>
								))}
							</SelectGroup>
						</SelectContent>
					</Select>
					<span className="flex aspect-square items-center justify-center">
						<Level className="flex aspect-square h-12 w-12 p-3" />
					</span>
				</div>
				<div className="flex flex-1">
					<span className="flex aspect-square items-center justify-center">
						<Stars className="flex aspect-square h-12 w-12 p-3" />
					</span>
					<Select
						defaultValue={ascension.toString()}
						onValueChange={handleOnMindscapeChange}
					>
						<SelectTrigger className="!h-12 w-full border-0">
							<SelectValue defaultValue={ascension.toString()} />
						</SelectTrigger>
						<SelectContent className="border-0">
							<SelectGroup>
								<SelectLabel>Mindscape</SelectLabel>
								{new Array(5).fill(0).map((_, i) => (
									<SelectItem
										key={`${engine._id}-mindscape-${i}`}
										value={(i + 1).toString()}
									>
										{i + 1}
									</SelectItem>
								))}
							</SelectGroup>
						</SelectContent>
					</Select>
				</div>
			</div>
		</div>
	);
};
