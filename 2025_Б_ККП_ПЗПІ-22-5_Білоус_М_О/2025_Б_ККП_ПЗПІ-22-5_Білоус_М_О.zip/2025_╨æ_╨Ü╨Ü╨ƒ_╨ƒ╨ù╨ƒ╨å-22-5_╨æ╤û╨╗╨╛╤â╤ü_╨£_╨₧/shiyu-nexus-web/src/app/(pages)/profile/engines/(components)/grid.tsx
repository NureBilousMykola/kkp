"use client";
import { Input } from "@/components/ui/input";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import type { IUser } from "@/lib/api/models/IUser";
import type { IEngine } from "@/lib/api/models/IEngine";
import { myUserService } from "@/lib/api/services/users/service";
import { useEngines } from "@/lib/contexts/dataProviders";
import { cn } from "@/lib/utils";
import { SpecialityColors } from "@/lib/utils/colors";
import { useMemo, useState } from "react";
import { EngineCard } from "./engineCard";

export interface EnginesGridProps {
	user: IUser;
	token: string;
}

export const EnginesGrid: React.FC<EnginesGridProps> = ({ user, token }) => {
	const [ownedEngines, setOwnedEngines] = useState(user.ownedEngines);

	// State for filters
	const [searchTerm, setSearchTerm] = useState<string>("");
	const [filterRarity, setFilterRarity] = useState<string>("all");
	const [filterSpecialty, setFilterSpecialty] = useState<string>("all");

	const [isAdding, setIsAdding] = useState<boolean>(false);
	const [enginesToAdd, setEnginesToAdd] = useState<string[]>([]);

	const { data: allEngines } = useEngines();

	const specialties = allEngines
		? [...new Set(allEngines.map((engine: IEngine) => engine.specialty))]
		: [];

	const myFilteredEngines = useMemo(() => {
		return ownedEngines.filter((myEngine) => {
			const Engine = myEngine.engine;

			// Apply search filter
			const matchesSearch =
				searchTerm === "" ||
				Engine.name.toLowerCase().includes(searchTerm.toLowerCase());

			// Apply rarity filter
			const matchesRarity =
				filterRarity === "all" || Engine.rarity === filterRarity;

			// Apply specialty filter
			const matchesSpecialty =
				filterSpecialty === "all" || Engine.specialty === filterSpecialty;

			// Return Engines that match all filters
			return matchesSearch && matchesRarity && matchesSpecialty;
		});
	}, [ownedEngines, searchTerm, filterRarity, filterSpecialty]);

	const allFilteredEngines = useMemo(() => {
		return (allEngines || []).filter((engine: IEngine) => {
			if (ownedEngines.find((myEngine) => myEngine.engine._id === engine._id))
				return false;

			// Apply search filter
			const matchesSearch =
				searchTerm === "" ||
				engine.name.toLowerCase().includes(searchTerm.toLowerCase());

			// Apply rarity filter
			const matchesRarity =
				filterRarity === "all" || engine.rarity === filterRarity;

			// Apply specialty filter
			const matchesSpecialty =
				filterSpecialty === "all" || engine.specialty === filterSpecialty;

			// Return Engines that match all filters
			return matchesSearch && matchesRarity && matchesSpecialty;
		});
	}, [ownedEngines, allEngines, searchTerm, filterRarity, filterSpecialty]);

	const toggleEngineToAdd = (EngineId: string) => {
		if (enginesToAdd.includes(EngineId)) {
			setEnginesToAdd(enginesToAdd.filter((id) => id !== EngineId));
		} else {
			setEnginesToAdd([...enginesToAdd, EngineId]);
		}
	};

	const addEngines = () => {
		myUserService.addMyEngines(token, {
			engines: enginesToAdd.map((engineId) => ({
				engineId,
				level: 1,
				ascension: 1
			}))
		});

		setOwnedEngines([
			...ownedEngines,
			...(allEngines || [])
				.filter((engine: IEngine) => enginesToAdd.includes(engine._id))
				.map((engine: IEngine) => ({
					engine,
					level: 1,
					ascension: 1
				}))
		]);

		setEnginesToAdd([]);
		setIsAdding(false);
	};

	const removeEngine = (engineId: string) => {
		myUserService.removeMyEngine(token, engineId);
		setOwnedEngines(
			ownedEngines.filter((Engine) => Engine.engine._id !== engineId)
		);
	};

	const editEngine = (EngineId: string, level: number, ascension: number) => {
		myUserService.updateMyEngine(token, EngineId, { level, ascension });
		setOwnedEngines(
			ownedEngines.map((engine) =>
				engine.engine._id === EngineId
					? { ...engine, level, ascension }
					: engine
			)
		);
	};

	return (
		<div className="space-y-4">
			<div className="mb-4 flex items-center justify-between">
				<div className="flex flex-1 items-center space-x-2">
					<Input
						placeholder="Search Engines..."
						value={searchTerm}
						onChange={(e) => {
							setSearchTerm(e.target.value);
						}}
						className="max-w-xs"
					/>

					<Select value={filterRarity} onValueChange={setFilterRarity}>
						<SelectTrigger className="w-24">
							<SelectValue placeholder="Rarity" />
						</SelectTrigger>
						<SelectContent className="capitalize">
							<SelectItem value="all">All</SelectItem>
							<SelectItem value="S">S</SelectItem>
							<SelectItem value="A">A</SelectItem>
						</SelectContent>
					</Select>

					<Select value={filterSpecialty} onValueChange={setFilterSpecialty}>
						<SelectTrigger className="w-32">
							<SelectValue placeholder="Specialty" />
						</SelectTrigger>
						<SelectContent className="capitalize">
							<SelectItem value="all">All</SelectItem>
							{specialties.map((specialty) => (
								<SelectItem key={specialty} value={specialty}>
									{specialty}
								</SelectItem>
							))}
						</SelectContent>
					</Select>
				</div>
			</div>

			{isAdding ? (
				<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
					<div className="flex w-full flex-1 border-4 border-card">
						<button
							type="button"
							className={cn(
								"flex-1 rounded p-8",
								enginesToAdd.length === 0 && "text-muted"
							)}
							onClick={addEngines}
							inert={enginesToAdd.length === 0}
						>
							Add selected
						</button>
						<span className="h-full w-1 bg-card" />
						<button
							type="button"
							className="flex-1 rounded p-8"
							onClick={() => {
								setIsAdding(false);
								setEnginesToAdd([]);
							}}
						>
							Cancel
						</button>
					</div>
					{allFilteredEngines.map((Engine: IEngine) => (
						<EngineCard
							key={`Engines-${Engine._id}`}
							engine={Engine}
							onClick={toggleEngineToAdd}
							clickText={enginesToAdd.includes(Engine._id) ? "Remove" : "Add"}
							className={
								enginesToAdd.includes(Engine._id)
									? SpecialityColors[Engine.specialty].border
									: ""
							}
						/>
					))}
				</div>
			) : (
				<>
					<button
						type="button"
						className={cn(
							"hidden h-92 w-full py-8 text-center text-muted-foreground",
							{
								block: ownedEngines.length === 0
							}
						)}
						onClick={() => setIsAdding(true)}
					>
						You don't have any engines in your collection yet. Click to add
						some!
					</button>

					<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
						<button
							type="button"
							className="cursor-pointer rounded border-2 border-card text-4xl"
							onClick={() => setIsAdding(true)}
						>
							+
						</button>
						{myFilteredEngines.map((ownedEngine) => {
							return (
								<EngineCard
									key={`my-Engines-${ownedEngine.engine._id}`}
									engine={ownedEngine.engine}
									level={ownedEngine.level}
									ascension={ownedEngine.ascension}
									onClick={removeEngine}
									onEdit={editEngine}
									clickText="Remove"
								/>
							);
						})}
					</div>
				</>
			)}
		</div>
	);
};
