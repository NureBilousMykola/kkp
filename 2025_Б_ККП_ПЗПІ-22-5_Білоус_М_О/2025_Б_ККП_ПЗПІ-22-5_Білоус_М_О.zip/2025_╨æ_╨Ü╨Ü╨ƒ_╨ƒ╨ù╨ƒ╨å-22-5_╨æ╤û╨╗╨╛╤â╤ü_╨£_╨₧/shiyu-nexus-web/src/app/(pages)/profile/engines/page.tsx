import type { IUser } from "@/lib/api/models/IUser";
import { myUserService } from "@/lib/api/services/users/service";
import { verifySession } from "@/lib/utils/dal";
import { EnginesGrid } from "./(components)/grid";
import { redirect } from "next/navigation";

export default async function Page() {
	const session = await verifySession();
	const userRequest = await myUserService.getMyUser(session.token);

	if (!userRequest.ok) {
		console.log(userRequest.error);
		redirect("/");
	}

	const user = userRequest.data as IUser;

	return <EnginesGrid user={user} token={session.token} />;
}
