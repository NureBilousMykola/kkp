import { verifySession } from "@/lib/utils/dal";
import { ProfileHeader } from "./(components)/header";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default async function ProfileLayout({
	children
}: { children: React.ReactNode }) {
	const session = await verifySession();

	return (
		<div className="m-10 flex-1">
			<div className="mb-6">
				<Button variant="ghost" asChild className="gap-2">
					<Link href="/">
						<span className="text-lg">←</span>
						Back to Home
					</Link>
				</Button>
			</div>
			<ProfileHeader
				username={session.username}
				email={session.email}
				discordId={session.discordId}
				token={session.token}
			/>
			{children}
		</div>
	);
}
