import { useCallback, useMemo, useState } from "react";
import { AgentGridFilters } from "../../agents/(components)/filters";
import { cn } from "@/lib/utils";
import { AgentCard } from "../../agents/(components)/agentCard";
import { AttributeColors } from "@/lib/utils/colors";
import type { IAgent } from "@/lib/api/models/IAgent";

export interface EditSaveGridProps {
	save?: {
		id: string;
		name: string;
		description: string;
		agentIds: string[];
	};
	ownedAgents: IAgent[];
	onUpdateSaveAgents: (agentIds: string[]) => void;
}

export const EditSaveGrid: React.FC<EditSaveGridProps> = ({
	save,
	ownedAgents,
	onUpdateSaveAgents = () => {}
}) => {
	const [saveAgentIds, setSaveAgentIds] = useState(save?.agentIds || []);

	// State for filters
	const [searchTerm, setSearchTerm] = useState<string>("");
	const [filterRarity, setFilterRarity] = useState<string>("all");
	const [filterSpecialty, setFilterSpecialty] = useState<string>("all");
	const [filterAttribute, setFilterAttribute] = useState<string>("all");

	const allFilteredAgents = useMemo(() => {
		return ownedAgents.filter((agent) => {
			// Apply search filter
			const matchesSearch =
				searchTerm === "" ||
				agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
				agent.fullName.toLowerCase().includes(searchTerm.toLowerCase());

			// Apply rarity filter
			const matchesRarity =
				filterRarity === "all" || agent.rarity === filterRarity;

			// Apply specialty filter
			const matchesSpecialty =
				filterSpecialty === "all" || agent.specialty === filterSpecialty;

			// Apply attribute filter
			const matchesAttribute =
				filterAttribute === "all" || agent.attribute === filterAttribute;

			// Return agents that match all filters
			return (
				matchesSearch && matchesRarity && matchesSpecialty && matchesAttribute
			);
		});
	}, [ownedAgents, searchTerm, filterRarity, filterSpecialty, filterAttribute]);

	const toggleAgent = useCallback(
		(agentId: string) => {
			const index = saveAgentIds.indexOf(agentId);
			if (index > -1) {
				const newAgents = [...saveAgentIds];
				newAgents.splice(index, 1);
				setSaveAgentIds(newAgents);
				onUpdateSaveAgents(newAgents);
			} else {
				setSaveAgentIds([...saveAgentIds, agentId]);
				onUpdateSaveAgents([...saveAgentIds, agentId]);
			}
		},
		[saveAgentIds, onUpdateSaveAgents]
	);

	return (
		<div className="space-y-4 px-4">
			<AgentGridFilters
				allAgents={ownedAgents}
				setSearchTerm={setSearchTerm}
				setFilterRarity={setFilterRarity}
				setFilterSpecialty={setFilterSpecialty}
				setFilterAttribute={setFilterAttribute}
			/>

			<div
				className={cn(
					"grid max-h-[50vh] grid-cols-1 gap-4 overflow-y-scroll sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
				)}
			>
				{allFilteredAgents.map((agent) => {
					const attributeColor = AttributeColors[agent.attribute].border;
					return (
						<AgentCard
							key={`agents-${agent._id}`}
							agent={agent}
							onClick={toggleAgent}
							clickText={saveAgentIds.includes(agent._id) ? "Remove" : "Add"}
							className={cn({
								[attributeColor]: saveAgentIds.includes(agent._id)
							})}
						/>
					);
				})}
			</div>
		</div>
	);
};
