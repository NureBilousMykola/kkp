import { Input } from "@/components/ui/input";
import { memo } from "react";

interface SaveGridFiltersProps {
	setSearchTerm: (searchTerm: string) => void;
}

export const SaveGridFilters: React.FC<SaveGridFiltersProps> = memo(
	({ setSearchTerm }) => {
		return (
			<div className="mb-4 flex items-center justify-between">
				<div className="flex flex-1 flex-wrap items-center gap-2">
					<Input
						placeholder="Search saves..."
						onChange={(e) => {
							setSearchTerm(e.target.value);
						}}
						className="m-0 w-full md:max-w-xs"
					/>
				</div>
			</div>
		);
	}
);
