"use client";

import type { ISave } from "@/lib/api/models/ISave";
import type { IUser } from "@/lib/api/models/IUser";
import { myUserService } from "@/lib/api/services/users/service";
import { cn } from "@/lib/utils";
import { useCallback, useMemo, useState } from "react";
import { SaveGridFilters } from "./filters";
import { SaveCard } from "./saveCard";
import {
	Drawer,
	DrawerClose,
	DrawerContent,
	DrawerDescription,
	DrawerFooter,
	DrawerHeader,
	DrawerTitle
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { EditSaveGrid, type EditSaveGridProps } from "./editSaveGrid";
import { randomHash } from "@/lib/utils/math";
import { Input } from "@/components/ui/input";

export interface SavesGridProps {
	user: IUser;
	token: string;
}

export const SavesGrid: React.FC<SavesGridProps> = ({ user, token }) => {
	const [saves, setSaves] = useState<ISave[]>(user.agentSaves);
	const [saveInEdit, setSaveInEdit] = useState<
		EditSaveGridProps["save"] | undefined
	>();

	const [searchTerm, setSearchTerm] = useState<string>("");

	const filteredSaves = useMemo(() => {
		return saves.filter((save) => {
			const matchesSearch =
				searchTerm === "" ||
				save.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
				save.description.toLowerCase().includes(searchTerm.toLowerCase());

			return matchesSearch;
		});
	}, [saves, searchTerm]);

	const deleteSave = useCallback(
		async (saveId: string) => {
			await myUserService.deleteMyAgentSave(token, saveId);
			setSaves(saves.filter((save) => save._id !== saveId));
		},
		[saves, token]
	);

	console.log(user);

	const handleSubmit = useCallback(async () => {
		if (!saveInEdit) return;

		if (!user.agentSaves.find((save) => save._id === saveInEdit.id)) {
			const response = await myUserService.createMyAgentSave(token, {
				name: saveInEdit.name,
				description: saveInEdit.description,
				agentIds: saveInEdit.agentIds
			});

			if (!response.ok) return;

			setSaves(response.data?.agentSaves || []);
			setSaveInEdit(undefined);
		} else {
			const response = await myUserService.updateMyAgentSave(
				token,
				saveInEdit.id,
				{
					name: saveInEdit.name,
					description: saveInEdit.description,
					agentIds: saveInEdit.agentIds
				}
			);

			console.log(response);

			if (!response.ok) return;

			const newSave = response.data as ISave;

			setSaves(
				saves.map((save) => (save._id === newSave._id ? newSave : save))
			);
			setSaveInEdit(undefined);
		}
	}, [saveInEdit, user.agentSaves, token, saves]);

	return (
		<div className="space-y-4">
			<SaveGridFilters setSearchTerm={setSearchTerm} />

			<button
				type="button"
				className={cn(
					"hidden h-92 w-full py-8 text-center text-muted-foreground",
					{
						block: saves.length === 0
					}
				)}
				onClick={() =>
					setSaveInEdit({
						id: randomHash(24).toString(),
						name: "",
						description: "",
						agentIds: []
					})
				}
			>
				You don't have any agent saves yet. Click to create one!
			</button>

			<div
				className={cn(
					"grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
					{
						hidden: saves.length === 0
					}
				)}
			>
				<button
					type="button"
					className="cursor-pointer rounded border-2 border-card text-4xl"
					onClick={() =>
						setSaveInEdit({
							id: randomHash(24).toString(),
							name: "",
							description: "",
							agentIds: []
						})
					}
				>
					+
				</button>

				{filteredSaves.map((save) => (
					<SaveCard
						key={`save-${save._id}`}
						save={save}
						onDelete={deleteSave}
						onEdit={() =>
							setSaveInEdit({
								id: save._id,
								name: save.name,
								description: save.description,
								agentIds: save.agents
							})
						}
					/>
				))}
			</div>

			<Drawer
				open={saveInEdit !== undefined}
				onOpenChange={() => setSaveInEdit(undefined)}
			>
				<DrawerContent className="flex flex-col max-h-[90vh]">
					<div className="flex flex-col flex-1 overflow-y-auto px-4">
						<DrawerHeader>
							<DrawerTitle>
								<Input
									className="!text-7xl h-auto border-none"
									placeholder="My very cool save"
									value={saveInEdit?.name || ""}
									onChange={(e) =>
										setSaveInEdit({
											// biome-ignore lint/style/noNonNullAssertion: we fucked up plenty if there is none
											...saveInEdit!,
											name: e.target.value
										})
									}
								/>
							</DrawerTitle>
							<DrawerDescription>
								<Input
									placeholder="My very cool save description"
									value={saveInEdit?.description || ""}
									onChange={(e) =>
										setSaveInEdit({
											// biome-ignore lint/style/noNonNullAssertion: we fucked up plenty if there is none
											...saveInEdit!,
											description: e.target.value
										})
									}
								/>
							</DrawerDescription>
						</DrawerHeader>
						<EditSaveGrid
							save={saveInEdit}
							ownedAgents={user.ownedAgents.map((a) => a.agent)}
							onUpdateSaveAgents={(agents) =>
								setSaveInEdit({
									// biome-ignore lint/style/noNonNullAssertion: we fucked up plenty if there is none
									...saveInEdit!,
									agentIds: agents
								})
							}
						/>
					</div>
					<DrawerFooter className="border-t">
						<Button onClick={handleSubmit}>Submit</Button>
						<DrawerClose asChild>
							<Button variant="outline">Cancel</Button>
						</DrawerClose>
					</DrawerFooter>
				</DrawerContent>
			</Drawer>
		</div>
	);
};
