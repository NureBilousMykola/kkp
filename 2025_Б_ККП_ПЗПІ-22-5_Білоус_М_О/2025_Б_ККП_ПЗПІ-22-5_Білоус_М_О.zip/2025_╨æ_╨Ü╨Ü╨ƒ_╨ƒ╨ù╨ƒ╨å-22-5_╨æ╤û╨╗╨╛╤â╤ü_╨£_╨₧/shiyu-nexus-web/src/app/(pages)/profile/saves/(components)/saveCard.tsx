import { Button } from "@/components/ui/button";
import type { ISave } from "@/lib/api/models/ISave";
import { cn } from "@/lib/utils";

interface SaveCardProps {
	save: ISave;
	onEdit?: (id: string) => void;
	onDelete?: (id: string) => void;
	className?: string;
}

export const SaveCard: React.FC<SaveCardProps> = ({
	save,
	onEdit = () => {},
	onDelete = () => {},
	className
}) => {
	return (
		<div
			className={cn(
				"rounded-md border-2 border-transparent bg-card",
				className
			)}
		>
			<div className="flex items-center justify-between gap-4 p-4">
				<div className="flex flex-col items-start">
					<p className="font-semibold">{save.name}</p>
					<p className="text-muted-foreground text-sm">
						Created: {new Date(save.createdAt).toLocaleDateString()}
					</p>
				</div>
			</div>

			<div className="p-4">
				<p className="text-muted-foreground text-sm">{save.description}</p>
			</div>

			<div className="flex justify-between border-border border-t p-2">
				<Button
					size={"sm"}
					variant={"outline"}
					onClick={() => onEdit(save._id)}
				>
					Edit
				</Button>
				<Button
					size={"sm"}
					variant={"destructive"}
					onClick={() => onDelete(save._id)}
				>
					Delete
				</Button>
			</div>
		</div>
	);
};
