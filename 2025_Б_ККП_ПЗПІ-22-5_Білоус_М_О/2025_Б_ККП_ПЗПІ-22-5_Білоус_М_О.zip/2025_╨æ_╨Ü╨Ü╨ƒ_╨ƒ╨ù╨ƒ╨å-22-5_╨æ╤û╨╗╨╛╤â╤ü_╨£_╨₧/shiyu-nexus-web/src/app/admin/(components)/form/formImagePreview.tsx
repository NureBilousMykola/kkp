import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useState, useEffect } from "react";

function isValidHttpUrl(url: string): boolean {
	try {
		const _ = new URL(url);
		return true;
	} catch (_) {
		return false;
	}
}

interface FormImageProps {
	url?: string;
	label: string;
	name: string;
	errors?: string[];
}

export const FormImage: React.FC<FormImageProps> = ({
	url,
	name,
	label,
	errors: _errors
}) => {
	const [input, setInput] = useState(url || "");
	const [imageSrc, setImageSrc] = useState<string | undefined>();

	const [errors, setErrors] = useState<string[]>(_errors || []);

	useEffect(() => {
		if (input.length === 0) {
			if (errors?.length !== 0) setErrors([]);
			return;
		}

		if (!isValidHttpUrl(input)) {
			setImageSrc(undefined);
			if (errors.length === 0) setErrors(["Please enter a valid URL"]);
			return;
		}

		if (errors?.length !== 0) {
			setErrors([]);
		}

		setImageSrc(input);
	}, [input, errors]);

	return (
		<div className="space-y-2">
			<Label htmlFor={name}>{label}</Label>
			<div className="flex gap-2">
				<div className="bg-card p-4 [background-image:radial-gradient(circle,var(--muted-foreground)_1px,transparent_1px)] [background-size:20px_20px]">
					<Avatar className="h-32 w-32 rounded-md">
						<AvatarImage className="object-contain" src={imageSrc} />
						<AvatarFallback>Image</AvatarFallback>
					</Avatar>
				</div>
				<Textarea
					id={name}
					name={name}
					placeholder="https://example.com/image.png"
					defaultValue={url}
					onChange={(e) => setInput(e.target.value)}
					className="resize-none"
				/>
			</div>
			{errors && (
				<span className="mt-0 text-destructive text-xs">{errors}</span>
			)}
		</div>
	);
};
