"use client";

import {
	Breadcrumb,
	BreadcrumbItem,
	BreadcrumbLink,
	BreadcrumbList,
	BreadcrumbPage,
	BreadcrumbSeparator
} from "@/components/ui/breadcrumb";
import { usePathname } from "next/navigation";
import { Fragment } from "react";

export const AdminBreadcrumb = () => {
	const pathname = usePathname();

	const segments = pathname.split("/").filter(Boolean);

	const breadcrumbItems = segments.map((segment, index) => {
		const href = `/${segments.slice(0, index + 1).join("/")}`;
		const isLast = index === segments.length - 1;

		const text = segment === "admin" ? "Dashboard" : segment;

		return (
			<Fragment key={href}>
				<BreadcrumbItem className="hidden md:block">
					{isLast ? (
						<BreadcrumbPage>{text}</BreadcrumbPage>
					) : (
						<BreadcrumbLink href={href}>{text}</BreadcrumbLink>
					)}
				</BreadcrumbItem>
				{!isLast && <BreadcrumbSeparator className="hidden md:block" />}
			</Fragment>
		);
	});

	return (
		<Breadcrumb className="capitalize">
			<BreadcrumbList>{breadcrumbItems}</BreadcrumbList>
		</Breadcrumb>
	);
};
