import { Bot, LifeBuoy, Send, SwordIcon, Users } from "lucide-react";

import { NavMain } from "@/app/admin/(components)/nav/nav-main";
import { NavSecondary } from "@/app/admin/(components)/nav/nav-secondary";
import { NavUser } from "@/app/admin/(components)/nav/nav-user";
import {
	Sidebar,
	SidebarContent,
	SidebarFooter,
	SidebarHeader,
	SidebarMenu,
	SidebarMenuButton,
	SidebarMenuItem
} from "@/components/ui/sidebar";
import Link from "next/link";
import type { IUser } from "@/lib/api/models/IUser";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const data = {
	navMain: [
		{
			title: "Users",
			url: "/admin/users",
			icon: Users
		},
		{
			title: "Entities",
			url: "/admin/entities",
			icon: SwordIcon,
			isActive: true,
			items: [
				{
					title: "Agents",
					url: "/admin/entities/agents"
				},
				{
					title: "Engines",
					url: "/admin/entities/engines"
				},
				{
					title: "Bangboos",
					url: "/admin/entities/bangboos"
				},
				{
					title: "Factions",
					url: "/admin/entities/factions"
				},
				{
					title: "Enemies",
					url: "/admin/entities/enemies"
				}
			]
		},
		{
			title: "Draft Game",
			url: "/admin/draft",
			icon: Bot,
			isActive: true,
			items: [
				{
					title: "Stages",
					url: "/admin/draft/stages"
				},
				{
					title: "Presets",
					url: "/admin/draft/presets"
				},
				{
					title: "Cost System",
					url: "/admin/draft/cost"
				}
			]
		}
	],
	navSecondary: [
		{
			title: "Support",
			url: "#",
			icon: LifeBuoy
		},
		{
			title: "Feedback",
			url: "#",
			icon: Send
		}
	]
};

interface AdminSidebarProps extends React.ComponentProps<typeof Sidebar> {
	user: IUser;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({
	user,
	...props
}) => {
	return (
		<Sidebar variant="inset" {...props}>
			<SidebarHeader>
				<SidebarMenu>
					<SidebarMenuItem>
						<SidebarMenuButton size="lg" asChild>
							<Link href="/admin">
								<div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
									<Avatar>
										<AvatarImage src="/icons/logo-dark.svg" alt="Shiyu Nexus" />
										<AvatarFallback className="capitalize">S</AvatarFallback>
									</Avatar>
								</div>
								<div className="grid flex-1 text-left text-sm leading-tight">
									<span className="truncate font-medium">Shiyu Nexus</span>
									<span className="truncate text-xs">Admin</span>
								</div>
							</Link>
						</SidebarMenuButton>
					</SidebarMenuItem>
				</SidebarMenu>
			</SidebarHeader>
			<SidebarContent>
				<NavMain items={data.navMain} />
				<NavSecondary items={data.navSecondary} className="mt-auto" />
			</SidebarContent>
			<SidebarFooter>
				<NavUser user={user} />
			</SidebarFooter>
		</Sidebar>
	);
};
