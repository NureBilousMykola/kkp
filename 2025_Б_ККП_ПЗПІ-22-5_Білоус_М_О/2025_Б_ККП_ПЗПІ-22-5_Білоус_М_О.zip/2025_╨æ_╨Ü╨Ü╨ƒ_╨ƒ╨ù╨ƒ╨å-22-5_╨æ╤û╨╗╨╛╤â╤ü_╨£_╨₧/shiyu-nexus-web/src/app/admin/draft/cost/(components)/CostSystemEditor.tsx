"use client";

import { useState, useEffect } from "react";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, X, Plus } from "lucide-react";
import { useAgents, useEngines } from "@/lib/contexts/dataProviders";
import type {
	ICostSystem,
	IAgentCost,
	IEngineCost
} from "@/lib/api/models/ICostSystem";
import type { IAgent } from "@/lib/api/models/IAgent";
import type { IEngine } from "@/lib/api/models/IEngine";
import { AgentCostEditor } from "./AgentCostEditor";
import { EngineCostEditor } from "./EngineCostEditor";
import {
	getDefaultMindscapeCosts,
	getDefaultAscensionCosts
} from "@/lib/utils/cost-system-helpers";

interface CostSystemEditorProps {
	system: ICostSystem | null;
	isOpen: boolean;
	onClose: () => void;
	onSave: (data: {
		name: string;
		description?: string;
		agentCosts: IAgentCost[];
		engineCosts: IEngineCost[];
		isDefault?: boolean;
	}) => void;
	isCreating?: boolean;
}

export function CostSystemEditor({
	system,
	isOpen,
	onClose,
	onSave,
	isCreating = false
}: CostSystemEditorProps) {
	const { data: allAgents = [] } = useAgents();
	const { data: allEngines = [] } = useEngines();

	const [name, setName] = useState("");
	const [description, setDescription] = useState("");
	const [agentCosts, setAgentCosts] = useState<IAgentCost[]>([]);
	const [engineCosts, setEngineCosts] = useState<IEngineCost[]>([]);
	const [isDefault, setIsDefault] = useState(false);
	const [isSaving, setIsSaving] = useState(false);

	// Initialize form when system changes
	useEffect(() => {
		if (system) {
			setName(system.name);
			setDescription(system.description || "");
			setAgentCosts(system.agentCosts || []);
			setEngineCosts(system.engineCosts || []);
			setIsDefault(system.isDefault);
		} else if (isCreating) {
			// Reset form for creating new system
			setName("");
			setDescription("");
			setAgentCosts([]);
			setEngineCosts([]);
			setIsDefault(false);
		}
	}, [system, isCreating]);

	const handleSave = async () => {
		if (!name.trim()) return;

		setIsSaving(true);
		try {
			await onSave({
				name: name.trim(),
				description: description.trim() || undefined,
				agentCosts,
				engineCosts,
				isDefault: isCreating ? isDefault : undefined
			});
			onClose();
		} catch (error) {
			console.error("Failed to save cost system:", error);
		} finally {
			setIsSaving(false);
		}
	};

	const addAllAgents = () => {
		const existingAgentIds = new Set(
			agentCosts.map((cost) =>
				typeof cost.agent === "string" ? cost.agent : cost.agent._id
			)
		);

		const newAgentCosts = allAgents
			.filter((agent) => !existingAgentIds.has(agent._id))
			.map((agent) => ({
				agent: agent._id,
				mindscapeCosts: getDefaultMindscapeCosts()
			}));

		setAgentCosts([...agentCosts, ...newAgentCosts]);
	};

	const addAllEngines = () => {
		const existingEngineIds = new Set(
			engineCosts.map((cost) =>
				typeof cost.engine === "string" ? cost.engine : cost.engine._id
			)
		);

		const newEngineCosts = allEngines
			.filter((engine) => !existingEngineIds.has(engine._id))
			.map((engine) => ({
				engine: engine._id,
				ascensionCosts: getDefaultAscensionCosts()
			}));

		setEngineCosts([...engineCosts, ...newEngineCosts]);
	};

	const updateAgentCost = (index: number, updatedCost: IAgentCost) => {
		const updated = [...agentCosts];
		updated[index] = updatedCost;
		setAgentCosts(updated);
	};

	const removeAgentCost = (index: number) => {
		setAgentCosts(agentCosts.filter((_, i) => i !== index));
	};

	const updateEngineCost = (index: number, updatedCost: IEngineCost) => {
		const updated = [...engineCosts];
		updated[index] = updatedCost;
		setEngineCosts(updated);
	};

	const removeEngineCost = (index: number) => {
		setEngineCosts(engineCosts.filter((_, i) => i !== index));
	};

	const getAgentById = (id: string): IAgent | undefined => {
		return allAgents.find((agent) => agent._id === id);
	};

	const getEngineById = (id: string): IEngine | undefined => {
		return allEngines.find((engine) => engine._id === id);
	};

	return (
		<Dialog open={isOpen} onOpenChange={onClose}>
			<DialogContent className="min-w-6xl max-h-[90vh] overflow-y-auto">
				<DialogHeader>
					<DialogTitle>
						{isCreating ? "Create Cost System" : `Edit ${system?.name}`}
					</DialogTitle>
					<DialogDescription>
						{isCreating
							? "Create a new cost system that defines agent mindscape and engine ascension costs."
							: "Modify the cost system configuration."}
					</DialogDescription>
				</DialogHeader>

				<div className="space-y-6">
					{/* Basic Information */}
					<div className="grid grid-cols-2 gap-4">
						<div className="space-y-2">
							<Label htmlFor="name">Name *</Label>
							<Input
								id="name"
								value={name}
								onChange={(e) => setName(e.target.value)}
								placeholder="Enter cost system name"
							/>
						</div>
						{isCreating && (
							<div className="flex items-center space-x-2 pt-7">
								<Checkbox
									id="isDefault"
									checked={isDefault}
									onCheckedChange={(checked) => setIsDefault(!!checked)}
								/>
								<Label htmlFor="isDefault">Set as default</Label>
							</div>
						)}
					</div>

					<div className="space-y-2">
						<Label htmlFor="description">Description</Label>
						<Textarea
							id="description"
							value={description}
							onChange={(e) => setDescription(e.target.value)}
							placeholder="Enter description (optional)"
							rows={3}
						/>
					</div>

					{/* Cost Configuration */}
					<Tabs defaultValue="agents" className="w-full">
						<TabsList className="grid w-full grid-cols-2">
							<TabsTrigger value="agents">
								Agent Costs ({agentCosts.length})
							</TabsTrigger>
							<TabsTrigger value="engines">
								Engine Costs ({engineCosts.length})
							</TabsTrigger>
						</TabsList>

						<TabsContent value="agents" className="space-y-4">
							<Card>
								<CardHeader>
									<div className="flex items-center justify-between">
										<CardTitle>Agent Mindscape Costs</CardTitle>
										<Button
											onClick={addAllAgents}
											variant="outline"
											size="sm"
											disabled={agentCosts.length >= allAgents.length}
										>
											<Plus className="h-4 w-4 mr-2" />
											Add All Agents
										</Button>
									</div>
								</CardHeader>
								<CardContent className="space-y-4">
									{agentCosts.length === 0 ? (
										<div className="text-center py-8 text-muted-foreground">
											No agent costs configured. Click "Add All Agents" to get
											started.
										</div>
									) : (
										agentCosts.map((cost, index) => (
											<AgentCostEditor
												key={`${typeof cost.agent === "string" ? cost.agent : cost.agent._id}-${index}`}
												cost={cost}
												agent={getAgentById(
													typeof cost.agent === "string"
														? cost.agent
														: cost.agent._id
												)}
												onUpdate={(updatedCost) =>
													updateAgentCost(index, updatedCost)
												}
												onRemove={() => removeAgentCost(index)}
											/>
										))
									)}
								</CardContent>
							</Card>
						</TabsContent>

						<TabsContent value="engines" className="space-y-4">
							<Card>
								<CardHeader>
									<div className="flex items-center justify-between">
										<CardTitle>Engine Ascension Costs</CardTitle>
										<Button
											onClick={addAllEngines}
											variant="outline"
											size="sm"
											disabled={engineCosts.length >= allEngines.length}
										>
											<Plus className="h-4 w-4 mr-2" />
											Add All Engines
										</Button>
									</div>
								</CardHeader>
								<CardContent className="space-y-4">
									{engineCosts.length === 0 ? (
										<div className="text-center py-8 text-muted-foreground">
											No engine costs configured. Click "Add All Engines" to get
											started.
										</div>
									) : (
										engineCosts.map((cost, index) => (
											<EngineCostEditor
												key={`${typeof cost.engine === "string" ? cost.engine : cost.engine._id}-${index}`}
												cost={cost}
												engine={getEngineById(
													typeof cost.engine === "string"
														? cost.engine
														: cost.engine._id
												)}
												onUpdate={(updatedCost) =>
													updateEngineCost(index, updatedCost)
												}
												onRemove={() => removeEngineCost(index)}
											/>
										))
									)}
								</CardContent>
							</Card>
						</TabsContent>
					</Tabs>
				</div>

				<DialogFooter>
					<Button variant="outline" onClick={onClose} disabled={isSaving}>
						<X className="h-4 w-4 mr-2" />
						Cancel
					</Button>
					<Button onClick={handleSave} disabled={!name.trim() || isSaving}>
						<Save className="h-4 w-4 mr-2" />
						{isSaving ? "Saving..." : isCreating ? "Create" : "Save"}
					</Button>
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}
