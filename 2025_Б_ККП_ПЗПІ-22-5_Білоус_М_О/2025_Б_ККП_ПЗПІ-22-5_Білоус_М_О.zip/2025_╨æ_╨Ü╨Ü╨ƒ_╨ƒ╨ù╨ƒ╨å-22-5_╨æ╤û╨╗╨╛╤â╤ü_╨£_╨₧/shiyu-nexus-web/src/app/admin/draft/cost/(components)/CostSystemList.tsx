"use client";

import { useState } from "react";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
	AlertDialog,
	AlertDialogAction,
	AlertDialogCancel,
	AlertDialogContent,
	AlertDialogDescription,
	AlertDialogFooter,
	AlertDialogHeader,
	AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { MoreHorizontal, Star, Copy, Trash2, Crown } from "lucide-react";
import type { ICostSystem } from "@/lib/api/models/ICostSystem";

interface CostSystemListProps {
	costSystems: ICostSystem[];
	onEdit: (system: ICostSystem) => void;
	onClone: (systemId: string) => void;
	onDelete: (systemId: string) => void;
	onSetDefault: (systemId: string) => void;
	isLoading?: boolean;
}

export function CostSystemList({
	costSystems,
	onEdit,
	onClone,
	onDelete,
	onSetDefault,
	isLoading = false
}: CostSystemListProps) {
	const [systemToDelete, setSystemToDelete] = useState<ICostSystem | null>(
		null
	);

	const handleDeleteClick = (system: ICostSystem) => {
		setSystemToDelete(system);
	};

	const handleDeleteConfirm = () => {
		if (systemToDelete) {
			onDelete(systemToDelete._id);
			setSystemToDelete(null);
		}
	};

	if (isLoading) {
		return (
			<div className="flex items-center justify-center py-8">
				<div className="text-muted-foreground">Loading cost systems...</div>
			</div>
		);
	}

	if (costSystems.length === 0) {
		return (
			<div className="flex items-center justify-center py-8">
				<div className="text-muted-foreground">No cost systems found</div>
			</div>
		);
	}

	return (
		<>
			<div className="rounded-md border">
				<Table>
					<TableHeader>
						<TableRow>
							<TableHead>Name</TableHead>
							<TableHead>Description</TableHead>
							<TableHead>Agent Costs</TableHead>
							<TableHead>Engine Costs</TableHead>
							<TableHead>Status</TableHead>
							<TableHead>Created By</TableHead>
							<TableHead>Created</TableHead>
							<TableHead className="w-[50px]" />
						</TableRow>
					</TableHeader>
					<TableBody>
						{costSystems.map((system) => (
							<TableRow
								key={system._id}
								className="cursor-pointer hover:bg-muted/50"
								onClick={() => onEdit(system)}
							>
								<TableCell className="font-medium">
									<div className="flex items-center gap-2">
										{system.name}
										{system.isDefault && (
											<Crown className="h-4 w-4 text-yellow-500" />
										)}
									</div>
								</TableCell>
								<TableCell className="text-muted-foreground">
									{system.description || "No description"}
								</TableCell>
								<TableCell>
									<Badge variant="secondary">
										{system.agentCosts?.length || 0} agents
									</Badge>
								</TableCell>
								<TableCell>
									<Badge variant="secondary">
										{system.engineCosts?.length || 0} engines
									</Badge>
								</TableCell>
								<TableCell>
									{system.isDefault ? (
										<Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20">
											Default
										</Badge>
									) : (
										<Badge variant="outline">Active</Badge>
									)}
								</TableCell>
								<TableCell className="text-muted-foreground">
									{typeof system.createdBy === "string"
										? system.createdBy
										: system.createdBy?.username || "Unknown"}
								</TableCell>
								<TableCell className="text-muted-foreground">
									{new Date(system.createdAt).toLocaleDateString()}
								</TableCell>
								<TableCell>
									<DropdownMenu>
										<DropdownMenuTrigger
											asChild
											onClick={(e) => e.stopPropagation()}
										>
											<Button variant="ghost" size="sm">
												<MoreHorizontal className="h-4 w-4" />
											</Button>
										</DropdownMenuTrigger>
										<DropdownMenuContent align="end">
											<DropdownMenuItem onClick={() => onEdit(system)}>
												Edit
											</DropdownMenuItem>
											<DropdownMenuItem
												onClick={(e) => {
													e.stopPropagation();
													onClone(system._id);
												}}
											>
												<Copy className="h-4 w-4 mr-2" />
												Clone
											</DropdownMenuItem>
											{!system.isDefault && (
												<DropdownMenuItem
													onClick={(e) => {
														e.stopPropagation();
														onSetDefault(system._id);
													}}
												>
													<Star className="h-4 w-4 mr-2" />
													Set as Default
												</DropdownMenuItem>
											)}
											{!system.isDefault && (
												<DropdownMenuItem
													onClick={(e) => {
														e.stopPropagation();
														handleDeleteClick(system);
													}}
													className="text-destructive"
												>
													<Trash2 className="h-4 w-4 mr-2" />
													Delete
												</DropdownMenuItem>
											)}
										</DropdownMenuContent>
									</DropdownMenu>
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
			</div>

			<AlertDialog
				open={!!systemToDelete}
				onOpenChange={() => setSystemToDelete(null)}
			>
				<AlertDialogContent>
					<AlertDialogHeader>
						<AlertDialogTitle>Delete Cost System</AlertDialogTitle>
						<AlertDialogDescription>
							Are you sure you want to delete "{systemToDelete?.name}"? This
							action cannot be undone.
						</AlertDialogDescription>
					</AlertDialogHeader>
					<AlertDialogFooter>
						<AlertDialogCancel>Cancel</AlertDialogCancel>
						<AlertDialogAction
							onClick={handleDeleteConfirm}
							className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
						>
							Delete
						</AlertDialogAction>
					</AlertDialogFooter>
				</AlertDialogContent>
			</AlertDialog>
		</>
	);
}
