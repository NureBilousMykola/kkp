"use client";

import { useState, useCallback, useEffect } from "react";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Search, RefreshCw } from "lucide-react";
import { useAgents, useEngines } from "@/lib/contexts/dataProviders";
import type {
	ICostSystem,
	IAgentCost,
	IEngineCost
} from "@/lib/api/models/ICostSystem";
import { costSystemsService } from "@/lib/api/services/cost-systems";
import { CostSystemList } from "./CostSystemList";
import { CostSystemEditor } from "./CostSystemEditor";
import {
	serializeAgentCosts,
	serializeEngineCosts,
	deserializeAgentCosts,
	deserializeEngineCosts
} from "@/lib/utils/cost-system-helpers";

interface CostSystemManagerProps {
	token: string;
}

interface CloneDialogState {
	isOpen: boolean;
	systemId: string | null;
	systemName: string;
}

export function CostSystemManager({ token }: CostSystemManagerProps) {
	const { data: allAgents = [], loading: agentsLoading } = useAgents();
	const { data: allEngines = [], loading: enginesLoading } = useEngines();

	const [costSystems, setCostSystems] = useState<ICostSystem[]>([]);
	const [isLoading, setIsLoading] = useState(true);
	const [searchQuery, setSearchQuery] = useState("");

	// Create dialog state
	const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

	// Edit dialog state
	const [editingSystem, setEditingSystem] = useState<ICostSystem | null>(null);
	const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

	// Clone dialog state
	const [cloneDialog, setCloneDialog] = useState<CloneDialogState>({
		isOpen: false,
		systemId: null,
		systemName: ""
	});
	const [cloneName, setCloneName] = useState("");

	// Load cost systems from the backend
	const loadCostSystems = useCallback(async () => {
		try {
			setIsLoading(true);
			const response = await costSystemsService.getCostSystems(token, {
				search: searchQuery || undefined,
				limit: 100
			});

			if (response.ok && response.data) {
				// Deserialize the Maps from the backend response
				const systems = response.data.map((system) => ({
					...system,
					agentCosts: deserializeAgentCosts(system.agentCosts as any),
					engineCosts: deserializeEngineCosts(system.engineCosts as any)
				}));
				setCostSystems(systems);
			} else {
				console.error("Failed to load cost systems:", response.error);
			}
		} catch (error) {
			console.error("Failed to load cost systems:", error);
		} finally {
			setIsLoading(false);
		}
	}, [token, searchQuery]);

	// Load systems on mount and when search changes
	useEffect(() => {
		loadCostSystems();
	}, [loadCostSystems]);

	// Create a new cost system
	const handleCreate = async (data: {
		name: string;
		description?: string;
		agentCosts: IAgentCost[];
		engineCosts: IEngineCost[];
		isDefault?: boolean;
	}) => {
		try {
			const response = await costSystemsService.createCostSystem(token, {
				name: data.name,
				description: data.description,
				agentCosts: serializeAgentCosts(data.agentCosts),
				engineCosts: serializeEngineCosts(data.engineCosts),
				isDefault: data.isDefault
			});

			if (response.ok) {
				console.log("Cost system created successfully");
				await loadCostSystems();
			} else {
				throw new Error(response.error || "Failed to create cost system");
			}
		} catch (error: any) {
			console.error("Failed to create cost system:", error.message);
			throw error;
		}
	};

	// Update an existing cost system
	const handleUpdate = async (data: {
		name: string;
		description?: string;
		agentCosts: IAgentCost[];
		engineCosts: IEngineCost[];
	}) => {
		if (!editingSystem) return;

		try {
			const response = await costSystemsService.updateCostSystem(
				token,
				editingSystem._id,
				{
					name: data.name,
					description: data.description,
					agentCosts: serializeAgentCosts(data.agentCosts),
					engineCosts: serializeEngineCosts(data.engineCosts)
				}
			);

			if (response.ok) {
				console.log("Cost system updated successfully");
				await loadCostSystems();
				setEditingSystem(null);
			} else {
				throw new Error(response.error || "Failed to update cost system");
			}
		} catch (error: any) {
			console.error("Failed to update cost system:", error.message);
			throw error;
		}
	};

	// Delete a cost system
	const handleDelete = async (systemId: string) => {
		try {
			const response = await costSystemsService.deleteCostSystem(
				token,
				systemId
			);

			if (response.ok) {
				console.log("Cost system deleted successfully");
				await loadCostSystems();
			} else {
				console.error("Failed to delete cost system:", response.error);
			}
		} catch (error) {
			console.error("Failed to delete cost system:", error);
		}
	};

	// Clone a cost system
	const handleClone = async () => {
		if (!cloneDialog.systemId || !cloneName.trim()) return;

		try {
			const response = await costSystemsService.cloneCostSystem(
				token,
				cloneDialog.systemId,
				{
					name: cloneName.trim()
				}
			);

			if (response.ok) {
				console.log("Cost system cloned successfully");
				await loadCostSystems();
				setCloneDialog({ isOpen: false, systemId: null, systemName: "" });
				setCloneName("");
			} else {
				console.error("Failed to clone cost system:", response.error);
			}
		} catch (error) {
			console.error("Failed to clone cost system:", error);
		}
	};

	// Set a cost system as default
	const handleSetDefault = async (systemId: string) => {
		try {
			const response = await costSystemsService.setDefaultCostSystem(
				token,
				systemId
			);

			if (response.ok) {
				console.log("Default cost system updated");
				await loadCostSystems();
			} else {
				console.error("Failed to set default cost system:", response.error);
			}
		} catch (error) {
			console.error("Failed to set default cost system:", error);
		}
	};

	// Event handlers
	const handleEdit = (system: ICostSystem) => {
		setEditingSystem(system);
		setIsEditDialogOpen(true);
	};

	const handleCloneRequest = (systemId: string) => {
		const system = costSystems.find((s) => s._id === systemId);
		if (system) {
			setCloneDialog({
				isOpen: true,
				systemId,
				systemName: system.name
			});
			setCloneName(`${system.name} (Copy)`);
		}
	};

	return (
		<div className="space-y-6">
			{/* Header */}
			<div className="flex items-center justify-between">
				<div className="flex items-center gap-4">
					<div className="relative">
						<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
						<Input
							placeholder="Search cost systems..."
							value={searchQuery}
							onChange={(e) => setSearchQuery(e.target.value)}
							className="pl-10 w-64"
						/>
					</div>
					<Button
						onClick={loadCostSystems}
						variant="outline"
						size="sm"
						disabled={isLoading}
					>
						<RefreshCw
							className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`}
						/>
						Refresh
					</Button>
				</div>
				<Button onClick={() => setIsCreateDialogOpen(true)}>
					<Plus className="h-4 w-4 mr-2" />
					Create Cost System
				</Button>
			</div>

			{/* Cost Systems List */}
			<CostSystemList
				costSystems={costSystems}
				onEdit={handleEdit}
				onClone={handleCloneRequest}
				onDelete={handleDelete}
				onSetDefault={handleSetDefault}
				isLoading={isLoading}
			/>

			{/* Create Dialog */}
			<CostSystemEditor
				system={null}
				isOpen={isCreateDialogOpen}
				onClose={() => setIsCreateDialogOpen(false)}
				onSave={handleCreate}
				isCreating={true}
			/>

			{/* Edit Dialog */}
			<CostSystemEditor
				system={editingSystem}
				isOpen={isEditDialogOpen}
				onClose={() => {
					setIsEditDialogOpen(false);
					setEditingSystem(null);
				}}
				onSave={handleUpdate}
				isCreating={false}
			/>

			{/* Clone Dialog */}
			<Dialog
				open={cloneDialog.isOpen}
				onOpenChange={(open) => {
					if (!open) {
						setCloneDialog({ isOpen: false, systemId: null, systemName: "" });
						setCloneName("");
					}
				}}
			>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Clone Cost System</DialogTitle>
						<DialogDescription>
							Create a copy of "{cloneDialog.systemName}" with a new name.
						</DialogDescription>
					</DialogHeader>
					<div className="space-y-4">
						<div className="space-y-2">
							<Label htmlFor="clone-name">New Name</Label>
							<Input
								id="clone-name"
								value={cloneName}
								onChange={(e) => setCloneName(e.target.value)}
								placeholder="Enter new cost system name"
							/>
						</div>
					</div>
					<DialogFooter>
						<Button
							variant="outline"
							onClick={() => {
								setCloneDialog({
									isOpen: false,
									systemId: null,
									systemName: ""
								});
								setCloneName("");
							}}
						>
							Cancel
						</Button>
						<Button onClick={handleClone} disabled={!cloneName.trim()}>
							Clone
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</div>
	);
}
