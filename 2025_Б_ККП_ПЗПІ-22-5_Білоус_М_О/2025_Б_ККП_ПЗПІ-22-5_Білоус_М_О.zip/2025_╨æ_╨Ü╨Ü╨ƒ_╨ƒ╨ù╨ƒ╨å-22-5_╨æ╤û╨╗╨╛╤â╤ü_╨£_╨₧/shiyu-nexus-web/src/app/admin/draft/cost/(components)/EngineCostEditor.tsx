"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit3, Check, X } from "lucide-react";
import type { IEngineCost } from "@/lib/api/models/ICostSystem";
import type { IEngine } from "@/lib/api/models/IEngine";

interface EngineCostEditorProps {
	cost: IEngineCost;
	engine?: IEngine;
	onUpdate: (updatedCost: IEngineCost) => void;
	onRemove: () => void;
}

export function EngineCostEditor({
	cost,
	engine,
	onUpdate,
	onRemove
}: EngineCostEditorProps) {
	const [isEditing, setIsEditing] = useState(false);
	const [editingCosts, setEditingCosts] = useState<Map<number, number>>(
		new Map(cost.ascensionCosts)
	);

	const handleStartEdit = () => {
		setEditingCosts(new Map(cost.ascensionCosts));
		setIsEditing(true);
	};

	const handleSaveEdit = () => {
		onUpdate({
			...cost,
			ascensionCosts: new Map(editingCosts)
		});
		setIsEditing(false);
	};

	const handleCancelEdit = () => {
		setEditingCosts(new Map(cost.ascensionCosts));
		setIsEditing(false);
	};

	const updateCost = (ascension: number, value: string) => {
		const numValue = Math.max(0, Number.parseInt(value) || 0);
		setEditingCosts((prev) => new Map(prev.set(ascension, numValue)));
	};

	const getRarityColor = (rarity: string) => {
		switch (rarity?.toLowerCase()) {
			case "s":
				return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
			case "a":
				return "bg-purple-500/10 text-purple-600 border-purple-500/20";
			case "b":
				return "bg-blue-500/10 text-blue-600 border-blue-500/20";
			default:
				return "bg-gray-500/10 text-gray-600 border-gray-500/20";
		}
	};

	if (!engine) {
		return (
			<Card className="bg-destructive/5 border-destructive/20">
				<CardContent className="p-4">
					<div className="flex items-center justify-between">
						<div className="text-destructive">
							Engine not found (ID:{" "}
							{typeof cost.engine === "string" ? cost.engine : cost.engine._id})
						</div>
						<Button
							onClick={onRemove}
							variant="ghost"
							size="sm"
							className="text-destructive hover:text-destructive"
						>
							<Trash2 className="h-4 w-4" />
						</Button>
					</div>
				</CardContent>
			</Card>
		);
	}

	return (
		<Card>
			<CardContent className="p-4">
				<div className="flex items-start justify-between mb-4">
					<div className="flex items-center gap-3">
						<div>
							<div className="font-medium">{engine.name}</div>
							<div className="flex items-center gap-2 mt-1">
								<Badge className={getRarityColor(engine.rarity)}>
									{engine.rarity}
								</Badge>
								{engine.specialty && (
									<Badge variant="outline">{engine.specialty}</Badge>
								)}
							</div>
						</div>
					</div>
					<div className="flex items-center gap-2">
						{isEditing ? (
							<>
								<Button
									onClick={handleSaveEdit}
									variant="ghost"
									size="sm"
									className="text-green-600 hover:text-green-700"
								>
									<Check className="h-4 w-4" />
								</Button>
								<Button
									onClick={handleCancelEdit}
									variant="ghost"
									size="sm"
									className="text-gray-600 hover:text-gray-700"
								>
									<X className="h-4 w-4" />
								</Button>
							</>
						) : (
							<Button
								onClick={handleStartEdit}
								variant="ghost"
								size="sm"
								className="text-blue-600 hover:text-blue-700"
							>
								<Edit3 className="h-4 w-4" />
							</Button>
						)}
						<Button
							onClick={onRemove}
							variant="ghost"
							size="sm"
							className="text-destructive hover:text-destructive"
						>
							<Trash2 className="h-4 w-4" />
						</Button>
					</div>
				</div>

				<div className="space-y-3">
					<Label className="text-sm font-medium">Ascension Costs</Label>
					<div className="grid grid-cols-5 gap-2">
						{[1, 2, 3, 4, 5].map((ascension) => (
							<div key={ascension} className="space-y-1">
								<Label className="text-xs text-center block">
									Lv.{ascension}
								</Label>
								{isEditing ? (
									<Input
										type="number"
										min="0"
										value={editingCosts.get(ascension) || 0}
										onChange={(e) => updateCost(ascension, e.target.value)}
										className="text-center text-sm"
									/>
								) : (
									<div className="text-center text-sm bg-muted/50 rounded px-2 py-1 min-h-[32px] flex items-center justify-center">
										{cost.ascensionCosts.get(ascension) || 0}
									</div>
								)}
							</div>
						))}
					</div>
				</div>
			</CardContent>
		</Card>
	);
}
