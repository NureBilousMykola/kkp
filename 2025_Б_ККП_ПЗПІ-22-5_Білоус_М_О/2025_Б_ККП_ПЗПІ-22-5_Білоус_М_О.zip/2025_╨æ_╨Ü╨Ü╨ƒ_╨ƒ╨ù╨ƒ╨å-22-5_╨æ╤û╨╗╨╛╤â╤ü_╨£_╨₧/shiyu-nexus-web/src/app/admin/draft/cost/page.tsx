import { CostSystemManager } from "./(components)/CostSystemManager";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { verifySession } from "@/lib/utils/dal";
import { redirect } from "next/navigation";

export const metadata = {
	title: "Cost Management | Admin",
	description: "Manage agent and engine cost systems for draft presets"
};

export default async function AdminDraftCostPage() {
	const session = await verifySession();

	if (session.role !== "admin") {
		redirect("/");
	}

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<CardHeader className="w-full px-0">
					<CardTitle>
						<h1 className="text-4xl">Cost Management</h1>
					</CardTitle>
					<CardDescription>
						Create and manage cost systems that define agent mindscape and
						engine ascension costs for draft presets
					</CardDescription>
				</CardHeader>
			</div>

			<CostSystemManager token={session.token} />
		</div>
	);
}
