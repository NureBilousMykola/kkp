import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { verifySession } from "@/lib/utils/dal";
import {
	Settings,
	DollarSign,
	FileText,
	MapPin,
	Users,
	Trophy,
	Plus,
	ArrowRight
} from "lucide-react";
import Link from "next/link";

export const metadata = {
	title: "Draft Management | Admin",
	description: "Manage draft game configurations, presets, and settings"
};

export default async function AdminDraftPage() {
	const session = await verifySession();

	const features = [
		{
			title: "Draft Presets",
			description:
				"Create and manage complete draft configurations including rules, costs, constraints, and flow",
			icon: FileText,
			href: "./draft/presets",
			badge: "Core Feature",
			badgeVariant: "default" as const
		},
		{
			title: "Cost Management",
			description:
				"Configure agent mindscape and engine ascension costs for balanced gameplay",
			icon: DollarSign,
			href: "./draft/cost",
			badge: "Essential",
			badgeVariant: "secondary" as const
		},
		{
			title: "Stage Configuration",
			description: "Manage Shiyu Defense stages and room-specific constraints",
			icon: MapPin,
			href: "./draft/stages",
			badge: "Coming Soon",
			badgeVariant: "outline" as const
		}
	];

	const quickActions = [
		{
			title: "Create New Preset",
			description: "Set up a new draft configuration",
			href: "./draft/presets/create",
			icon: Plus
		},
		{
			title: "Manage Costs",
			description: "Adjust character and engine costs",
			href: "./draft/cost",
			icon: Settings
		}
	];

	return (
		<div className="space-y-8">
			<div className="space-y-2">
				<h1 className="text-4xl font-bold">Draft Management</h1>
				<p className="text-muted-foreground text-lg">
					Configure draft game modes, preset rules, character costs, and stage
					constraints
				</p>
			</div>

			{/* Quick Actions */}
			<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
				{quickActions.map((action) => (
					<Card key={action.href} className="hover:shadow-md transition-shadow">
						<CardContent className="p-6">
							<div className="flex items-center justify-between">
								<div className="space-y-2">
									<div className="flex items-center gap-2">
										<action.icon className="h-5 w-5 text-primary" />
										<h3 className="font-semibold">{action.title}</h3>
									</div>
									<p className="text-sm text-muted-foreground">
										{action.description}
									</p>
								</div>
								<Button asChild size="sm">
									<Link href={action.href}>
										<ArrowRight className="h-4 w-4" />
									</Link>
								</Button>
							</div>
						</CardContent>
					</Card>
				))}
			</div>

			{/* Feature Overview */}
			<div className="space-y-4">
				<h2 className="text-2xl font-semibold">Draft System Features</h2>
				<div className="grid grid-cols-1 md:grid-cols-3 gap-6">
					{features.map((feature) => (
						<Card key={feature.href} className="h-full">
							<CardHeader>
								<div className="flex items-center justify-between">
									<feature.icon className="h-8 w-8 text-primary" />
									<Badge variant={feature.badgeVariant}>{feature.badge}</Badge>
								</div>
								<CardTitle className="text-xl">{feature.title}</CardTitle>
								<CardDescription className="text-sm">
									{feature.description}
								</CardDescription>
							</CardHeader>
							<CardContent className="pt-0">
								<Button asChild variant="outline" className="w-full">
									<Link href={feature.href}>
										Configure
										<ArrowRight className="h-4 w-4 ml-2" />
									</Link>
								</Button>
							</CardContent>
						</Card>
					))}
				</div>
			</div>

			{/* Information Cards */}
			<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Users className="h-5 w-5" />
							What is a Draft Game?
						</CardTitle>
					</CardHeader>
					<CardContent className="space-y-4 text-sm">
						<p>
							Draft games are competitive matches where players take turns
							picking and banning characters in a structured format. This
							creates strategic depth and ensures balanced gameplay.
						</p>
						<div className="space-y-2">
							<h4 className="font-medium">Key Components:</h4>
							<ul className="list-disc list-inside space-y-1 text-muted-foreground">
								<li>
									<strong>Character Cost:</strong> Balances team composition by
									limiting powerful combinations
								</li>
								<li>
									<strong>Pre-ban:</strong> Strategic early bans based on
									collection differences
								</li>
								<li>
									<strong>Mirror Picks:</strong> Option to allow or restrict
									same character selections
								</li>
								<li>
									<strong>Stage Constraints:</strong> Room-specific character
									restrictions
								</li>
							</ul>
						</div>
					</CardContent>
				</Card>

				<Card>
					<CardHeader>
						<CardTitle className="flex items-center gap-2">
							<Trophy className="h-5 w-5" />
							Draft Flow Example
						</CardTitle>
					</CardHeader>
					<CardContent className="space-y-4 text-sm">
						<p>
							A typical draft follows a structured pick/ban sequence designed
							for competitive balance:
						</p>
						<div className="bg-muted p-3 rounded-lg space-y-1 font-mono text-xs">
							<div>1. Player 1: Pre-ban</div>
							<div>2. Player 2: Pre-ban</div>
							<div>3. Player 1: Ban</div>
							<div>4. Player 2: Ban</div>
							<div>5. Player 1: Pick</div>
							<div>6. Player 2: Pick × 2</div>
							<div>7. Player 1: Pick × 2</div>
							<div>8. Player 2: Pick</div>
						</div>
						<p className="text-muted-foreground">
							Each phase has configurable time limits and can be customized per
							preset.
						</p>
					</CardContent>
				</Card>
			</div>
		</div>
	);
}
