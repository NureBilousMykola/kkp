"use client";

import { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
	Card,
	CardContent,
	CardHeader,
	CardTitle,
	CardDescription
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Plus, Trash2, Save } from "lucide-react";
import { adminPresetService } from "@/lib/api/services/presets/service";
import { useAgents, useEngines } from "@/lib/contexts/dataProviders";
import Link from "next/link";

interface PresetFormProps {
	token: string;
}

interface CostSystem {
	id: string;
	name: string;
	description?: string;
	agentCosts: any[];
	engineCosts: any[];
	isDefault?: boolean;
}

// Mock storage function for cost systems - replace with API call
const getStoredCostSystems = (): CostSystem[] => {
	if (typeof window === "undefined") return [];
	const stored = localStorage.getItem("draft_cost_systems");
	return stored
		? JSON.parse(stored)
		: [
				{
					id: "default",
					name: "Default Cost System",
					description: "Standard balanced cost configuration",
					agentCosts: [],
					engineCosts: [],
					isDefault: true
				}
			];
};

const STAGE_OPTIONS = [
	{ value: 1, label: "Shiyu Defense 1" },
	{ value: 2, label: "Shiyu Defense 2" },
	{ value: 3, label: "Shiyu Defense 3" },
	{ value: 4, label: "Shiyu Defense 4" },
	{ value: 5, label: "Shiyu Defense 5" },
	{ value: 6, label: "Shiyu Defense 6" },
	{ value: 7, label: "Shiyu Defense 7" }
];

const DRAFT_PHASE_TYPES = [
	{ value: "PREBANS", label: "Pre-ban" },
	{ value: "BAN", label: "Ban" },
	{ value: "PICK", label: "Pick" },
	{ value: "STAGE_BAN", label: "Stage Ban" },
	{ value: "STAGE_PICK", label: "Stage Pick" }
];

export function PresetForm({ token }: PresetFormProps) {
	const router = useRouter();
	const { data: agents = [] } = useAgents();
	const { data: engines = [] } = useEngines();

	// Form state
	const [formData, setFormData] = useState({
		name: "",
		description: "",
		costSystemId: "default",
		rules: {
			minCharacters: 3,
			maxCharacters: 6,
			minCost: 0,
			maxCost: 200,
			allowedStages: [1, 2, 3, 4, 5, 6, 7],
			costDifferenceForPreban: 50,
			allowMirrorPicks: false,
			restarts: {
				freeRestarts: 2,
				paidRestarts: 2,
				timePenalty: 10
			}
		},
		draftFlow: [
			{ id: "1", type: "PREBANS", player: 1, count: 1, timeLimit: 60 },
			{ id: "2", type: "PREBANS", player: 2, count: 1, timeLimit: 60 },
			{ id: "3", type: "BAN", player: 1, count: 1, timeLimit: 30 },
			{ id: "4", type: "BAN", player: 2, count: 1, timeLimit: 30 },
			{ id: "5", type: "PICK", player: 1, count: 1, timeLimit: 45 },
			{ id: "6", type: "PICK", player: 2, count: 2, timeLimit: 45 },
			{ id: "7", type: "PICK", player: 1, count: 2, timeLimit: 45 },
			{ id: "8", type: "PICK", player: 2, count: 1, timeLimit: 45 }
		]
	});

	const [isSubmitting, setIsSubmitting] = useState(false);
	const [costSystems, setCostSystems] = useState<CostSystem[]>([]);

	// Load cost systems
	useEffect(() => {
		const systems = getStoredCostSystems();
		setCostSystems(systems);
	}, []);

	const selectedCostSystem = costSystems.find(
		(s) => s.id === formData.costSystemId
	);

	const updateFormData = useCallback((field: string, value: any) => {
		setFormData((prev) => ({
			...prev,
			[field]: value
		}));
	}, []);

	const updateRules = useCallback((field: string, value: any) => {
		setFormData((prev) => ({
			...prev,
			rules: {
				...prev.rules,
				[field]: value
			}
		}));
	}, []);

	const addDraftPhase = useCallback(() => {
		const newPhase = {
			id: Date.now().toString(),
			type: "PICK",
			player: 1,
			count: 1,
			timeLimit: 45
		};

		setFormData((prev) => ({
			...prev,
			draftFlow: [...prev.draftFlow, newPhase]
		}));
	}, []);

	const removeDraftPhase = useCallback((index: number) => {
		setFormData((prev) => ({
			...prev,
			draftFlow: prev.draftFlow.filter((_, i) => i !== index)
		}));
	}, []);

	const updateDraftPhase = useCallback(
		(index: number, field: string, value: any) => {
			setFormData((prev) => ({
				...prev,
				draftFlow: prev.draftFlow.map((phase, i) =>
					i === index ? { ...phase, [field]: value } : phase
				)
			}));
		},
		[]
	);

	const handleSubmit = useCallback(
		async (e: React.FormEvent) => {
			e.preventDefault();
			setIsSubmitting(true);

			try {
				const submitData = {
					name: formData.name,
					description: formData.description,
					rules: formData.rules,
					constraints: [],
					pickableAgents: [],
					agentCosts: agents.map((agent) => ({
						agent: agent._id,
						mindscapeCosts: {
							0: 10,
							1: 15,
							2: 20,
							3: 25,
							4: 30,
							5: 35,
							6: 40
						}
					})),
					engineCosts: engines.map((engine) => ({
						engine: engine._id,
						ascensionCosts: {
							1: 5,
							2: 8,
							3: 12,
							4: 15,
							5: 20
						}
					})),
					draftFlow: formData.draftFlow
				};

				const response = await adminPresetService.createPreset(
					token,
					submitData as any
				);

				if (response.ok) {
					router.push("/admin/draft/presets");
				} else {
					console.error("Failed to save preset:", response.error);
				}
			} catch (error) {
				console.error("Error saving preset:", error);
			} finally {
				setIsSubmitting(false);
			}
		},
		[formData, token, agents, engines, router]
	);

	return (
		<form onSubmit={handleSubmit} className="space-y-6">
			<Card>
				<CardHeader>
					<CardTitle>Basic Information</CardTitle>
				</CardHeader>
				<CardContent className="space-y-4">
					<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
						<div className="space-y-2">
							<Label htmlFor="name">Name *</Label>
							<Input
								id="name"
								value={formData.name}
								onChange={(e) => updateFormData("name", e.target.value)}
								placeholder="Enter preset name"
								required
							/>
						</div>
						<div className="space-y-2">
							<Label htmlFor="version">Version</Label>
							<Input id="version" value="v1" disabled className="bg-muted" />
						</div>
					</div>
					<div className="space-y-2">
						<Label htmlFor="description">Description</Label>
						<Textarea
							id="description"
							value={formData.description}
							onChange={(e) => updateFormData("description", e.target.value)}
							placeholder="Enter preset description"
							rows={3}
						/>
					</div>
				</CardContent>
			</Card>

			<Tabs defaultValue="rules" className="w-full">
				<TabsList className="grid w-full grid-cols-3">
					<TabsTrigger value="rules">General Rules</TabsTrigger>
					<TabsTrigger value="flow">Draft Flow</TabsTrigger>
					<TabsTrigger value="cost">Cost Configuration</TabsTrigger>
				</TabsList>

				<TabsContent value="rules" className="space-y-4">
					<Card>
						<CardHeader>
							<CardTitle>General Rules</CardTitle>
						</CardHeader>
						<CardContent className="space-y-6">
							<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
								<div className="space-y-2">
									<Label htmlFor="minCharacters">Min Characters</Label>
									<Input
										id="minCharacters"
										type="number"
										min="1"
										max="12"
										value={formData.rules.minCharacters}
										onChange={(e) =>
											updateRules(
												"minCharacters",
												Number.parseInt(e.target.value)
											)
										}
									/>
								</div>
								<div className="space-y-2">
									<Label htmlFor="maxCharacters">Max Characters</Label>
									<Input
										id="maxCharacters"
										type="number"
										min="1"
										max="12"
										value={formData.rules.maxCharacters}
										onChange={(e) =>
											updateRules(
												"maxCharacters",
												Number.parseInt(e.target.value)
											)
										}
									/>
								</div>
								<div className="space-y-2">
									<Label htmlFor="minCost">Min Cost</Label>
									<Input
										id="minCost"
										type="number"
										min="0"
										value={formData.rules.minCost}
										onChange={(e) =>
											updateRules("minCost", Number.parseInt(e.target.value))
										}
									/>
								</div>
								<div className="space-y-2">
									<Label htmlFor="maxCost">Max Cost</Label>
									<Input
										id="maxCost"
										type="number"
										min="0"
										value={formData.rules.maxCost}
										onChange={(e) =>
											updateRules("maxCost", Number.parseInt(e.target.value))
										}
									/>
								</div>
								<div className="space-y-2">
									<Label htmlFor="costDifferenceForPreban">
										Cost Difference for Pre-ban
									</Label>
									<Input
										id="costDifferenceForPreban"
										type="number"
										min="0"
										value={formData.rules.costDifferenceForPreban}
										onChange={(e) =>
											updateRules(
												"costDifferenceForPreban",
												Number.parseInt(e.target.value)
											)
										}
									/>
								</div>
							</div>

							<div className="space-y-4">
								<div className="flex items-center space-x-2">
									<Switch
										id="allowMirrorPicks"
										checked={formData.rules.allowMirrorPicks}
										onCheckedChange={(checked) =>
											updateRules("allowMirrorPicks", checked)
										}
									/>
									<Label htmlFor="allowMirrorPicks">Allow Mirror Picks</Label>
								</div>
							</div>

							<div className="space-y-2">
								<Label>Allowed Stages</Label>
								<div className="grid grid-cols-2 md:grid-cols-4 gap-2">
									{STAGE_OPTIONS.map((stage) => (
										<div
											key={stage.value}
											className="flex items-center space-x-2"
										>
											<Checkbox
												id={`stage-${stage.value}`}
												checked={formData.rules.allowedStages.includes(
													stage.value
												)}
												onCheckedChange={(checked) => {
													const currentStages = formData.rules.allowedStages;
													const newStages = checked
														? [...currentStages, stage.value]
														: currentStages.filter((s) => s !== stage.value);
													updateRules("allowedStages", newStages);
												}}
											/>
											<Label
												htmlFor={`stage-${stage.value}`}
												className="text-sm"
											>
												{stage.label}
											</Label>
										</div>
									))}
								</div>
							</div>

							<Separator />

							<div className="space-y-4">
								<h4 className="font-medium">Restarts Configuration</h4>
								<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
									<div className="space-y-2">
										<Label htmlFor="freeRestarts">Free Restarts</Label>
										<Input
											id="freeRestarts"
											type="number"
											min="0"
											value={formData.rules.restarts.freeRestarts}
											onChange={(e) =>
												updateRules("restarts", {
													...formData.rules.restarts,
													freeRestarts: Number.parseInt(e.target.value)
												})
											}
										/>
									</div>
									<div className="space-y-2">
										<Label htmlFor="paidRestarts">Paid Restarts</Label>
										<Input
											id="paidRestarts"
											type="number"
											min="0"
											value={formData.rules.restarts.paidRestarts}
											onChange={(e) =>
												updateRules("restarts", {
													...formData.rules.restarts,
													paidRestarts: Number.parseInt(e.target.value)
												})
											}
										/>
									</div>
									<div className="space-y-2">
										<Label htmlFor="timePenalty">Time Penalty (seconds)</Label>
										<Input
											id="timePenalty"
											type="number"
											min="0"
											value={formData.rules.restarts.timePenalty}
											onChange={(e) =>
												updateRules("restarts", {
													...formData.rules.restarts,
													timePenalty: Number.parseInt(e.target.value)
												})
											}
										/>
									</div>
								</div>
							</div>
						</CardContent>
					</Card>
				</TabsContent>

				<TabsContent value="flow" className="space-y-4">
					<Card>
						<CardHeader>
							<div className="flex items-center justify-between">
								<CardTitle>Draft Flow</CardTitle>
								<Button
									type="button"
									variant="outline"
									size="sm"
									onClick={addDraftPhase}
								>
									<Plus className="h-4 w-4" />
									Add Phase
								</Button>
							</div>
						</CardHeader>
						<CardContent className="space-y-4">
							{formData.draftFlow.map((phase, index) => (
								<div key={phase.id} className="p-4 border rounded-lg space-y-4">
									<div className="flex items-center justify-between">
										<Badge variant="outline">Phase {index + 1}</Badge>
										<Button
											type="button"
											variant="outline"
											size="sm"
											onClick={() => removeDraftPhase(index)}
										>
											<Trash2 className="h-4 w-4" />
										</Button>
									</div>
									<div className="grid grid-cols-1 md:grid-cols-4 gap-4">
										<div className="space-y-2">
											<Label>Type</Label>
											<Select
												value={phase.type}
												onValueChange={(value) =>
													updateDraftPhase(index, "type", value)
												}
											>
												<SelectTrigger>
													<SelectValue />
												</SelectTrigger>
												<SelectContent>
													{DRAFT_PHASE_TYPES.map((type) => (
														<SelectItem key={type.value} value={type.value}>
															{type.label}
														</SelectItem>
													))}
												</SelectContent>
											</Select>
										</div>
										<div className="space-y-2">
											<Label>Player</Label>
											<Select
												value={phase.player.toString()}
												onValueChange={(value) =>
													updateDraftPhase(
														index,
														"player",
														Number.parseInt(value)
													)
												}
											>
												<SelectTrigger>
													<SelectValue />
												</SelectTrigger>
												<SelectContent>
													<SelectItem key="player-1" value="1">
														Player 1
													</SelectItem>
													<SelectItem key="player-2" value="2">
														Player 2
													</SelectItem>
												</SelectContent>
											</Select>
										</div>
										<div className="space-y-2">
											<Label>Count</Label>
											<Input
												type="number"
												min="1"
												max="6"
												value={phase.count}
												onChange={(e) =>
													updateDraftPhase(
														index,
														"count",
														Number.parseInt(e.target.value)
													)
												}
											/>
										</div>
										<div className="space-y-2">
											<Label>Time Limit (seconds)</Label>
											<Input
												type="number"
												min="10"
												max="300"
												value={phase.timeLimit}
												onChange={(e) =>
													updateDraftPhase(
														index,
														"timeLimit",
														Number.parseInt(e.target.value)
													)
												}
											/>
										</div>
									</div>
								</div>
							))}
						</CardContent>
					</Card>
				</TabsContent>

				<TabsContent value="cost" className="space-y-4">
					<Card>
						<CardHeader>
							<CardTitle>Cost Configuration</CardTitle>
							<CardDescription>
								Select a cost system that defines agent mindscape and engine
								ascension costs for this preset
							</CardDescription>
						</CardHeader>
						<CardContent className="space-y-6">
							<div className="space-y-4">
								<div className="space-y-2">
									<Label htmlFor="cost-system-select">Cost System</Label>
									<Select
										value={formData.costSystemId || ""}
										onValueChange={(value) =>
											setFormData((prev) => ({
												...prev,
												costSystemId: value
											}))
										}
									>
										<SelectTrigger id="cost-system-select">
											<SelectValue placeholder="Select a cost system" />
										</SelectTrigger>
										<SelectContent>
											{costSystems.map((system) => (
												<SelectItem key={system.id} value={system.id}>
													<div className="flex items-center gap-2">
														{system.name}
														{system.isDefault && (
															<Badge variant="secondary" className="text-xs">
																Default
															</Badge>
														)}
													</div>
												</SelectItem>
											))}
										</SelectContent>
									</Select>
								</div>

								{selectedCostSystem && (
									<div className="p-4 bg-muted rounded-lg space-y-2">
										<div className="flex items-center gap-2">
											<h4 className="font-medium">{selectedCostSystem.name}</h4>
											{selectedCostSystem.isDefault && (
												<Badge variant="secondary">Default</Badge>
											)}
										</div>
										{selectedCostSystem.description && (
											<p className="text-sm text-muted-foreground">
												{selectedCostSystem.description}
											</p>
										)}
										<p className="text-xs text-muted-foreground">
											{selectedCostSystem.agentCosts.length} agents,{" "}
											{selectedCostSystem.engineCosts.length} engines configured
										</p>
									</div>
								)}

								<div className="flex items-center gap-2">
									<p className="text-sm text-muted-foreground">
										Need a different cost configuration?
									</p>
									<Button variant="outline" size="sm" asChild>
										<Link href="../cost">Manage Cost Systems</Link>
									</Button>
								</div>
							</div>
						</CardContent>
					</Card>
				</TabsContent>
			</Tabs>

			<div className="flex items-center gap-4">
				<Button type="submit" disabled={isSubmitting}>
					<Save className="h-4 w-4" />
					{isSubmitting ? "Creating..." : "Create Preset"}
				</Button>
				<Button type="button" variant="outline" onClick={() => router.back()}>
					Cancel
				</Button>
			</div>
		</form>
	);
}
