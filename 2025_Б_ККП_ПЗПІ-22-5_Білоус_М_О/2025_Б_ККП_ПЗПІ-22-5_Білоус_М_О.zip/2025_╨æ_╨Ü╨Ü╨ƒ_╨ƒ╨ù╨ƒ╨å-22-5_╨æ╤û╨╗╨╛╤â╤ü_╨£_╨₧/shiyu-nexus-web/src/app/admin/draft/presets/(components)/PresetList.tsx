"use client";

import { useState, useCallback, useEffect } from "react";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Trash2, Edit, Copy, Eye } from "lucide-react";
import {
	adminPresetService,
	presetService
} from "@/lib/api/services/presets/service";
import type { IDraftPreset } from "@/lib/api/models/game/IDraftPreset";
import Link from "next/link";

interface PresetListProps {
	token: string;
}

export function PresetList({ token }: PresetListProps) {
	const [presets, setPresets] = useState<IDraftPreset[]>([]);
	const [loading, setLoading] = useState(true);
	const [searchTerm, setSearchTerm] = useState("");
	const [presetToDelete, setPresetToDelete] = useState<string | null>(null);

	const loadPresets = useCallback(async () => {
		setLoading(true);
		try {
			const response = await presetService.getPresets();
			if (response.ok) {
				setPresets(response.data || []);
			} else {
				console.error("Failed to load presets:", response.error);
			}
		} catch (error) {
			console.error("Failed to load presets:", error);
		} finally {
			setLoading(false);
		}
	}, []);

	useEffect(() => {
		loadPresets();
	}, [loadPresets]);

	const filteredPresets = presets.filter(
		(preset) =>
			preset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
			preset.description?.toLowerCase().includes(searchTerm.toLowerCase())
	);

	const deletePreset = useCallback(async () => {
		if (!presetToDelete) return;

		try {
			const response = await adminPresetService.deletePreset(
				token,
				presetToDelete
			);
			if (response.ok) {
				await loadPresets();
				setPresetToDelete(null);
			}
		} catch (error) {
			console.error("Failed to delete preset:", error);
		}
	}, [presetToDelete, token, loadPresets]);

	const handleClone = useCallback(
		async (presetId: string, originalName: string) => {
			try {
				const cloneName = `${originalName} (Copy)`;
				const response = await adminPresetService.clonePreset(
					token,
					presetId,
					cloneName
				);
				if (response.ok) {
					await loadPresets();
				}
			} catch (error) {
				console.error("Failed to clone preset:", error);
			}
		},
		[token, loadPresets]
	);

	if (loading) {
		return (
			<div className="flex items-center justify-center p-8">
				<div className="text-lg">Loading presets...</div>
			</div>
		);
	}

	return (
		<>
			<div className="flex flex-col gap-4">
				<div className="flex items-center gap-4">
					<Input
						placeholder="Search presets..."
						value={searchTerm}
						onChange={(e) => setSearchTerm(e.target.value)}
						className="max-w-sm"
					/>
				</div>

				<div className="rounded-md border-2 border-border">
					<Table>
						<TableHeader>
							<TableRow>
								<TableHead>Name</TableHead>
								<TableHead>Description</TableHead>
								<TableHead>Characters</TableHead>
								<TableHead>Cost Range</TableHead>
								<TableHead>Stages</TableHead>
								<TableHead>Mirror Picks</TableHead>
								<TableHead>Version</TableHead>
								<TableHead className="w-32 text-center">Actions</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{!filteredPresets.length ? (
								<TableRow>
									<TableCell colSpan={8} className="py-8 text-center">
										No presets found
									</TableCell>
								</TableRow>
							) : (
								filteredPresets.map((preset) => (
									<TableRow key={preset._id}>
										<TableCell>
											<div className="font-medium">{preset.name}</div>
										</TableCell>
										<TableCell>
											<div className="max-w-xs truncate text-sm text-muted-foreground">
												{preset.description || "No description"}
											</div>
										</TableCell>
										<TableCell>
											<div className="text-sm">
												{preset.rules.minCharacters}-
												{preset.rules.maxCharacters}
											</div>
										</TableCell>
										<TableCell>
											<div className="text-sm">
												{preset.rules.minCost}-{preset.rules.maxCost}
											</div>
										</TableCell>
										<TableCell>
											<div className="text-sm">
												{preset.rules.allowedStages.length} stage
												{preset.rules.allowedStages.length !== 1 ? "s" : ""}
											</div>
										</TableCell>
										<TableCell>
											<Badge
												variant={
													preset.rules.allowMirrorPicks
														? "default"
														: "secondary"
												}
											>
												{preset.rules.allowMirrorPicks ? "Allowed" : "Disabled"}
											</Badge>
										</TableCell>
										<TableCell>
											<Badge variant="outline">v{preset.version}</Badge>
										</TableCell>
										<TableCell>
											<div className="flex items-center gap-1">
												<Button size="sm" variant="outline" asChild>
													<Link href={`./presets/${preset._id}`}>
														<Eye className="h-3 w-3" />
													</Link>
												</Button>
												<Button size="sm" variant="outline" asChild>
													<Link href={`./presets/${preset._id}/edit`}>
														<Edit className="h-3 w-3" />
													</Link>
												</Button>
												<Button
													size="sm"
													variant="outline"
													onClick={() => handleClone(preset._id, preset.name)}
												>
													<Copy className="h-3 w-3" />
												</Button>
												<Button
													size="sm"
													variant="outline"
													onClick={() => setPresetToDelete(preset._id)}
												>
													<Trash2 className="h-3 w-3" />
												</Button>
											</div>
										</TableCell>
									</TableRow>
								))
							)}
						</TableBody>
					</Table>
				</div>
			</div>

			<Dialog
				open={!!presetToDelete}
				onOpenChange={(open) => !open && setPresetToDelete(null)}
			>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Are you sure?</DialogTitle>
						<DialogDescription>
							This action cannot be undone. This will permanently delete this
							preset from the system.
						</DialogDescription>
					</DialogHeader>
					<DialogFooter>
						<Button variant="outline" onClick={() => setPresetToDelete(null)}>
							Cancel
						</Button>
						<Button variant="destructive" onClick={deletePreset}>
							Delete
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</>
	);
}
