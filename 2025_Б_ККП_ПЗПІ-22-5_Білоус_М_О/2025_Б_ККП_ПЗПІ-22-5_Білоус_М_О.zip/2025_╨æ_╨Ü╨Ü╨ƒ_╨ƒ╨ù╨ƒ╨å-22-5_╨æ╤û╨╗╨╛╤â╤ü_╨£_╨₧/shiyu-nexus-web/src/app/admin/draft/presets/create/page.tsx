import { PresetForm } from "../(components)/PresetForm";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { verifySession } from "@/lib/utils/dal";

export const metadata = {
	title: "Create Draft Preset | Admin",
	description: "Create a new draft preset configuration"
};

export default async function CreatePresetPage() {
	const session = await verifySession();

	return (
		<div className="space-y-6">
			<CardHeader className="px-0">
				<CardTitle>
					<h1 className="text-4xl">Create Draft Preset</h1>
				</CardTitle>
				<CardDescription>
					Define rules, costs, constraints, and flow for a new draft preset
				</CardDescription>
			</CardHeader>

			<PresetForm token={session.token} />
		</div>
	);
}
