import { PresetList } from "./(components)/PresetList";
import { Button } from "@/components/ui/button";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { verifySession } from "@/lib/utils/dal";
import { Plus } from "lucide-react";
import Link from "next/link";

export const metadata = {
	title: "Draft Presets | Admin",
	description: "Manage draft presets and configurations"
};

export default async function AdminDraftPresetsPage() {
	const session = await verifySession();

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<CardHeader className="w-full px-0">
					<CardTitle>
						<h1 className="text-4xl">Draft Presets</h1>
					</CardTitle>
					<CardDescription>
						Create and manage draft presets that define rules, costs,
						constraints, and flow for draft games
					</CardDescription>
				</CardHeader>

				<Button asChild>
					<Link href="./presets/create">
						<Plus className="h-4 w-4" />
						Create Preset
					</Link>
				</Button>
			</div>

			<PresetList token={session.token} />
		</div>
	);
}
