"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle
} from "@/components/ui/dialog";
import { Plus, Save, X } from "lucide-react";
import type { IStageEnemy } from "@/lib/api/models/IStageEnemy";
import type { IEnemy } from "@/lib/api/models/IEnemy";
import { adminEnemyService } from "@/lib/api/services/enemies/service";
import { toast } from "sonner";

interface StageRoomManagerProps {
	stageEnemies: IStageEnemy[];
	allEnemies: IEnemy[];
	token: string;
}

interface StageRoomData {
	stageId: number;
	roomId: number;
	enemies: {
		enemy: IEnemy;
		level: number;
		stageEnemyId: string;
	}[];
}

// API DTOs that match the backend structure
interface CreateStageEnemyDto {
	stageId: number;
	roomId: number;
	enemies: {
		enemyId: string;
		level: number;
	}[];
}

interface UpdateStageEnemyDto {
	stageId?: number;
	roomId?: number;
	enemies?: {
		enemyId: string;
		level: number;
	}[];
}

// Generate level options from 40 to 70 with step 5
const LEVEL_OPTIONS = Array.from({ length: 7 }, (_, i) => 40 + i * 5);

export default function StageRoomManager({
	stageEnemies,
	allEnemies,
	token
}: StageRoomManagerProps) {
	const [isLoading, setIsLoading] = useState(false);
	const [editingRoom, setEditingRoom] = useState<StageRoomData | null>(null);
	const [selectedEnemyId, setSelectedEnemyId] = useState<string>("");
	const [level, setLevel] = useState<number>(40);
	const [isAddingEnemy, setIsAddingEnemy] = useState(false);

	// Create a comprehensive data structure for all stages and rooms
	const createStageRoomMatrix = (): StageRoomData[][] => {
		const matrix: StageRoomData[][] = [];

		for (let stageId = 1; stageId <= 7; stageId++) {
			const stageRooms: StageRoomData[] = [];

			for (let roomId = 1; roomId <= 2; roomId++) {
				// Each stage-room combination has at most one document that contains an array of enemies.
				const stageRoomDoc = stageEnemies.find(
					(se) => se.stageId === stageId && se.roomId === roomId
				);

				stageRooms.push({
					stageId,
					roomId,
					enemies:
						(stageRoomDoc?.enemies
							?.map((entry) => {
								// Backend now returns enemy data in 'enemyId' field (populated)
								// Handle both populated object and string ID cases
								let enemyData: IEnemy | null = null;

								if (
									typeof entry.enemyId === "object" &&
									entry.enemyId !== null
								) {
									// enemyId is populated with enemy data
									enemyData = entry.enemyId as IEnemy;
								} else if (entry.enemy) {
									// Fallback to legacy 'enemy' field
									enemyData = entry.enemy;
								} else if (typeof entry.enemyId === "string") {
									// enemyId is just a string, find in allEnemies
									enemyData =
										allEnemies.find((e) => e._id === entry.enemyId) || null;
								}

								if (!enemyData) {
									console.warn("Enemy data not found for entry:", entry);
									return null;
								}

								return {
									enemy: enemyData,
									level: entry.level,
									stageEnemyId: stageRoomDoc._id
								};
							})
							.filter(Boolean) as StageRoomData["enemies"]) || []
				});
			}

			matrix.push(stageRooms);
		}

		return matrix;
	};

	const [stageMatrix, setStageMatrix] = useState(createStageRoomMatrix());

	const handleSetEnemy = (roomData: StageRoomData) => {
		setEditingRoom(roomData);
		setSelectedEnemyId("");
		setLevel(40);
		setIsAddingEnemy(true);
	};

	const handleSaveEnemy = async () => {
		if (!editingRoom || !token) return;

		setIsLoading(true);
		try {
			const selectedEnemy = allEnemies.find((e) => e._id === selectedEnemyId);
			if (!selectedEnemy) {
				toast.error("Please select an enemy");
				return;
			}

			// Create new stage enemy
			const createDto: CreateStageEnemyDto = {
				stageId: editingRoom.stageId,
				roomId: editingRoom.roomId,
				enemies: [
					{
						enemyId: selectedEnemyId,
						level
					}
				]
			};

			const response = await adminEnemyService.createStageEnemy(
				token,
				createDto as any
			);

			// Update local state
			const newMatrix = [...stageMatrix];
			const stageIndex = editingRoom.stageId - 1;
			const roomIndex = editingRoom.roomId - 1;

			newMatrix[stageIndex][roomIndex].enemies.push({
				enemy: selectedEnemy,
				level,
				stageEnemyId: response.data?._id || "new"
			});

			setStageMatrix(newMatrix);
			toast.success("Enemy assigned to room successfully");
			setEditingRoom(null);
		} catch (error) {
			console.error("Error saving enemy:", error);
			toast.error("Failed to save enemy");
		} finally {
			setIsLoading(false);
		}
	};

	const handleRemoveEnemy = async (
		roomData: StageRoomData,
		stageEnemyId: string
	) => {
		if (!token) return;

		setIsLoading(true);
		try {
			await adminEnemyService.removeStageEnemy(token, stageEnemyId);

			// Update local state
			const newMatrix = [...stageMatrix];
			const stageIndex = roomData.stageId - 1;
			const roomIndex = roomData.roomId - 1;

			newMatrix[stageIndex][roomIndex].enemies = newMatrix[stageIndex][
				roomIndex
			].enemies.filter((e) => e.stageEnemyId !== stageEnemyId);

			setStageMatrix(newMatrix);
			toast.success("Enemy removed successfully");
		} catch (error) {
			console.error("Error removing enemy:", error);
			toast.error("Failed to remove enemy");
		} finally {
			setIsLoading(false);
		}
	};

	return (
		<div className="space-y-6">
			<div className="grid gap-6">
				{stageMatrix.map((stageRooms, stageIndex) => (
					<Card key={`stage-${stageIndex + 1}`} className="w-full">
						<CardHeader>
							<CardTitle className="flex items-center gap-2">
								<span>Stage {stageIndex + 1}</span>
								<Badge variant="outline">
									{stageRooms.reduce(
										(acc, room) => acc + room.enemies.length,
										0
									)}{" "}
									Enemies Configured
								</Badge>
							</CardTitle>
						</CardHeader>
						<CardContent>
							<div className="grid gap-4 md:grid-cols-2">
								{stageRooms.map((roomData) => (
									<Card
										key={`stage-${roomData.stageId}-room-${roomData.roomId}`}
										className="border-2 border-dashed"
									>
										<CardHeader className="pb-3">
											<CardTitle className="flex items-center justify-between text-lg">
												<span>Room {roomData.roomId}</span>
												<Button
													size="sm"
													variant="default"
													onClick={() => handleSetEnemy(roomData)}
												>
													<Plus className="mr-1 h-3 w-3" />
													Add Enemy
												</Button>
											</CardTitle>
										</CardHeader>
										<CardContent className="space-y-4">
											{roomData.enemies.length > 0 ? (
												<div className="space-y-3">
													{roomData.enemies.map((enemyData, enemyIndex) => (
														<div
															key={`stage-${roomData.stageId}-room-${roomData.roomId}-enemy-${enemyIndex}-${enemyData.stageEnemyId}`}
															className="rounded-md border p-3"
														>
															<div className="mb-2 flex items-center justify-between">
																<div className="flex items-center gap-2">
																	<span className="font-medium">
																		{enemyData.enemy.name}
																	</span>
																	<Badge variant="secondary">
																		Level {enemyData.level}
																	</Badge>
																</div>
																<Button
																	size="sm"
																	variant="destructive"
																	onClick={() =>
																		handleRemoveEnemy(
																			roomData,
																			enemyData.stageEnemyId
																		)
																	}
																	disabled={isLoading}
																>
																	<X className="h-3 w-3" />
																</Button>
															</div>
															<div className="space-y-1">
																<div className="flex flex-wrap gap-1">
																	<span className="text-muted-foreground text-sm">
																		Weaknesses:
																	</span>
																	{enemyData.enemy.weaknessAttributes.map(
																		(attr, attrIndex) => (
																			<Badge
																				key={`stage-${roomData.stageId}-room-${roomData.roomId}-enemy-${enemyIndex}-weakness-${attrIndex}-${attr}`}
																				variant="destructive"
																				className="text-xs"
																			>
																				{attr}
																			</Badge>
																		)
																	)}
																</div>
																<div className="flex flex-wrap gap-1">
																	<span className="text-muted-foreground text-sm">
																		Resistances:
																	</span>
																	{enemyData.enemy.resistanceAttributes.map(
																		(attr, attrIndex) => (
																			<Badge
																				key={`stage-${roomData.stageId}-room-${roomData.roomId}-enemy-${enemyIndex}-resistance-${attrIndex}-${attr}`}
																				variant="secondary"
																				className="text-xs"
																			>
																				{attr}
																			</Badge>
																		)
																	)}
																</div>
															</div>
														</div>
													))}
												</div>
											) : (
												<div className="text-center py-8">
													<p className="text-muted-foreground mb-4">
														No enemies assigned
													</p>
												</div>
											)}
										</CardContent>
									</Card>
								))}
							</div>
						</CardContent>
					</Card>
				))}
			</div>

			{/* Add Enemy Dialog */}
			<Dialog open={!!editingRoom} onOpenChange={() => setEditingRoom(null)}>
				<DialogContent className="sm:max-w-[500px]">
					<DialogHeader>
						<DialogTitle>
							Add Enemy to Stage {editingRoom?.stageId} Room{" "}
							{editingRoom?.roomId}
						</DialogTitle>
						<DialogDescription>
							Select an enemy and set its level for this room.
						</DialogDescription>
					</DialogHeader>

					<div className="space-y-4">
						<div className="space-y-2">
							<Label htmlFor="enemy-select">Enemy</Label>
							<Select
								value={selectedEnemyId}
								onValueChange={setSelectedEnemyId}
							>
								<SelectTrigger>
									<SelectValue placeholder="Select an enemy" />
								</SelectTrigger>
								<SelectContent>
									{allEnemies.map((enemy) => (
										<SelectItem key={enemy._id} value={enemy._id}>
											<div className="flex items-center gap-2">
												<span>{enemy.name}</span>
												<Badge variant="outline" className="text-xs">
													{enemy.category}
												</Badge>
											</div>
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>

						<div className="space-y-2">
							<Label htmlFor="level-select">Level</Label>
							<Select
								value={level.toString()}
								onValueChange={(value) => setLevel(Number(value))}
							>
								<SelectTrigger>
									<SelectValue placeholder="Select level" />
								</SelectTrigger>
								<SelectContent>
									{LEVEL_OPTIONS.map((levelOption) => (
										<SelectItem
											key={levelOption}
											value={levelOption.toString()}
										>
											Level {levelOption}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>

						{selectedEnemyId && (
							<div className="space-y-2">
								<Label>Enemy Details</Label>
								{(() => {
									const selectedEnemy = allEnemies.find(
										(e) => e._id === selectedEnemyId
									);
									return selectedEnemy ? (
										<div className="p-3 border rounded-md space-y-2">
											<div className="flex flex-wrap gap-1">
												<span className="text-sm font-medium">Weaknesses:</span>
												{selectedEnemy.weaknessAttributes.map((attr) => (
													<Badge
														key={`dialog-weakness-${attr}-${selectedEnemy._id}`}
														variant="destructive"
														className="text-xs"
													>
														{attr}
													</Badge>
												))}
											</div>
											<div className="flex flex-wrap gap-1">
												<span className="text-sm font-medium">
													Resistances:
												</span>
												{selectedEnemy.resistanceAttributes.map((attr) => (
													<Badge
														key={`dialog-resistance-${attr}-${selectedEnemy._id}`}
														variant="secondary"
														className="text-xs"
													>
														{attr}
													</Badge>
												))}
											</div>
										</div>
									) : null;
								})()}
							</div>
						)}
					</div>

					<DialogFooter>
						<Button variant="outline" onClick={() => setEditingRoom(null)}>
							Cancel
						</Button>
						<Button
							onClick={handleSaveEnemy}
							disabled={!selectedEnemyId || isLoading}
						>
							<Save className="h-4 w-4 mr-2" />
							{isLoading ? "Saving..." : "Save"}
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</div>
	);
}
