import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { enemyService } from "@/lib/api/services/enemies/service";
import { verifySession } from "@/lib/utils/dal";
import StageRoomManager from "./(components)/StageRoomManager";

export const metadata = {
	title: "Draft Stages Management | Admin",
	description: "Manage enemies for each stage and room in the draft system"
};

export default async function AdminDraftStagePage() {
	const session = await verifySession();

	try {
		const [stageEnemiesResponse, allEnemiesResponse] = await Promise.all([
			enemyService.getStageEnemies(),
			enemyService.getEnemies()
		]);

		const stageEnemies = stageEnemiesResponse.data || [];
		const allEnemies = allEnemiesResponse.data || [];

		return (
			<div className="space-y-6">
				<div className="flex items-center justify-between">
					<CardHeader className="w-full px-0">
						<CardTitle>
							<h1 className="text-4xl">Draft Stages Management</h1>
						</CardTitle>
						<CardDescription>
							Configure enemies for each room in all 7 draft stages.
						</CardDescription>
					</CardHeader>
				</div>

				<StageRoomManager
					stageEnemies={stageEnemies}
					allEnemies={allEnemies}
					token={session.token}
				/>
			</div>
		);
	} catch (error) {
		console.error("Error loading stage management page:", error);
		return (
			<div className="space-y-6">
				<div className="flex items-center justify-between">
					<CardHeader className="w-full px-0">
						<CardTitle>
							<h1 className="text-4xl">Draft Stages Management</h1>
						</CardTitle>
						<CardDescription>
							Error loading stage data. Please check the console for details.
						</CardDescription>
					</CardHeader>
				</div>
			</div>
		);
	}
}
