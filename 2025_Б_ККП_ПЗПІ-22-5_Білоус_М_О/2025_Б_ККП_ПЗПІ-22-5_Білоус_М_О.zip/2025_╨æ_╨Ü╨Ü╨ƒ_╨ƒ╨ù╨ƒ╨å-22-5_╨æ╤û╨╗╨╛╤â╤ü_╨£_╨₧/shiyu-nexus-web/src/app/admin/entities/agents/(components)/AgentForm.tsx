"use client";

import { useActionState, useDeferredValue, useEffect, useState } from "react";
import { createAgent, updateAgent } from "@/lib/actions/agents/actions";
import { Attributes } from "@/lib/api/keys/Attribute";
import { Specialties } from "@/lib/api/keys/Specialty";
import type { IAgent } from "@/lib/api/models/IAgent";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertCircle, Loader2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { useAgents, useFactions } from "@/lib/contexts/dataProviders";
import { redirect } from "next/navigation";
import { FormImage } from "../../../(components)/form/formImagePreview";

interface AgentFormProps {
	agent?: IAgent;
}


export const AgentForm: React.FC<AgentFormProps> = ({ agent }) => {
	const [createState, createAgentAction, isCreating] = useActionState(
		createAgent,
		undefined
	);

	const [updateState, updateAgentAction, isUpdating] = useActionState(
		updateAgent,
		undefined
	);

	const { data: factions } = useFactions();
	const { refreshData } = useAgents();

	const isLoading = isCreating || isUpdating;

	useEffect(() => {
		if (createState?.success || updateState?.success) {
			refreshData();
			redirect("./");
		}
	}, [createState, updateState, refreshData]);

	const [imageUrl, setImageUrl] = useState(agent?.imageUrl || "");
	const [iconUrl, setIconUrl] = useState(agent?.iconUrl || "");

	const deferredImageUrl = useDeferredValue(imageUrl);
	const deferredIconUrl = useDeferredValue(iconUrl);

	return (
		<form action={agent ? updateAgentAction : createAgentAction}>
			<Card>
				<CardContent className="space-y-4">
					{(createState?.message || updateState?.message) &&
						(!createState?.success || !updateState?.success) && (
							<Alert variant="destructive">
								<AlertCircle className="h-4 w-4" />
								<AlertTitle>Api Error:</AlertTitle>
								<AlertDescription>
									{createState?.message || updateState?.message}
								</AlertDescription>
							</Alert>
						)}

					{agent && (
						<div className="space-y-2 text-muted-foreground">
							<Label htmlFor="id">Agent ID</Label>
							<Input
								readOnly
								id="id"
								name="id"
								defaultValue={agent?._id}
								required
							/>
							{updateState?.errors?.id && (
								<span className="mt-0 text-destructive text-xs">
									{updateState?.errors?.id}
								</span>
							)}
						</div>
					)}

					<div className="grid grid-cols-1 gap-4 md:grid-cols-3">
						<div className="space-y-2">
							<Label htmlFor="name">Name</Label>
							<Input
								id="name"
								name="name"
								placeholder="Agent name"
								defaultValue={agent?.name}
								required
								aria-errormessage={
									createState?.errors?.name?.at(0) ||
									updateState?.errors?.name?.at(0)
								}
								className={cn(
									createState?.errors?.name ||
										(updateState?.errors?.name && "border-2 border-destructive")
								)}
							/>

							{(createState?.errors?.name || updateState?.errors?.name) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.name || updateState?.errors?.name}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="fullName">Full Name</Label>
							<Input
								id="fullName"
								name="fullName"
								placeholder="Full agent name"
								defaultValue={agent?.fullName}
								required
								aria-errormessage={
									createState?.errors?.fullName?.at(0) ||
									updateState?.errors?.fullName?.at(0)
								}
								className={cn(
									createState?.errors?.fullName ||
										(updateState?.errors?.fullName &&
											"border-2 border-destructive")
								)}
							/>

							{(createState?.errors?.fullName ||
								updateState?.errors?.fullName) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.fullName ||
										updateState?.errors?.fullName}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="normalizedName">Normalized Name</Label>

							<Input
								id="normalizedName"
								name="normalizedName"
								placeholder="Normalized agent name"
								defaultValue={agent?.normalizedName}
								required
								className={cn(
									createState?.errors?.normalizedName ||
										(updateState?.errors?.normalizedName &&
											"border-2 border-destructive")
								)}
							/>

							{(createState?.errors?.normalizedName ||
								updateState?.errors?.normalizedName) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.normalizedName ||
										updateState?.errors?.normalizedName}
								</span>
							)}
						</div>
					</div>

					<div className="grid grid-cols-1 gap-4 md:grid-cols-4">
						<div className="space-y-2">
							<Label htmlFor="rarity">Rarity</Label>
							<Select name="rarity" required defaultValue={agent?.rarity}>
								<SelectTrigger className="w-full" id="rarity">
									<SelectValue placeholder="Select rarity" />
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="S">S</SelectItem>
									<SelectItem value="A">A</SelectItem>
								</SelectContent>
							</Select>
							{(createState?.errors?.rarity || updateState?.errors?.rarity) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.rarity || updateState?.errors?.rarity}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="specialty">Specialty</Label>
							<Select name="specialty" required defaultValue={agent?.specialty}>
								<SelectTrigger className="w-full" id="specialty">
									<SelectValue placeholder="Select specialty" />
								</SelectTrigger>
								<SelectContent>
									{Object.values(Specialties).map((specialty) => (
										<SelectItem key={specialty} value={specialty}>
											{specialty}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
							{(createState?.errors?.specialty ||
								updateState?.errors?.specialty) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.specialty ||
										updateState?.errors?.specialty}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="attribute">Attribute</Label>
							<Select name="attribute" required defaultValue={agent?.attribute}>
								<SelectTrigger className="w-full" id="attribute">
									<SelectValue placeholder="Select attribute" />
								</SelectTrigger>
								<SelectContent>
									{Object.values(Attributes).map((attribute) => (
										<SelectItem key={attribute} value={attribute}>
											{attribute}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
							{(createState?.errors?.attribute ||
								updateState?.errors?.attribute) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.attribute ||
										updateState?.errors?.attribute}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="factionId">Faction</Label>
							<Select name="factionId" required defaultValue={agent?.faction}>
								<SelectTrigger className="w-full" id="factionId">
									<SelectValue placeholder="Select faction" />
								</SelectTrigger>
								<SelectContent>
									{factions.map((faction) => (
										<SelectItem
											key={`faction-select-${faction._id}`}
											value={faction._id}
										>
											{faction.name}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>
						{(createState?.errors?.factionId ||
							updateState?.errors?.factionId) && (
							<span className="mt-0 text-destructive text-xs">
								{createState?.errors?.factionId ||
									updateState?.errors?.factionId}
							</span>
						)}
					</div>

					<div className="grid gap-4 md:grid-cols-2">
						<FormImage url={agent?.imageUrl} name="imageUrl" label="Image" />
						<FormImage url={agent?.iconUrl} name="iconUrl" label="Icon" />
					</div>

					<div className="flex items-center space-x-2">
						<Checkbox
							id="isReleased"
							name="isReleased"
							defaultChecked={agent?.isReleased}
						/>
						<Label htmlFor="isReleased">Agent is released</Label>
						{(createState?.errors?.isReleased ||
							updateState?.errors?.isReleased) && (
							<span className="mt-0 text-destructive text-xs">
								{createState?.errors?.isReleased ||
									updateState?.errors?.isReleased}
							</span>
						)}
					</div>

					<div className="flex items-center space-x-2">
						<Checkbox
							id="isLimited"
							name="isLimited"
							defaultChecked={agent?.isLimited}
						/>
						<Label htmlFor="isLimited">Agent is limited edition</Label>
						{(createState?.errors?.isLimited ||
							updateState?.errors?.isLimited) && (
							<span className="mt-0 text-destructive text-xs">
								{createState?.errors?.isLimited ||
									updateState?.errors?.isLimited}
							</span>
						)}
					</div>
				</CardContent>

				<CardFooter className="flex justify-between">
					<Button type="button" variant="outline" disabled={isLoading} asChild>
						<Link href="./">Cancel</Link>
					</Button>
					<Button type="submit" disabled={isLoading}>
						{isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
						{agent ? "Update Agent" : "Create Agent"}
					</Button>
				</CardFooter>
			</Card>
		</form>
	);
};
