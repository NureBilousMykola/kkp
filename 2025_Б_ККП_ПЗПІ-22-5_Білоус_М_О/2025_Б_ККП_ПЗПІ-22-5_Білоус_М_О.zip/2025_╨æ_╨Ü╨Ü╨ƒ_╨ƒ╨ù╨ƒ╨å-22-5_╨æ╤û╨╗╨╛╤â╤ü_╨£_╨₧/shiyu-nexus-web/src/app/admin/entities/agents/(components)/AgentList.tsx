"use client";
import { useCallback, useState } from "react";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow
} from "@/components/ui/table";

import { useAgents } from "@/lib/contexts/dataProviders";
import { AgentListItem, AgentListItemSkeleton } from "./AgentsListItem";
import { adminAgentService } from "@/lib/api/services/agents/service";
import { randomHash } from "@/lib/utils/math";
import { AgentListFilters } from "./AgentListFilters";

interface AgentListProps {
	token: string;
}

export default function AgentList({ token }: AgentListProps) {
	const [searchTerm, setSearchTerm] = useState("");
	const [rarityFilter, setRarityFilter] = useState("all");
	const [specialtyFilter, setSpecialtyFilter] = useState("all");
	const [attributeFilter, setAttributeFilter] = useState("all");
	const [releasedFilter, setReleasedFilter] = useState("all");
	const [agentToDelete, setAgentToDelete] = useState<string | null>(null);

	const {
		data: agents,
		loading: agentsLoading,
		refreshData: refreshAgents
	} = useAgents();

	const filteredAgents = agents?.filter((agent) => {
		const matchesSearch =
			agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
			agent.fullName.toLowerCase().includes(searchTerm.toLowerCase());

		const matchesRarity =
			rarityFilter === "all" || agent.rarity === rarityFilter;
		const matchesSpecialty =
			specialtyFilter === "all" || agent.specialty === specialtyFilter;
		const matchesAttribute =
			attributeFilter === "all" || agent.attribute === attributeFilter;
		const matchesReleased =
			releasedFilter === "all" ||
			(releasedFilter === "released" && agent.isReleased) ||
			(releasedFilter === "unreleased" && !agent.isReleased);

		return (
			matchesSearch &&
			matchesRarity &&
			matchesSpecialty &&
			matchesAttribute &&
			matchesReleased
		);
	});

	const deleteAgent = useCallback(async () => {
		if (!agentToDelete) return;

		const response = await adminAgentService.deleteAgent(token, agentToDelete);

		if (!response.ok) {
			return { error: response.error || "Failed to delete agent" };
		}

		await refreshAgents();

		setAgentToDelete(null);

		return { success: true };
	}, [agentToDelete, token, refreshAgents]);

	return (
		<>
			<div className="flex flex-col gap-4">
				<AgentListFilters
					setSearchTerm={setSearchTerm}
					setRarityFilter={setRarityFilter}
					setSpecialtyFilter={setSpecialtyFilter}
					setAttributeFilter={setAttributeFilter}
					setReleasedFilter={setReleasedFilter}
				/>

				<div className="rounded-md border-2 border-border">
					<Table>
						<TableHeader>
							<TableRow>
								<TableHead>Agent</TableHead>
								<TableHead>Rarity</TableHead>
								<TableHead>Specialty</TableHead>
								<TableHead>Attribute</TableHead>
								<TableHead>Status</TableHead>
								<TableHead className="w-20 text-center">Actions</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{agentsLoading ? (
								new Array(30)
									.fill(0)
									.map((_, i) => (
										<AgentListItemSkeleton key={randomHash(10).toString()} />
									))
							) : !filteredAgents?.length ? (
								<TableRow>
									<TableCell colSpan={6} className="py-8 text-center">
										No agents found
									</TableCell>
								</TableRow>
							) : (
								filteredAgents.map((agent) => (
									<AgentListItem
										key={agent._id}
										agent={agent}
										onDelete={setAgentToDelete}
									/>
								))
							)}
						</TableBody>
					</Table>
				</div>
			</div>
			<Dialog
				open={!!agentToDelete}
				onOpenChange={(open) => !open && setAgentToDelete(null)}
			>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Are you sure?</DialogTitle>
						<DialogDescription>
							This action cannot be undone. This will permanently delete this
							agent from the system.
						</DialogDescription>
					</DialogHeader>
					<DialogFooter>
						<Button variant="outline" onClick={() => setAgentToDelete(null)}>
							Cancel
						</Button>
						<Button variant="destructive" onClick={deleteAgent}>
							Delete
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</>
	);
}
