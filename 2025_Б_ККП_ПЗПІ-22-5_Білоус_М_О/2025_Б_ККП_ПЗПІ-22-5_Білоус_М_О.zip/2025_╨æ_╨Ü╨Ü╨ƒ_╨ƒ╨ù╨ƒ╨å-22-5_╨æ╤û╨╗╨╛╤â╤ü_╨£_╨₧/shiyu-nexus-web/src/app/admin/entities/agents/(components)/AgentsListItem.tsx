import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { TableCell, TableRow } from "@/components/ui/table";
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger
} from "@/components/ui/tooltip";
import type { IAgent } from "@/lib/api/models/IAgent";
import { cn } from "@/lib/utils";
import {
	AttributeColors,
	RarityColors,
	SpecialityColors
} from "@/lib/utils/colors";
import { Edit, Trash2 } from "lucide-react";
import Link from "next/link";

export interface AgentListItemProps {
	agent: IAgent;
	onDelete: (id: string) => void;
}

export const AgentListItem: React.FC<AgentListItemProps> = ({
	agent,
	onDelete
}) => {
	return (
		<TableRow key={agent._id}>
			<TableCell>
				<div className="flex flex-col">
					<div className="flex items-center gap-2">
						<Avatar className="h-8 w-8">
							<AvatarImage src={agent.iconUrl} alt={agent.name} />
							<AvatarFallback>{agent.name.charAt(0)}</AvatarFallback>
						</Avatar>
						<span className="font-medium">{agent.fullName}</span>
					</div>
				</div>
			</TableCell>
			<TableCell>
				<Badge
					variant="outline"
					className={cn(RarityColors[agent.rarity].border, "text-xs")}
				>
					{agent.rarity}
				</Badge>
			</TableCell>
			<TableCell>
				<Badge
					variant="outline"
					className={cn(
						SpecialityColors[agent.specialty].border,
						"w-16 text-xs"
					)}
				>
					{agent.specialty}
				</Badge>
			</TableCell>
			<TableCell>
				<Badge
					variant="outline"
					className={cn(
						AttributeColors[agent.attribute].border,
						"w-16 text-xs"
					)}
				>
					{agent.attribute}
				</Badge>
			</TableCell>
			<TableCell>
				<Badge variant={agent.isReleased ? "secondary" : "default"}>
					{agent.isReleased ? "Released" : "Unreleased"}
				</Badge>
				{agent.isLimited && (
					<Badge variant="destructive" className="ml-2">
						Limited
					</Badge>
				)}
			</TableCell>
			<TableCell className="text-right">
				<div className="flex items-center justify-end gap-2">
					<TooltipProvider>
						<Tooltip>
							<TooltipTrigger asChild>
								<Button variant="ghost" size="icon" asChild>
									<Link href={`./agents/${agent._id}`}>
										<Edit className="h-4 w-4" />
										<span className="sr-only">Edit</span>
									</Link>
								</Button>
							</TooltipTrigger>
							<TooltipContent>Edit agent</TooltipContent>
						</Tooltip>
					</TooltipProvider>
					<TooltipProvider>
						<Tooltip>
							<TooltipTrigger asChild>
								<Button
									variant="ghost"
									size="icon"
									onClick={() => onDelete(agent._id)}
								>
									<Trash2 className="h-4 w-4" />
									<span className="sr-only">Delete</span>
								</Button>
							</TooltipTrigger>
							<TooltipContent>Delete agent</TooltipContent>
						</Tooltip>
					</TooltipProvider>
				</div>
			</TableCell>
		</TableRow>
	);
};

export const AgentListItemSkeleton = () => {
	return (
		<TableRow>
			<TableCell>
				<div className="flex flex-col">
					<div className="flex items-center gap-2">
						<Skeleton className="h-8 w-8 rounded-full" />
						<Skeleton className="h-6 w-40" />
					</div>
				</div>
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-8" />
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-16" />
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-16" />
			</TableCell>
			<TableCell className="flex gap-2">
				<Skeleton className="h-6 w-20" />
				<Skeleton className="h-6 w-20" />
			</TableCell>
			<TableCell className="text-right">
				<div className="flex items-center justify-end gap-2">
					<Skeleton className="h-8 w-8" />
					<Skeleton className="h-8 w-8" />
				</div>
			</TableCell>
		</TableRow>
	);
};
