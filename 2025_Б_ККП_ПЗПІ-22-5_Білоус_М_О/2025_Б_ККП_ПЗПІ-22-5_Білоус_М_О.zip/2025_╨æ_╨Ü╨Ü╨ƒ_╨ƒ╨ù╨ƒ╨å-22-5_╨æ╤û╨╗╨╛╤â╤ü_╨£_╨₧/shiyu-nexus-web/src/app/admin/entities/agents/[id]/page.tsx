import { verifySession } from "@/lib/utils/dal";
import { AgentForm } from "../(components)/AgentForm";
import { notFound } from "next/navigation";
import { agentService } from "@/lib/api/services/agents/service";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export const metadata = {
	title: "Edit Agent | Admin",
	description: "Edit an existing agent in the system"
};

interface EditAgentPageProps {
	params: Promise<{ id: string }>;
}

export default async function EditAgentPage({ params }: EditAgentPageProps) {
	await verifySession();

	const id = (await params).id;
	const agentResponse = await agentService.getAgent(id);

	if (!agentResponse.ok || !agentResponse.data) {
		notFound();
	}

	const agent = agentResponse.data;

	return (
		<div className="space-y-6">
			<CardHeader className="w-full px-0">
				<CardTitle>
					<h1 className="text-4xl">Edit Agent: {agent.name}</h1>
				</CardTitle>
				<CardDescription>Edit an existing agent in the system</CardDescription>
			</CardHeader>

			<AgentForm agent={agent} />
		</div>
	);
}
