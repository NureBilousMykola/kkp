"use client";

import { useActionState, useEffect, useState } from "react";
import { type Attribute, Attributes } from "@/lib/api/keys/Attribute";
import { Specialties } from "@/lib/api/keys/Specialty";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { AlertCircle, Loader2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { useEnemies } from "@/lib/contexts/dataProviders";
import { redirect } from "next/navigation";
import { Textarea } from "@/components/ui/textarea";
import type { IEnemy } from "@/lib/api/models/IEnemy";
import { createEnemy, updateEnemy } from "@/lib/actions/enemies/actions";
import { MultiSelect } from "@/components/multi-select";
import { EnemyCategories } from "@/lib/api/keys/EnemyCategory";
import { AttributeColors } from "@/lib/utils/colors";
import { FormImage } from "../../../(components)/form/formImagePreview";

interface EnemyFormProps {
	enemy?: IEnemy;
}

export const EnemyForm: React.FC<EnemyFormProps> = ({ enemy }) => {
	const [createState, _createEnemyAction, isCreating] = useActionState(
		createEnemy,
		undefined
	);

	const [updateState, _updateEnemyAction, isUpdating] = useActionState(
		updateEnemy,
		undefined
	);

	// Since multi-select doesnt use the native select compoenents, track the selected values manually
	const [weaknessAttributes, setWeaknessAttributes] = useState<Attribute[]>(
		enemy?.weaknessAttributes || []
	);
	const [resistanceAttributes, setResistanceAttributes] = useState<Attribute[]>(
		enemy?.resistanceAttributes || []
	);

	const { refreshData } = useEnemies();

	const isLoading = isCreating || isUpdating;

	useEffect(() => {
		if (createState?.success || updateState?.success) {
			refreshData();
			redirect("./");
		}
	}, [createState, updateState, refreshData]);

	const [imageUrl, setImageUrl] = useState(enemy?.imageUrl || "");

	const updateEnemyAction = async (data: FormData) => {
		for (const attribute of weaknessAttributes) {
			data.append("weaknessAttributes", attribute);
		}
		for (const attribute of resistanceAttributes) {
			data.append("resistanceAttributes", attribute);
		}
		return _updateEnemyAction(data);
	};

	const createEnemyAction = async (data: FormData) => {
		for (const attribute of weaknessAttributes) {
			data.append("weaknessAttributes", attribute);
		}
		for (const attribute of resistanceAttributes) {
			data.append("resistanceAttributes", attribute);
		}
		return _createEnemyAction(data);
	};

	return (
		<form action={enemy ? updateEnemyAction : createEnemyAction}>
			<Card>
				<CardContent className="space-y-4">
					{(createState?.message || updateState?.message) &&
						(!createState?.success || !updateState?.success) && (
							<Alert variant="destructive">
								<AlertCircle className="h-4 w-4" />
								<AlertTitle>Api Error:</AlertTitle>
								<AlertDescription>
									{createState?.message || updateState?.message}
								</AlertDescription>
							</Alert>
						)}

					{enemy && (
						<div className="space-y-2 text-muted-foreground">
							<Label htmlFor="id">Enemy ID</Label>
							<Input
								readOnly
								id="id"
								name="id"
								defaultValue={enemy?._id}
								required
							/>
							{updateState?.errors?.id && (
								<span className="mt-0 text-destructive text-xs">
									{updateState?.errors?.id}
								</span>
							)}
						</div>
					)}

					<div className="grid grid-cols-1 gap-4 md:grid-cols-2">
						<div className="space-y-2">
							<Label htmlFor="name">Name</Label>
							<Input
								id="name"
								name="name"
								placeholder="Agent name"
								defaultValue={enemy?.name}
								required
								aria-errormessage={
									createState?.errors?.name?.at(0) ||
									updateState?.errors?.name?.at(0)
								}
								className={cn(
									createState?.errors?.name ||
										(updateState?.errors?.name && "border-2 border-destructive")
								)}
							/>

							{(createState?.errors?.name || updateState?.errors?.name) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.name || updateState?.errors?.name}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="normalizedName">Normalized Name</Label>

							<Input
								id="normalizedName"
								name="normalizedName"
								placeholder="Normalized agent name"
								defaultValue={enemy?.normalizedName}
								required
								className={cn(
									createState?.errors?.normalizedName ||
										(updateState?.errors?.normalizedName &&
											"border-2 border-destructive")
								)}
							/>

							{(createState?.errors?.normalizedName ||
								updateState?.errors?.normalizedName) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.normalizedName ||
										updateState?.errors?.normalizedName}
								</span>
							)}
						</div>
					</div>

					<div className="grid grid-cols-1 gap-4 md:grid-cols-3">
						<div className="space-y-2">
							<Label htmlFor="category">Category</Label>
							<Select name="category" required defaultValue={enemy?.category}>
								<SelectTrigger className="w-full" id="category">
									<SelectValue placeholder="Select category" />
								</SelectTrigger>
								<SelectContent>
									{Object.values(EnemyCategories).map((category) => (
										<SelectItem key={category} value={category}>
											{category}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
							{(createState?.errors?.category ||
								updateState?.errors?.category) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.category ||
										updateState?.errors?.category}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="resistanceAttributes">
								Resistance Attributes
							</Label>
							<MultiSelect
								name="resistanceAttributes"
								defaultValue={enemy?.resistanceAttributes}
								onValueChange={(value) =>
									setResistanceAttributes(value as Attribute[])
								}
								options={Object.values(Attributes).map((attribute) => ({
									value: attribute,
									label: attribute,
									badgeClass: cn(AttributeColors[attribute]?.border),
									badgeType: "outline"
								}))}
							>
								<SelectTrigger id="resistanceAttributes">
									<SelectValue placeholder="Select resistance attributes" />
								</SelectTrigger>
								<SelectContent>
									{Object.values(Specialties).map((specialty) => (
										<SelectItem key={specialty} value={specialty}>
											{specialty}
										</SelectItem>
									))}
								</SelectContent>
							</MultiSelect>
							{(createState?.errors?.resistanceAttributes ||
								updateState?.errors?.resistanceAttributes) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.resistanceAttributes ||
										updateState?.errors?.resistanceAttributes}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="weaknessAttributes">Weakness Attributes</Label>
							<MultiSelect
								name="weaknessAttributes"
								defaultValue={enemy?.weaknessAttributes}
								onValueChange={(attributes) =>
									setWeaknessAttributes(attributes as Attribute[])
								}
								options={Object.values(Attributes).map((attribute) => ({
									value: attribute,
									label: attribute,
									badgeClass: cn(AttributeColors[attribute]?.border),
									badgeType: "outline"
								}))}
							>
								<SelectTrigger id="weaknessAttributes">
									<SelectValue placeholder="Select weakness attributes" />
								</SelectTrigger>
								<SelectContent>
									{Object.values(Attributes).map((attribute) => (
										<SelectItem key={attribute} value={attribute}>
											{attribute}
										</SelectItem>
									))}
								</SelectContent>
							</MultiSelect>
							{(createState?.errors?.weaknessAttributes ||
								updateState?.errors?.weaknessAttributes) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.weaknessAttributes ||
										updateState?.errors?.weaknessAttributes}
								</span>
							)}
						</div>
					</div>

					<div className="flex gap-4">
						<div className="w-full space-y-2">
							<Label htmlFor="description">Description</Label>
							<Textarea
								id="description"
								name="description"
								placeholder="Description"
								defaultValue={enemy?.description}
								className="resize-none"
							/>
							{(createState?.errors?.description ||
								updateState?.errors?.description) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.description ||
										updateState?.errors?.description}
								</span>
							)}
						</div>
					</div>

					<FormImage
						name="imageUrl"
						label="Image"
						url={enemy?.imageUrl}
						errors={
							createState?.errors?.imageUrl || updateState?.errors?.imageUrl
						}
					/>
				</CardContent>

				<CardFooter className="flex justify-between">
					<Button type="button" variant="outline" disabled={isLoading} asChild>
						<Link href="./">Cancel</Link>
					</Button>
					<Button type="submit" disabled={isLoading}>
						{isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
						{enemy ? "Update Enemy" : "Create Enemy"}
					</Button>
				</CardFooter>
			</Card>
		</form>
	);
};
