"use client";

import { useCallback, useState } from "react";
import { adminEnemyService } from "@/lib/api/services/enemies/service";
import { EnemyListFilters } from "./EnemyListFilters";
import {
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow
} from "@/components/ui/table";
import { Table } from "@/components/ui/table";
import { randomHash } from "@/lib/utils/math";
import { EnemyListItemSkeleton, EnemysListItem } from "./EnemysListItem";
import { useEnemies } from "@/lib/contexts/dataProviders";
import {
	Dialog,
	DialogDescription,
	DialogFooter,
	DialogTitle
} from "@/components/ui/dialog";
import { DialogContent } from "@/components/ui/dialog";
import { DialogHeader } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface EnemyListProps {
	token: string;
}

export default function EnemyList({ token }: EnemyListProps) {
	const [searchTerm, setSearchTerm] = useState("");
	const [categoryFilter, setCategoryFilter] = useState("all");
	const [weaknessAttributeFilter, setWeaknessAttributeFilter] = useState("all");
	const [resistanceAttributeFilter, setResistanceAttributeFilter] =
		useState("all");
	const [enemyToDelete, setEnemyToDelete] = useState<string | null>(null);

	const {
		data: enemies,
		loading: enemiesLoading,
		refreshData: refreshEnemies
	} = useEnemies();

	const filteredEnemies = enemies?.filter((enemy) => {
		const matchesSearch =
			enemy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
			enemy.normalizedName.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesCategory =
			categoryFilter === "all" || enemy.category === categoryFilter;

		const matchesWeaknessAttribute =
			weaknessAttributeFilter === "all" ||
			(enemy.weaknessAttributes as string[]).includes(weaknessAttributeFilter);

		const matchesResistanceAttribute =
			resistanceAttributeFilter === "all" ||
			(enemy.resistanceAttributes as string[]).includes(
				resistanceAttributeFilter
			);

		return (
			matchesSearch &&
			matchesCategory &&
			matchesWeaknessAttribute &&
			matchesResistanceAttribute
		);
	});

	const deleteEnemy = useCallback(async () => {
		if (!enemyToDelete) return;

		const response = await adminEnemyService.deleteEnemy(token, enemyToDelete);

		if (!response.ok) {
			return { error: response.error || "Failed to delete enemy" };
		}

		await refreshEnemies();

		setEnemyToDelete(null);

		return { success: true };
	}, [enemyToDelete, token, refreshEnemies]);

	return (
		<>
			<div className="flex flex-col gap-4">
				<EnemyListFilters
					setSearchTerm={setSearchTerm}
					setCategoryFilter={setCategoryFilter}
					setWeaknessAttributeFilter={setWeaknessAttributeFilter}
					setResistanceAttributeFilter={setResistanceAttributeFilter}
				/>

				<div className="rounded-md border-2 border-border">
					<Table>
						<TableHeader>
							<TableRow>
								<TableHead>Enemy</TableHead>
								<TableHead>Category</TableHead>
								<TableHead>Weakness Attribute</TableHead>
								<TableHead>Resistance Attribute</TableHead>
								<TableHead className="w-20 text-center">Actions</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{enemiesLoading ? (
								new Array(30)
									.fill(0)
									.map((_, i) => (
										<EnemyListItemSkeleton key={randomHash(10).toString()} />
									))
							) : !filteredEnemies?.length ? (
								<TableRow>
									<TableCell colSpan={5} className="py-8 text-center">
										No enemies found
									</TableCell>
								</TableRow>
							) : (
								filteredEnemies.map((enemy) => (
									<EnemysListItem
										key={enemy._id}
										enemy={enemy}
										onDelete={setEnemyToDelete}
									/>
								))
							)}
						</TableBody>
					</Table>
				</div>
			</div>
			<Dialog
				open={!!enemyToDelete}
				onOpenChange={(open) => !open && setEnemyToDelete(null)}
			>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Are you sure?</DialogTitle>
						<DialogDescription>This action cannot be undone.</DialogDescription>
					</DialogHeader>
					<DialogFooter>
						<Button variant="outline" onClick={() => setEnemyToDelete(null)}>
							Cancel
						</Button>
						<Button variant="destructive" onClick={deleteEnemy}>
							Delete
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</>
	);
}
