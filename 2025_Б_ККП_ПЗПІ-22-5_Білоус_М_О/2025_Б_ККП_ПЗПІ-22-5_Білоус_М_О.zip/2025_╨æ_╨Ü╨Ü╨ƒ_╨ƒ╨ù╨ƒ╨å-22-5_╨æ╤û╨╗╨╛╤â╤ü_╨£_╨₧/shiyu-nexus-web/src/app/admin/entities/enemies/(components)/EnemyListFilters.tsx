import Search from "@/components/icons/search";
import { Input } from "@/components/ui/input";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { Attributes } from "@/lib/api/keys/Attribute";
import { EnemyCategories } from "@/lib/api/keys/EnemyCategory";

interface EnemyListFiltersProps {
	setSearchTerm: (searchTerm: string) => void;
	setCategoryFilter: (categoryFilter: string) => void;
	setWeaknessAttributeFilter: (weaknessAttributeFilter: string) => void;
	setResistanceAttributeFilter: (resistanceAttributeFilter: string) => void;
}

export const EnemyListFilters: React.FC<EnemyListFiltersProps> = ({
	setSearchTerm,
	setCategoryFilter,
	setWeaknessAttributeFilter,
	setResistanceAttributeFilter
}) => {
	return (
		<div className="flex flex-wrap justify-between gap-4">
			<div className="relative w-full md:w-64 md:flex-1">
				<Search className="absolute top-2.5 left-2 h-4 w-4 text-muted-foreground" />
				<Input
					placeholder="Search enemies..."
					className="pl-8"
					onChange={(e) => setSearchTerm(e.target.value)}
				/>
			</div>
			<div className="flex flex-wrap gap-2">
				<Select onValueChange={setCategoryFilter}>
					<SelectTrigger className="w-full md:w-48">
						<SelectValue placeholder="Select category" />
					</SelectTrigger>
					<SelectContent>
						<SelectItem value="all">All Categories</SelectItem>
						{Object.values(EnemyCategories).map((category) => (
							<SelectItem key={category} value={category}>
								{category}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
				<Select onValueChange={setWeaknessAttributeFilter}>
					<SelectTrigger className="w-full md:w-48">
						<SelectValue placeholder="Select weakness" />
					</SelectTrigger>
					<SelectContent>
						<SelectItem value="all">All Weakness Attributes</SelectItem>
						{Object.values(Attributes).map((attribute) => (
							<SelectItem key={attribute} value={attribute}>
								{attribute}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
				<Select onValueChange={setResistanceAttributeFilter}>
					<SelectTrigger className="w-full md:w-48">
						<SelectValue placeholder="Select resistance" />
					</SelectTrigger>
					<SelectContent>
						<SelectItem value="all">All Resistance Attributes</SelectItem>
						{Object.values(Attributes).map((attribute) => (
							<SelectItem key={attribute} value={attribute}>
								{attribute}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
			</div>
		</div>
	);
};
