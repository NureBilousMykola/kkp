import { Badge } from "@/components/ui/badge";
import { TableCell } from "@/components/ui/table";
import { TableRow } from "@/components/ui/table";
import type { IEnemy } from "@/lib/api/models/IEnemy";
import type { Attribute } from "@/lib/api/keys/Attribute";
import { AttributeColors } from "@/lib/utils/colors";
import {
	Tooltip,
	TooltipContent,
	TooltipTrigger
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Edit, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export interface EnemysListItemProps {
	enemy: IEnemy;
	onDelete: (id: string) => void;
}

export const EnemysListItem: React.FC<EnemysListItemProps> = ({
	enemy,
	onDelete
}) => {
	return (
		<TableRow key={enemy._id}>
			<TableCell>
				<div className="flex flex-col">
					<div className="flex items-center gap-2">
						<Avatar className="h-8 w-8">
							<AvatarImage src={enemy.imageUrl} alt={enemy.name} />
							<AvatarFallback>{enemy.name.charAt(0)}</AvatarFallback>
						</Avatar>
						<span className="font-medium">{enemy.name}</span>
					</div>
				</div>
			</TableCell>
			<TableCell>
				<Badge variant="secondary">{enemy.category}</Badge>
			</TableCell>
			<TableCell>
				<div className="flex flex-wrap gap-1 text-xs">
					{enemy.weaknessAttributes.length > 0
						? enemy.weaknessAttributes.map((attr, index) => (
								<Badge
									variant="outline"
									key={attr}
									className={AttributeColors[attr as Attribute]?.border}
								>
									{attr}
								</Badge>
							))
						: "N/A"}
				</div>
			</TableCell>
			<TableCell>
				<div className="flex flex-wrap gap-1 text-xs">
					{enemy.resistanceAttributes.length > 0
						? enemy.resistanceAttributes.map((attr) => (
								<Badge
									variant="outline"
									key={`resistance-${attr}`}
									className={AttributeColors[attr as Attribute]?.border}
								>
									{attr}
								</Badge>
							))
						: "N/A"}
				</div>
			</TableCell>
			<TableCell className="text-right">
				<div className="flex items-center justify-end gap-2">
					<Tooltip>
						<TooltipTrigger asChild>
							<Button variant="ghost" size="icon" asChild>
								<Link href={`./enemies/${enemy._id}`}>
									<Edit className="h-4 w-4" />
									<span className="sr-only">Edit</span>
								</Link>
							</Button>
						</TooltipTrigger>
						<TooltipContent>Edit</TooltipContent>
					</Tooltip>
					<Tooltip>
						<TooltipTrigger asChild>
							<Button
								variant="ghost"
								size="icon"
								onClick={() => onDelete(enemy._id)}
							>
								<Trash2 className="h-4 w-4" />
								<span className="sr-only">Delete</span>
							</Button>
						</TooltipTrigger>
						<TooltipContent>Delete</TooltipContent>
					</Tooltip>
				</div>
			</TableCell>
		</TableRow>
	);
};

export const EnemyListItemSkeleton = () => {
	return (
		<TableRow>
			<TableCell>
				<div className="flex flex-col">
					<div className="flex items-center gap-2">
						<Skeleton className="h-8 w-8 rounded-full" />
						<Skeleton className="h-6 w-40" />
					</div>
				</div>
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-8" />
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-16" />
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-16" />
			</TableCell>
			<TableCell className="text-right">
				<div className="flex items-center justify-end gap-2">
					<Skeleton className="h-8 w-8" />
					<Skeleton className="h-8 w-8" />
				</div>
			</TableCell>
		</TableRow>
	);
};
