import { verifySession } from "@/lib/utils/dal";
import { notFound } from "next/navigation";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { EnemyForm } from "../(components)/EnemyForm";
import { enemyService } from "@/lib/api/services/enemies/service";

export const metadata = {
	title: "Edit Agent | Admin",
	description: "Edit an existing agent in the system"
};

interface EditEnemyPageProps {
	params: Promise<{ id: string }>;
}

export default async function EditEnemyPage({ params }: EditEnemyPageProps) {
	await verifySession();

	const id = (await params).id;

	const enemyResponse = await enemyService.getEnemy(id);

	if (!enemyResponse.ok || !enemyResponse.data) {
		notFound();
	}

	const enemy = enemyResponse.data;

	return (
		<div className="space-y-6">
			<CardHeader className="w-full px-0">
				<CardTitle>
					<h1 className="text-4xl">Edit Enemy: {enemy.name}</h1>
				</CardTitle>
				<CardDescription>Edit an existing enemy in the system</CardDescription>
			</CardHeader>

			<EnemyForm enemy={enemy} />
		</div>
	);
}
