import { verifySession } from "@/lib/utils/dal";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { EnemyForm } from "../(components)/EnemyForm";

export const metadata = {
	title: "Create Agent | Admin",
	description: "Create a new agent in the system"
};

export default async function CreateAgentPage() {
	await verifySession();

	return (
		<div className="space-y-6">
			<CardHeader className="w-full px-0">
				<CardTitle>
					<h1 className="text-4xl">Create an enemy</h1>
				</CardTitle>
				<CardDescription>Create a new enemy in the system</CardDescription>
			</CardHeader>

			<EnemyForm />
		</div>
	);
}
