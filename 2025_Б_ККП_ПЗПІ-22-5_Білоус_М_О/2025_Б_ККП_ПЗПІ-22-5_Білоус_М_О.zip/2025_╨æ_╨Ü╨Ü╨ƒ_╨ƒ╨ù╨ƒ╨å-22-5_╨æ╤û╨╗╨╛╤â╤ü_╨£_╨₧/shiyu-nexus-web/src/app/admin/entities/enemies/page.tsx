import { verifySession } from "@/lib/utils/dal";
import { CardHeader } from "@/components/ui/card";
import { CardTitle } from "@/components/ui/card";
import { CardDescription } from "@/components/ui/card";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import EnemyList from "./(components)/EnemyList";
import Link from "next/link";

export const metadata = {
	title: "Enemy Management | Admin",
	description: "Manage enemies in the system"
};

export default async function AdminEnemiesPage() {
	const session = await verifySession();

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<CardHeader className="w-full px-0">
					<CardTitle>
						<h1 className="text-4xl">Enemies</h1>
					</CardTitle>
					<CardDescription>
						View and manage all enemies in the system
					</CardDescription>
				</CardHeader>

				<Button asChild>
					<Link href="./enemies/create">
						<Plus className="h-4 w-4" />
						Create Enemy
					</Link>
				</Button>
			</div>

			<EnemyList token={session.token} />
		</div>
	);
}
