"use client";

import { useActionState, useEffect } from "react";
import { createEngine, updateEngine } from "@/lib/actions/engines/actions";
import { Specialties } from "@/lib/api/keys/Specialty";
import type { IEngine } from "@/lib/api/models/IEngine";
import type { CreateEngineFormState, UpdateEngineState } from "@/lib/actions/engines/types";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { useEngines } from "@/lib/contexts/dataProviders";
import { redirect } from "next/navigation";
import { FormImage } from "../../../(components)/form/formImagePreview";

interface EngineFormProps {
	engine?: IEngine;
}

export const EngineForm: React.FC<EngineFormProps> = ({ engine }) => {
	const [createState, createEngineAction, isCreating] = useActionState(createEngine, undefined);
	const [updateState, updateEngineAction, isUpdating] = useActionState(updateEngine, undefined);

	const { refreshData } = useEngines();

	const isLoading = isCreating || isUpdating;

	useEffect(() => {
		if (createState?.success || updateState?.success) {
			refreshData();
			redirect("./");
		}
	}, [createState, updateState, refreshData]);

	return (
		<form action={engine ? updateEngineAction : createEngineAction}>
			{engine && <input type="hidden" name="id" value={engine._id} />}

			<Card>
				<CardContent className="space-y-4 pt-6">
					<div className="grid grid-cols-1 gap-4 md:grid-cols-3">
						<div className="space-y-2">
							<Label htmlFor="name">Name</Label>
							<Input
								id="name"
								name="name"
								placeholder="Engine name"
								defaultValue={engine?.name}
								required
								aria-errormessage={
									createState?.errors?.name?.at(0) ||
									updateState?.errors?.name?.at(0)
								}
								className={cn(
									createState?.errors?.name ||
										(updateState?.errors?.name && "border-2 border-destructive")
								)}
							/>

							{(createState?.errors?.name || updateState?.errors?.name) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.name || updateState?.errors?.name}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="rarity">Rarity</Label>
							<Select name="rarity" required defaultValue={engine?.rarity}>
								<SelectTrigger className="w-full" id="rarity">
									<SelectValue placeholder="Select rarity" />
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="S">S</SelectItem>
									<SelectItem value="A">A</SelectItem>
								</SelectContent>
							</Select>
							{(createState?.errors?.rarity ||
								updateState?.errors?.rarity) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.rarity ||
										updateState?.errors?.rarity}
								</span>
							)}
						</div>

						<div className="space-y-2">
							<Label htmlFor="specialty">Specialty</Label>
							<Select name="specialty" required defaultValue={engine?.specialty}>
								<SelectTrigger className="w-full" id="specialty">
									<SelectValue placeholder="Select specialty" />
								</SelectTrigger>
								<SelectContent>
									{Object.values(Specialties).map((specialty) => (
										<SelectItem
											key={`specialty-select-${specialty}`}
											value={specialty}
										>
											{specialty}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
							{(createState?.errors?.specialty ||
								updateState?.errors?.specialty) && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.specialty ||
										updateState?.errors?.specialty}
								</span>
							)}
						</div>
					</div>

					<div>
						<FormImage url={engine?.imageUrl} name="imageUrl" label="Image" />
					</div>
				</CardContent>

				<CardFooter className="flex justify-between">
					<Button type="button" variant="outline" disabled={isLoading} asChild>
						<Link href="./">Cancel</Link>
					</Button>
					<Button type="submit" disabled={isLoading}>
						{isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
						{engine ? "Update Engine" : "Create Engine"}
					</Button>
				</CardFooter>
			</Card>
		</form>
	);
};
