"use client";
import { useCallback, useState } from "react";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow
} from "@/components/ui/table";

import { useEngines } from "@/lib/contexts/dataProviders";
import { EngineListItem, EngineListItemSkeleton } from "./EngineListItem";
import { adminEngineService } from "@/lib/api/services/engines/service";
import { randomHash } from "@/lib/utils/math";
import { EngineListFilters } from "./EngineListFilters";

interface EngineListProps {
	token: string;
}

export default function EngineList({ token }: EngineListProps) {
	const [searchTerm, setSearchTerm] = useState("");
	const [rarityFilter, setRarityFilter] = useState("all");
	const [specialtyFilter, setSpecialtyFilter] = useState("all");
	const [engineToDelete, setEngineToDelete] = useState<string | null>(null);

	const {
		data: engines,
		loading: enginesLoading,
		refreshData: refreshEngines
	} = useEngines();

	const filteredEngines = engines?.filter((engine) => {
		const matchesSearch =
			engine.name.toLowerCase().includes(searchTerm.toLowerCase());

		const matchesRarity =
			rarityFilter === "all" || engine.rarity === rarityFilter;
		const matchesSpecialty =
			specialtyFilter === "all" || engine.specialty === specialtyFilter;

		return matchesSearch && matchesRarity && matchesSpecialty;
	});

	const deleteEngine = useCallback(async () => {
		if (!engineToDelete) return;

		const response = await adminEngineService.deleteEngine(token, engineToDelete);

		if (!response.ok) {
			return { error: response.error || "Failed to delete engine" };
		}

		await refreshEngines();

		setEngineToDelete(null);

		return { success: true };
	}, [engineToDelete, token, refreshEngines]);

	return (
		<>
			<div className="flex flex-col gap-4">
				<EngineListFilters
					setSearchTerm={setSearchTerm}
					setRarityFilter={setRarityFilter}
					setSpecialtyFilter={setSpecialtyFilter}
				/>

				<div className="rounded-md border-2 border-border">
					<Table>
						<TableHeader>
							<TableRow>
								<TableHead>Engine</TableHead>
								<TableHead>Rarity</TableHead>
								<TableHead>Specialty</TableHead>
								<TableHead className="w-20 text-center">Actions</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{enginesLoading ? (
								new Array(30)
									.fill(0)
									.map(() => (
										<EngineListItemSkeleton key={randomHash(10).toString()} />
									))
							) : !filteredEngines?.length ? (
								<TableRow>
									<TableCell colSpan={4} className="py-8 text-center">
										No engines found
									</TableCell>
								</TableRow>
							) : (
								filteredEngines.map((engine) => (
									<EngineListItem
										key={engine._id}
										engine={engine}
										onDelete={setEngineToDelete}
									/>
								))
							)}
						</TableBody>
					</Table>
				</div>
			</div>

			<Dialog
				open={!!engineToDelete}
				onOpenChange={(open) => !open && setEngineToDelete(null)}
			>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Are you sure?</DialogTitle>
						<DialogDescription>
							This action cannot be undone. This will permanently delete this
							engine from the system.
						</DialogDescription>
					</DialogHeader>
					<DialogFooter>
						<Button variant="outline" onClick={() => setEngineToDelete(null)}>
							Cancel
						</Button>
						<Button variant="destructive" onClick={deleteEngine}>
							Delete
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</>
	);
}
