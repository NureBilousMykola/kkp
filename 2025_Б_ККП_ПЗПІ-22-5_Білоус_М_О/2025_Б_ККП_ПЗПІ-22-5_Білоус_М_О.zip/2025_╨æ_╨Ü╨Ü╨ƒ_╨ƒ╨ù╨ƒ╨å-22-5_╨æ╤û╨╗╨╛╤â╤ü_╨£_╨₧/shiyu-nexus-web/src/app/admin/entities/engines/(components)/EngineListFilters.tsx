import Search from "@/components/icons/search";
import { Input } from "@/components/ui/input";
import { Specialties } from "@/lib/api/keys/Specialty";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";

interface EngineListFiltersProps {
	setSearchTerm: (searchTerm: string) => void;
	setRarityFilter: (rarityFilter: string) => void;
	setSpecialtyFilter: (specialtyFilter: string) => void;
}

export const EngineListFilters: React.FC<EngineListFiltersProps> = ({
	setSearchTerm,
	setRarityFilter,
	setSpecialtyFilter
}) => {
	return (
		<div className="flex flex-wrap justify-between gap-4">
			<div className="relative w-full md:w-64 md:flex-1">
				<Search className="absolute top-2.5 left-2 h-4 w-4 text-muted-foreground" />
				<Input
					placeholder="Search engines..."
					className="pl-8"
					onChange={(e) => setSearchTerm(e.target.value)}
				/>
			</div>
			<div className="flex flex-wrap gap-2">
				<Select onValueChange={setRarityFilter}>
					<SelectTrigger className="w-full md:w-32">
						<SelectValue placeholder="Rarity" />
					</SelectTrigger>
					<SelectContent>
						<SelectItem value="all">All Rarities</SelectItem>
						<SelectItem value="S">S</SelectItem>
						<SelectItem value="A">A</SelectItem>
					</SelectContent>
				</Select>
				<Select onValueChange={setSpecialtyFilter}>
					<SelectTrigger className="w-full md:w-32">
						<SelectValue placeholder="Specialty" />
					</SelectTrigger>
					<SelectContent>
						<SelectItem value="all">All Specialties</SelectItem>
						{Object.values(Specialties).map((specialty) => (
							<SelectItem key={specialty} value={specialty}>
								{specialty}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
			</div>
		</div>
	);
};
