import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { TableCell, TableRow } from "@/components/ui/table";
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger
} from "@/components/ui/tooltip";
import type { IEngine } from "@/lib/api/models/IEngine";
import { cn } from "@/lib/utils";
import { RarityColors, SpecialityColors } from "@/lib/utils/colors";
import { Edit, Trash2 } from "lucide-react";
import Link from "next/link";

export interface EngineListItemProps {
	engine: IEngine;
	onDelete: (id: string) => void;
}

export const EngineListItem: React.FC<EngineListItemProps> = ({
	engine,
	onDelete
}) => {
	return (
		<TableRow key={engine._id}>
			<TableCell>
				<div className="flex flex-col">
					<div className="flex items-center gap-2">
						<Avatar className="h-8 w-8">
							<AvatarImage src={engine.imageUrl} alt={engine.name} />
							<AvatarFallback>{engine.name.charAt(0)}</AvatarFallback>
						</Avatar>
						<span className="font-medium">{engine.name}</span>
					</div>
				</div>
			</TableCell>
			<TableCell>
				<Badge
					variant="outline"
					className={cn(RarityColors[engine.rarity].border, "text-xs")}
				>
					{engine.rarity}
				</Badge>
			</TableCell>
			<TableCell>
				<Badge
					variant="outline"
					className={cn(
						SpecialityColors[engine.specialty].border,
						"w-16 text-xs"
					)}
				>
					{engine.specialty}
				</Badge>
			</TableCell>
			<TableCell className="text-right">
				<div className="flex items-center justify-end gap-2">
					<TooltipProvider>
						<Tooltip>
							<TooltipTrigger asChild>
								<Button variant="ghost" size="icon" asChild>
									<Link href={`./engines/${engine._id}`}>
										<Edit className="h-4 w-4" />
										<span className="sr-only">Edit</span>
									</Link>
								</Button>
							</TooltipTrigger>
							<TooltipContent>Edit engine</TooltipContent>
						</Tooltip>
					</TooltipProvider>
					<TooltipProvider>
						<Tooltip>
							<TooltipTrigger asChild>
								<Button
									variant="ghost"
									size="icon"
									onClick={() => onDelete(engine._id)}
								>
									<Trash2 className="h-4 w-4" />
									<span className="sr-only">Delete</span>
								</Button>
							</TooltipTrigger>
							<TooltipContent>Delete engine</TooltipContent>
						</Tooltip>
					</TooltipProvider>
				</div>
			</TableCell>
		</TableRow>
	);
};

export const EngineListItemSkeleton: React.FC = () => {
	return (
		<TableRow>
			<TableCell>
				<div className="flex items-center gap-2">
					<Skeleton className="h-8 w-8 rounded-full" />
					<Skeleton className="h-4 w-32" />
				</div>
			</TableCell>
			<TableCell>
				<Skeleton className="h-4 w-16" />
			</TableCell>
			<TableCell>
				<Skeleton className="h-4 w-16" />
			</TableCell>
			<TableCell>
				<div className="flex items-center justify-end gap-2">
					<Skeleton className="h-8 w-8" />
					<Skeleton className="h-8 w-8" />
				</div>
			</TableCell>
		</TableRow>
	);
};
