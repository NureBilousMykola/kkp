import { verifySession } from "@/lib/utils/dal";
import { EngineForm } from "../(components)/EngineForm";
import { notFound } from "next/navigation";
import { engineService } from "@/lib/api/services/engines/service";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export const metadata = {
	title: "Edit Engine | Admin",
	description: "Edit an existing engine in the system"
};

interface EditEnginePageProps {
	params: Promise<{ id: string }>;
}

export default async function EditEnginePage({ params }: EditEnginePageProps) {
	await verifySession();

	const id = (await params).id;
	const engineResponse = await engineService.getEngine(id);

	if (!engineResponse.ok || !engineResponse.data) {
		notFound();
	}

	const engine = engineResponse.data;

	return (
		<div className="space-y-6">
			<CardHeader className="w-full px-0">
				<CardTitle>
					<h1 className="text-4xl">Edit Engine: {engine.name}</h1>
				</CardTitle>
				<CardDescription>Edit an existing engine in the system</CardDescription>
			</CardHeader>

			<EngineForm engine={engine} />
		</div>
	);
}
