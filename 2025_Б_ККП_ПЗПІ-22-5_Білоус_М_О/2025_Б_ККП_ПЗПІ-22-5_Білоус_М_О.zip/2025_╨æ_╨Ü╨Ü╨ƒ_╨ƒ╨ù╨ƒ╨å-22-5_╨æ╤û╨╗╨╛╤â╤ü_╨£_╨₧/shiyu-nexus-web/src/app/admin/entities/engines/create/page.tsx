import { verifySession } from "@/lib/utils/dal";
import { EngineForm } from "../(components)/EngineForm";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export const metadata = {
	title: "Create Engine | Admin",
	description: "Create a new engine in the system"
};

export default async function CreateEnginePage() {
	await verifySession();

	return (
		<div className="space-y-6">
			<CardHeader className="w-full px-0">
				<CardTitle>
					<h1 className="text-4xl">Create an engine</h1>
				</CardTitle>
				<CardDescription>Create a new engine in the system</CardDescription>
			</CardHeader>

			<EngineForm />
		</div>
	);
}
