import EngineList from "@/app/admin/entities/engines/(components)/EngineList";
import { Button } from "@/components/ui/button";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { verifySession } from "@/lib/utils/dal";
import { Settings } from "lucide-react";
import Link from "next/link";

export const metadata = {
	title: "Engine Management | Admin",
	description: "Manage engines in the system"
};

export default async function AdminEnginesPage() {
	const session = await verifySession();

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<CardHeader className="w-full px-0">
					<CardTitle>
						<h1 className="text-4xl">Engines</h1>
					</CardTitle>
					<CardDescription>
						View and manage all engines in the system
					</CardDescription>
				</CardHeader>

				<Button asChild>
					<Link href="./engines/create">
						<Settings className="h-4 w-4" />
						Create Engine
					</Link>
				</Button>
			</div>

			<EngineList token={session.token} />
		</div>
	);
}
