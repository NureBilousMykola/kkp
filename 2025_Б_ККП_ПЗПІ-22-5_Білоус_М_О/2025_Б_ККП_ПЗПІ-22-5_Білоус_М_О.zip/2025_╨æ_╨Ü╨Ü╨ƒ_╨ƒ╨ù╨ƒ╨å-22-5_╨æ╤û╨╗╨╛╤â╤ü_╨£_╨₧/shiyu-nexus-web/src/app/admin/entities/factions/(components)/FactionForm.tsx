"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createFaction, updateFaction } from "@/lib/actions/factions";
import type { IFaction } from "@/lib/api/models/IFaction";

import { Button } from "@/components/ui/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardFooter,
	CardHeader,
	CardTitle
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, Loader2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface FactionFormProps {
	token: string;
	faction?: IFaction;
	isEdit?: boolean;
}

type FactionResult =
	| { error: string; faction?: undefined }
	| { faction: IFaction | null; error?: undefined };

export default function FactionForm({
	token,
	faction,
	isEdit = false
}: FactionFormProps) {
	const router = useRouter();
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [error, setError] = useState<string | null>(null);

	const [formState, setFormState] = useState({
		name: faction?.name || "",
		iconUrl: faction?.iconUrl || ""
	});

	const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault();
		setIsSubmitting(true);
		setError(null);

		try {
			const payload = {
				name: formState.name,
				iconUrl: formState.iconUrl || undefined
			};

			let result: FactionResult;
			if (isEdit && faction) {
				result = await updateFaction({
					token,
					factionId: faction._id,
					faction: payload
				});
			} else {
				result = await createFaction({
					token,
					faction: payload
				});
			}

			if (result.error) {
				setError(result.error);
			} else {
				router.push("/admin/factions");
			}
		} catch (err) {
			setError("An unexpected error occurred");
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<form onSubmit={handleSubmit}>
			<Card>
				<CardHeader>
					<CardTitle>
						{isEdit ? "Edit Faction" : "Create New Faction"}
					</CardTitle>
					<CardDescription>
						{isEdit
							? "Update faction information in the system"
							: "Add a new faction to the system"}
					</CardDescription>
				</CardHeader>

				<CardContent className="space-y-4">
					{error && (
						<Alert variant="destructive">
							<AlertCircle className="h-4 w-4" />
							<AlertTitle>Error</AlertTitle>
							<AlertDescription>{error}</AlertDescription>
						</Alert>
					)}

					<div className="grid grid-cols-1 gap-4">
						<div className="space-y-2">
							<Label htmlFor="name">Name</Label>
							<Input
								id="name"
								placeholder="Faction name"
								value={formState.name}
								onChange={(e) =>
									setFormState({ ...formState, name: e.target.value })
								}
								required
							/>
						</div>

						<div className="space-y-2">
							<Label htmlFor="iconUrl">Icon URL</Label>
							<Input
								id="iconUrl"
								placeholder="URL to faction icon"
								value={formState.iconUrl}
								onChange={(e) =>
									setFormState({ ...formState, iconUrl: e.target.value })
								}
							/>
						</div>
					</div>
				</CardContent>

				<CardFooter className="flex justify-end space-x-2">
					<Button
						variant="outline"
						type="button"
						onClick={() => router.push("/admin/factions")}
					>
						Cancel
					</Button>
					<Button type="submit" disabled={isSubmitting}>
						{isSubmitting ? (
							<>
								<Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...
							</>
						) : (
							<>{isEdit ? "Update" : "Create"} Faction</>
						)}
					</Button>
				</CardFooter>
			</Card>
		</form>
	);
}
