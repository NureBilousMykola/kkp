"use client";

import type { IFaction } from "@/lib/api/models/IFaction";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { deleteFaction, getFactions } from "@/lib/actions/factions";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow
} from "@/components/ui/table";
import { Edit, Search, Trash2 } from "lucide-react";
import {
	Tooltip,
	TooltipContent,
	TooltipProvider,
	TooltipTrigger
} from "@/components/ui/tooltip";

interface FactionListProps {
	token: string;
}

export default function FactionList({ token }: FactionListProps) {
	const [searchTerm, setSearchTerm] = useState("");
	const [factionToDelete, setFactionToDelete] = useState<string | null>(null);
	const [selectedFaction, setSelectedFaction] = useState<IFaction | null>(null);
	const [isLoading, setIsLoading] = useState(false);
	const [isDeleting, setIsDeleting] = useState(false);
	const [factions, setFactions] = useState<IFaction[] | null>(null);
	const [error, setError] = useState<string | null>(null);

	const router = useRouter();

	// Load factions
	useEffect(() => {
		async function loadFactions() {
			setIsLoading(true);
			try {
				const result = await getFactions({ token });
				if (result.error) {
					setError(result.error);
				} else {
					setFactions(result.factions || []);
				}
			} catch (err) {
				setError("An unexpected error occurred");
			} finally {
				setIsLoading(false);
			}
		}

		loadFactions();
	}, [token]);

	const handleEditFaction = (factionId: string) => {
		router.push(`/admin/factions/${factionId}`);
	};

	const handleDeleteFaction = async () => {
		if (!factionToDelete) return;
		setIsDeleting(true);
		try {
			const result = await deleteFaction({ token, factionId: factionToDelete });
			if (result.error) {
				setError(result.error);
			} else {
				// Refresh the factions list
				const updatedFactions = await getFactions({ token });
				if (updatedFactions.factions) {
					setFactions(updatedFactions.factions);
				}
			}
		} catch (err) {
			setError("An unexpected error occurred while deleting");
		} finally {
			setIsDeleting(false);
			setFactionToDelete(null);
		}
	};

	const handleRowClick = (faction: IFaction) => {
		setSelectedFaction(faction);
	};

	const handleRowKeyDown = (e: React.KeyboardEvent, faction: IFaction) => {
		if (e.key === "Enter" || e.key === " ") {
			e.preventDefault();
			setSelectedFaction(faction);
		}
	};

	const filteredFactions = factions?.filter((faction) => {
		return faction.name.toLowerCase().includes(searchTerm.toLowerCase());
	});

	if (isLoading) {
		return <div className="flex justify-center p-8">Loading factions...</div>;
	}

	if (error) {
		return (
			<div className="p-8">
				<div className="rounded border border-red-400 bg-red-100 px-4 py-3 text-red-700">
					{error}
				</div>
			</div>
		);
	}

	return (
		<Card>
			<CardHeader>
				<CardTitle>Faction Management</CardTitle>
				<CardDescription>
					View and manage all factions in the system
				</CardDescription>
			</CardHeader>
			<CardContent>
				<div className="flex flex-col gap-4">
					<div className="flex flex-wrap justify-between gap-4">
						<div className="relative w-full md:w-64">
							<Search className="absolute top-2.5 left-2 h-4 w-4 text-muted-foreground" />
							<Input
								placeholder="Search factions..."
								className="pl-8"
								value={searchTerm}
								onChange={(e) => setSearchTerm(e.target.value)}
							/>
						</div>
					</div>

					<Table>
						<TableHeader>
							<TableRow>
								<TableHead>Name</TableHead>
								<TableHead className="w-32 text-right">Actions</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{filteredFactions && filteredFactions.length > 0 ? (
								filteredFactions.map((faction) => (
									<TableRow
										key={faction._id}
										className="cursor-pointer"
										onClick={() => handleRowClick(faction)}
										onKeyDown={(e) => handleRowKeyDown(e, faction)}
										tabIndex={0}
									>
										<TableCell className="font-medium">
											{faction.name}
										</TableCell>
										<TableCell className="text-right">
											<div className="flex justify-end gap-2">
												<TooltipProvider>
													<Tooltip>
														<TooltipTrigger asChild>
															<Button
																variant="outline"
																size="icon"
																onClick={(e) => {
																	e.stopPropagation();
																	handleEditFaction(faction._id);
																}}
															>
																<Edit className="h-4 w-4" />
															</Button>
														</TooltipTrigger>
														<TooltipContent>Edit Faction</TooltipContent>
													</Tooltip>
												</TooltipProvider>

												<TooltipProvider>
													<Tooltip>
														<TooltipTrigger asChild>
															<Button
																variant="outline"
																size="icon"
																className="text-red-500 hover:text-red-600"
																onClick={(e) => {
																	e.stopPropagation();
																	setFactionToDelete(faction._id);
																}}
															>
																<Trash2 className="h-4 w-4" />
															</Button>
														</TooltipTrigger>
														<TooltipContent>Delete Faction</TooltipContent>
													</Tooltip>
												</TooltipProvider>
											</div>
										</TableCell>
									</TableRow>
								))
							) : (
								<TableRow>
									<TableCell colSpan={5} className="text-center">
										No factions found.
									</TableCell>
								</TableRow>
							)}
						</TableBody>
					</Table>
				</div>
			</CardContent>

			<Dialog
				open={factionToDelete !== null}
				onOpenChange={(open) => !open && setFactionToDelete(null)}
			>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Confirm Deletion</DialogTitle>
						<DialogDescription>
							Are you sure you want to delete this faction? This action cannot
							be undone.
						</DialogDescription>
					</DialogHeader>
					<DialogFooter>
						<Button variant="outline" onClick={() => setFactionToDelete(null)}>
							Cancel
						</Button>
						<Button
							variant="destructive"
							onClick={handleDeleteFaction}
							disabled={isDeleting}
						>
							{isDeleting ? "Deleting..." : "Delete"}
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</Card>
	);
}
