import { ChevronLeft } from "lucide-react";
import { verifySession } from "@/lib/utils/dal";
import FactionForm from "../(components)/FactionForm";
import Link from "next/link";
import { notFound } from "next/navigation";
import { factionService } from "@/lib/api/services/factions/service";

export const metadata = {
	title: "Edit Faction | Admin",
	description: "Edit an existing faction in the system"
};

interface EditFactionPageProps {
	params: {
		id: string;
	};
}

export default async function EditFactionPage({
	params
}: EditFactionPageProps) {
	const session = await verifySession();

	// Fetch the faction details
	const factionResponse = await factionService.getFaction(params.id);

	if (!factionResponse.ok || !factionResponse.data) {
		notFound();
	}

	const faction = factionResponse.data;

	return (
		<div className="space-y-6">
			<div>
				<Link
					href="/admin/factions"
					className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
				>
					<ChevronLeft className="mr-1 h-4 w-4" />
					Back to factions
				</Link>
				<h1 className="mt-2 text-3xl font-bold tracking-tight">
					Edit Faction: {faction.name}
				</h1>
			</div>

			<FactionForm token={session.token} faction={faction} isEdit />
		</div>
	);
}
