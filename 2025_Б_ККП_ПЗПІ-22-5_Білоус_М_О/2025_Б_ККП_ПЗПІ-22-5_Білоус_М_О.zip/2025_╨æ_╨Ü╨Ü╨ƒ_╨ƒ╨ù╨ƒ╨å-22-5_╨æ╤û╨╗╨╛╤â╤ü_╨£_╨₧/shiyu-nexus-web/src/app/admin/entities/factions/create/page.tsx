import { ChevronLeft } from "lucide-react";
import { verifySession } from "@/lib/utils/dal";
import FactionForm from "../(components)/FactionForm";
import Link from "next/link";

export const metadata = {
	title: "Create Faction | Admin",
	description: "Create a new faction in the system"
};

export default async function CreateFactionPage() {
	const session = await verifySession();

	return (
		<div className="space-y-6">
			<div>
				<Link
					href="/admin/factions"
					className="inline-flex items-center text-muted-foreground text-sm hover:text-foreground"
				>
					<ChevronLeft className="mr-1 h-4 w-4" />
					Back to factions
				</Link>
				<h1 className="mt-2 font-bold text-3xl tracking-tight">
					Create Faction
				</h1>
			</div>

			<FactionForm token={session.token} />
		</div>
	);
}
