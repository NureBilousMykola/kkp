import { verifySession } from "@/lib/utils/dal";
import { CardHeader } from "@/components/ui/card";
import { CardTitle } from "@/components/ui/card";
import { CardDescription } from "@/components/ui/card";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import FactionList from "./(components)/FactionList";

export const metadata = {
	title: "Enemy Management | Admin",
	description: "Manage factions in the system"
};

export default async function AdminFactionsPage() {
	const session = await verifySession();

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<CardHeader className="w-full px-0">
					<CardTitle>
						<h1 className="text-4xl">Factions</h1>
					</CardTitle>
					<CardDescription>
						View and manage all factions in the system
					</CardDescription>
				</CardHeader>

				<Button asChild>
					<Link href="./factions/create">
						<Plus className="h-4 w-4" />
						Create Faction
					</Link>
				</Button>
			</div>

			<FactionList token={session.token} />
		</div>
	);
}
