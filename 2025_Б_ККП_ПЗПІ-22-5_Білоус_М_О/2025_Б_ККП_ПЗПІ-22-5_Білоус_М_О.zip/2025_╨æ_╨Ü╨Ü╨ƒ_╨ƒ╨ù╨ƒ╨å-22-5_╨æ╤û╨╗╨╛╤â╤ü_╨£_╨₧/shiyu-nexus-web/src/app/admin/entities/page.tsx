export default function AdminEntitiesPage() {
	return <div>AdminEntitiesPage</div>;
}
