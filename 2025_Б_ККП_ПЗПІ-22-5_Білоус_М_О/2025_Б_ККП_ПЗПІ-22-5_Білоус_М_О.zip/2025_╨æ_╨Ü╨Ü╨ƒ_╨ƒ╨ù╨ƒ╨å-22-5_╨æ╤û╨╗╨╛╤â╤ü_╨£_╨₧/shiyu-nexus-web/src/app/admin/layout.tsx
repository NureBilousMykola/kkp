import { AdminSidebar } from "@/app/admin/(components)/nav/sidebar";

import { Separator } from "@/components/ui/separator";
import {
	SidebarInset,
	SidebarProvider,
	SidebarTrigger
} from "@/components/ui/sidebar";
import type { IUser } from "@/lib/api/models/IUser";
import { myUserService } from "@/lib/api/services/users/service";
import { verifySession } from "@/lib/utils/dal";
import { redirect } from "next/navigation";
import { AdminBreadcrumb } from "./(components)/nav/breadcrumb";

export const metadata = {
	title: "Admin Dashboard | Shiyu Nexus",
	description: "Administration controls for Shiyu Nexus"
};

export default async function AdminRootLayout({
	children
}: Readonly<{ children: React.ReactNode }>) {
	const session = await verifySession();

	if (session.role !== "admin") {
		return redirect("/");
	}

	const userRequest = await myUserService.getMyUser(session.token);
	if (!userRequest.ok) {
		return redirect("/");
	}
	const user = userRequest.data as IUser;

	return (
		<SidebarProvider>
			<AdminSidebar user={user} />
			<SidebarInset>
				<header className="flex h-16 shrink-0 items-center gap-2">
					<div className="flex items-center gap-2 px-4">
						<SidebarTrigger className="-ml-1" />
						<Separator
							orientation="vertical"
							className="mr-2 data-[orientation=vertical]:h-4"
						/>
						<AdminBreadcrumb />
					</div>
				</header>
				<div className="flex flex-1 flex-col gap-4 p-4 pt-0">{children}</div>
			</SidebarInset>
		</SidebarProvider>
	);
}
