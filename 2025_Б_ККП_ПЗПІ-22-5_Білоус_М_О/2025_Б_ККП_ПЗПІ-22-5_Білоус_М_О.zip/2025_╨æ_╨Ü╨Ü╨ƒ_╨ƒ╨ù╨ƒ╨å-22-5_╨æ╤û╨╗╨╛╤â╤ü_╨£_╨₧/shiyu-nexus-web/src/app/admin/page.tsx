import { myUserService } from "@/lib/api/services/users/service";
import { verifySession } from "@/lib/utils/dal";
import { redirect } from "next/navigation";

import {
	BarChart,
	CircleUser,
	Gamepad2,
	LayoutDashboard,
	Settings,
	Shield,
	Users
} from "lucide-react";

import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle
} from "@/components/ui/card";
import type { ReactNode } from "react";

export const metadata = {
	title: "Admin Dashboard | Shiyu Nexus",
	description: "Administrative dashboard for Shiyu Nexus"
};

const stats: {
	title: string;
	description: string;
	icon: ReactNode;
	value?: number;
	change?: `${"-" | "+"}${number}%`;
}[] = [
	{
		title: "Total Users",
		description: "Registered accounts",
		icon: <Users className="h-4 w-4 text-muted-foreground" />
	},
	{
		title: "Agents",
		description: "Playable characters",
		icon: <CircleUser className="h-4 w-4 text-muted-foreground" />
	},
	{
		title: "Engines",
		description: "Weapons available",
		icon: <Settings className="h-4 w-4 text-muted-foreground" />
	},
	{
		title: "Bangboos",
		description: "Support characters",
		icon: <Gamepad2 className="h-4 w-4 text-muted-foreground" />
	},
	{
		title: "Enemies",
		description: "Enemy types",
		icon: <Shield className="h-4 w-4 text-muted-foreground" />
	},
	{
		title: "Draft Sessions",
		description: "Total hosted sessions",
		icon: <BarChart className="h-4 w-4 text-muted-foreground" />
	}
];

export default async function AdminPage() {
	const session = await verifySession();
	const userResponse = await myUserService.getMyUser(session.token);

	if (!userResponse.ok || userResponse.data?.role !== "admin") {
		redirect("/");
	}

	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<h1 className="font-bold text-3xl tracking-tight">Dashboard</h1>
			</div>

			<div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
				{stats.map((stat, index) => (
					<Card key={`card-${stat.title}-${index}`}>
						<CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
							<CardTitle className="font-medium text-sm">
								{stat.title}
							</CardTitle>
							{stat.icon}
						</CardHeader>
						<CardContent>
							<div className="font-bold text-2xl">{stat.value}</div>
							<div className="flex items-center">
								<CardDescription className="text-xs">
									{stat.description}
								</CardDescription>
								{stat.change && (
									<span
										className={`ml-2 font-medium text-xs ${
											stat.change.includes("+")
												? "text-emerald-600"
												: "text-destructive"
										}`}
									>
										{stat.change}
									</span>
								)}
							</div>
						</CardContent>
					</Card>
				))}
			</div>

			<div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
				<Card className="col-span-full lg:col-span-2">
					<CardHeader>
						<CardTitle>Recent Activity</CardTitle>
						<CardDescription>
							System activity for the last 24 hours
						</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="flex h-[300px] items-center justify-center rounded-md border p-4">
							<p className="text-muted-foreground">
								Activity chart will be displayed here
							</p>
						</div>
					</CardContent>
				</Card>

				<Card className="col-span-full lg:col-span-1">
					<CardHeader>
						<CardTitle>Quick Actions</CardTitle>
						<CardDescription>Common administrative tasks</CardDescription>
					</CardHeader>
					<CardContent className="space-y-2">
						<button
							type="button"
							className="flex w-full items-center rounded-md bg-secondary p-2 text-secondary-foreground hover:bg-secondary/80"
						>
							<LayoutDashboard className="mr-2 h-4 w-4" /> Create New Draft
							Preset
						</button>
						<button
							type="button"
							className="flex w-full items-center rounded-md bg-secondary p-2 text-secondary-foreground hover:bg-secondary/80"
						>
							<CircleUser className="mr-2 h-4 w-4" /> Add New Agent
						</button>
						<button
							type="button"
							className="flex w-full items-center rounded-md bg-secondary p-2 text-secondary-foreground hover:bg-secondary/80"
						>
							<Users className="mr-2 h-4 w-4" /> Manage Users
						</button>
					</CardContent>
				</Card>
			</div>
		</div>
	);
}
