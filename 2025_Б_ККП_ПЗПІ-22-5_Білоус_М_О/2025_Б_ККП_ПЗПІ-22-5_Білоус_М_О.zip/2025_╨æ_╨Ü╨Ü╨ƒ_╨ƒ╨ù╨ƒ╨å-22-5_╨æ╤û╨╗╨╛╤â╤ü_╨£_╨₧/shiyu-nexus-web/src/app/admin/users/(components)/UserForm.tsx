"use client";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";
import { createUser, updateUser } from "@/lib/actions/users/actions";
import type { IUser } from "@/lib/api/models/IUser";
import { cn } from "@/lib/utils";
import { AlertCircle, Loader2 } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { useActionState, useEffect } from "react";

interface UserFormProps {
	user?: IUser;
}

export default function UserForm({ user }: UserFormProps) {
	const [createState, createAgentAction, isCreating] = useActionState(
		createUser,
		undefined
	);

	const [updateState, updateAgentAction, isUpdating] = useActionState(
		updateUser,
		undefined
	);

	const isLoading = isCreating || isUpdating;

	useEffect(() => {
		if (createState?.success || updateState?.success) {
			redirect("./");
		}
	}, [createState, updateState]);

	return (
		<form action={user ? updateAgentAction : createAgentAction}>
			<Card>
				<CardContent className="space-y-4">
					{(createState?.message || updateState?.message) &&
						(!createState?.success || !updateState?.success) && (
							<Alert variant="destructive">
								<AlertCircle className="h-4 w-4" />
								<AlertTitle>Api Error:</AlertTitle>
								<AlertDescription>
									{createState?.message || updateState?.message}
								</AlertDescription>
							</Alert>
						)}

					{user && (
						<div className="space-y-2 text-muted-foreground">
							<Label htmlFor="id">User ID</Label>
							<Input
								readOnly
								id="id"
								name="id"
								defaultValue={user?._id}
								required
							/>
							{updateState?.errors?.id && (
								<span className="mt-0 text-destructive text-xs">
									{updateState?.errors?.id}
								</span>
							)}
						</div>
					)}

					<div className="space-y-2 text-muted-foreground">
						<Label htmlFor="id">Username</Label>
						<Input
							readOnly={!!user}
							id="username"
							name="username"
							placeholder="Username"
							defaultValue={user?.username}
							required
							className={cn(
								createState?.errors?.username && "border-2 border-destructive"
							)}
						/>
						{createState?.errors?.email && (
							<span className="mt-0 text-destructive text-xs">
								{createState?.errors?.email}
							</span>
						)}
					</div>
					<div className="space-y-2 text-muted-foreground">
						<Label htmlFor="email">Email</Label>
						<Input
							readOnly={!!user}
							id="email"
							name="email"
							placeholder="Email"
							defaultValue={user?.email}
							required
							className={cn(
								createState?.errors?.email && "border-2 border-destructive"
							)}
						/>
						{createState?.errors?.email && (
							<span className="mt-0 text-destructive text-xs">
								{createState?.errors?.email}
							</span>
						)}
					</div>

					{!user && (
						<div className="space-y-2">
							<Label htmlFor="password">Password</Label>

							<Input
								id="password"
								name="password"
								placeholder="Password"
								required
								className={cn(
									createState?.errors?.password && "border-2 border-destructive"
								)}
							/>

							{createState?.errors?.password && (
								<span className="mt-0 text-destructive text-xs">
									{createState?.errors?.password}
								</span>
							)}
						</div>
					)}

					<div className="space-y-2">
						<Label htmlFor="role">Role</Label>
						<Select name="role" required defaultValue={user?.role}>
							<SelectTrigger id="role">
								<SelectValue placeholder="Select role" />
							</SelectTrigger>
							<SelectContent>
								<SelectItem value="admin">Admin</SelectItem>
								<SelectItem value="moderator">Moderator</SelectItem>
								<SelectItem value="user">User</SelectItem>
							</SelectContent>
						</Select>
						{(createState?.errors?.role || updateState?.errors?.role) && (
							<span className="mt-0 text-destructive text-xs">
								{createState?.errors?.role || updateState?.errors?.role}
							</span>
						)}
					</div>
				</CardContent>

				<CardFooter className="flex justify-between">
					<Button type="button" variant="outline" disabled={isLoading} asChild>
						<Link href="./">Cancel</Link>
					</Button>
					<Button type="submit" disabled={isLoading}>
						{isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
						{user ? "Update" : "Create"}
					</Button>
				</CardFooter>
			</Card>
		</form>
	);
}
