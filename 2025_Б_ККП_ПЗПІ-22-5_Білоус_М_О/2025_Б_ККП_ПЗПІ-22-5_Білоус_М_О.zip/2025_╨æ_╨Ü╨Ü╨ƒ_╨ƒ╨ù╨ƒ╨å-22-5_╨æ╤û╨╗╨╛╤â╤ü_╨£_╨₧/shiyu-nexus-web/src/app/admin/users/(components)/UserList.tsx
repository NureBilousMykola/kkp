"use client";

import type { IUser } from "@/lib/api/models/IUser";
import { useCallback, useEffect, useState } from "react";

import {
	AlertDialog,
	AlertDialogAction,
	AlertDialogCancel,
	AlertDialogContent,
	AlertDialogDescription,
	AlertDialogFooter,
	AlertDialogHeader,
	AlertDialogTitle
} from "@/components/ui/alert-dialog";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow
} from "@/components/ui/table";
import { User, Mail, ShieldBan, List } from "lucide-react";
import { UserListFilters } from "./UserListFilters";
import { UserListItem, UserListItemSkeleton } from "./UserListItem";
import { adminUserService } from "@/lib/api/services/users/service";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationPrevious,
	PaginationLink,
	PaginationEllipsis,
	PaginationNext
} from "@/components/ui/pagination";
import { randomHash } from "@/lib/utils/math";

interface UserListProps {
	token: string;
}

export default function UserList({ token }: UserListProps) {
	const [searchTerm, setSearchTerm] = useState("");
	const [roleFilter, setRoleFilter] = useState("all");
	const [userToDelete, setUserToDelete] = useState<string | null>(null);

	const [users, setUsers] = useState<IUser[] | null>(null);

	useEffect(() => {
		(async () => {
			const response = await adminUserService.getUsers(token);
			if (!response.ok) {
				console.error(response.error);
				return;
			}
			setUsers(response.data);
		})();
	}, [token]);

	const filteredUsers = users?.filter((user) => {
		const matchesSearch =
			user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
			user.email.toLowerCase().includes(searchTerm.toLowerCase());

		const matchesRole = roleFilter === "all" || user.role === roleFilter;

		return matchesSearch && matchesRole;
	});

	const deleteUser = useCallback(async () => {
		if (!userToDelete) return;

		const response = await adminUserService.deleteUser(token, userToDelete);

		if (!response.ok) {
			return { error: response.error || "Failed to delete agent" };
		}

		setUserToDelete(null);

		return { success: true };
	}, [userToDelete, token]);

	return (
		<>
			<div className="flex flex-col gap-4">
				<UserListFilters
					setSearchTerm={setSearchTerm}
					setRoleFilter={setRoleFilter}
				/>

				<Pagination>
					<PaginationContent>
						<PaginationItem>
							<PaginationPrevious href="#" />
						</PaginationItem>
						<PaginationItem>
							<PaginationLink href="#">1</PaginationLink>
						</PaginationItem>
						<PaginationItem>
							<PaginationLink href="#" isActive>
								2
							</PaginationLink>
						</PaginationItem>
						<PaginationItem>
							<PaginationLink href="#">3</PaginationLink>
						</PaginationItem>
						<PaginationItem>
							<PaginationEllipsis />
						</PaginationItem>
						<PaginationItem>
							<PaginationNext href="#" />
						</PaginationItem>
					</PaginationContent>
				</Pagination>

				<div className="rounded-md border-2 border-border">
					<Table>
						<TableHeader>
							<TableRow>
								<TableHead>
									<div className="flex items-center gap-2">
										<User className="h-4 w-4 text-muted-foreground" />
										User
									</div>
								</TableHead>
								<TableHead>
									<div className="flex items-center gap-2">
										<Mail className="h-4 w-4 text-muted-foreground" />
										Email
									</div>
								</TableHead>
								<TableHead>
									<div className="flex items-center gap-2">
										<ShieldBan className="h-4 w-4 text-muted-foreground" />
										Role
									</div>
								</TableHead>
								<TableHead>
									<div className="flex items-center gap-2">
										<List className="h-4 w-4 text-muted-foreground" />
										Collection
									</div>
								</TableHead>
								<TableHead className="w-20 text-center">Actions</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{!users ? (
								new Array(10)
									.fill(null)
									.map((_, i) => (
										<UserListItemSkeleton key={randomHash(10).toString()} />
									))
							) : !filteredUsers?.length ? (
								<TableRow>
									<TableCell colSpan={4} className="py-8 text-center">
										No users found
									</TableCell>
								</TableRow>
							) : (
								filteredUsers.map((user) => (
									<UserListItem
										key={user._id}
										user={user}
										onDelete={setUserToDelete}
									/>
								))
							)}
						</TableBody>
					</Table>
				</div>
			</div>

			<AlertDialog
				open={!!userToDelete}
				onOpenChange={() => setUserToDelete(null)}
			>
				<AlertDialogContent>
					<AlertDialogHeader>
						<AlertDialogTitle>Are you sure?</AlertDialogTitle>
						<AlertDialogDescription>
							This action cannot be undone. This will permanently delete the
							user and all associated data.
						</AlertDialogDescription>
					</AlertDialogHeader>
					<AlertDialogFooter>
						<AlertDialogCancel>Cancel</AlertDialogCancel>
						<AlertDialogAction onClick={deleteUser}>Delete</AlertDialogAction>
					</AlertDialogFooter>
				</AlertDialogContent>
			</AlertDialog>
		</>
	);
}
