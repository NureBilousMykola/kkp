import Search from "@/components/icons/search";
import { Input } from "@/components/ui/input";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue
} from "@/components/ui/select";

interface UserListFiltersProps {
	setSearchTerm: (searchTerm: string) => void;
	setRoleFilter: (roleFilter: string) => void;
}

export const UserListFilters: React.FC<UserListFiltersProps> = ({
	setSearchTerm,
	setRoleFilter
}) => {
	return (
		<div className="flex flex-col justify-between gap-4 md:flex-row">
			<div className="relative w-full flex-1 md:w-64">
				<Search className="absolute top-2.5 left-2 h-4 w-4 text-muted-foreground" />
				<Input
					placeholder="Search users..."
					className="pl-8"
					onChange={(e) => setSearchTerm(e.target.value)}
				/>
			</div>
			<Select onValueChange={setRoleFilter}>
				<SelectTrigger className="w-full md:w-40">
					<SelectValue placeholder="Filter by role" />
				</SelectTrigger>
				<SelectContent>
					<SelectItem value="all">All Roles</SelectItem>
					<SelectItem value="user">User</SelectItem>
					<SelectItem value="moderator">Moderator</SelectItem>
					<SelectItem value="admin">Admin</SelectItem>
				</SelectContent>
			</Select>
		</div>
	);
};
