import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { TableCell, TableRow } from "@/components/ui/table";
import {
	Tooltip,
	TooltipContent,
	TooltipTrigger
} from "@/components/ui/tooltip";
import type { IUser } from "@/lib/api/models/IUser";
import { CrownIcon, Edit, Gamepad2, Settings, Trash2 } from "lucide-react";
import Link from "next/link";

interface UserListItemProps {
	user: IUser;
	onDelete: (id: string) => void;
}

export const UserListItem: React.FC<UserListItemProps> = ({
	user,
	onDelete
}) => {
	return (
		<TableRow className="hover:bg-muted/50">
			<TableCell>
				<span>{user.username}</span>
			</TableCell>
			<TableCell>
				<span>{user.email}</span>
			</TableCell>
			<TableCell className="capitalize">
				{user.role === "user" ? (
					<span className="text-muted-foreground">User</span>
				) : (
					<Badge variant={user.role === "admin" ? "default" : "secondary"}>
						{user.role === "admin" && <CrownIcon className="h-4 w-4" />}
						{user.role}
					</Badge>
				)}
			</TableCell>
			<TableCell>
				<div className="flex items-center gap-4">
					<Tooltip>
						<TooltipTrigger className="flex items-center gap-1">
							<Gamepad2 className="h-4 w-4 text-muted-foreground" />
							<span>{user.ownedAgents.length}</span>
						</TooltipTrigger>
						<TooltipContent>
							<p>Owned Agents</p>
						</TooltipContent>
					</Tooltip>
					<Tooltip>
						<TooltipTrigger className="flex items-center gap-1">
							<Settings className="h-4 w-4 text-muted-foreground" />
							<span>{user.ownedEngines.length}</span>
						</TooltipTrigger>
						<TooltipContent>
							<p>Owned Engines</p>
						</TooltipContent>
					</Tooltip>
				</div>
			</TableCell>
			<TableCell className="text-right">
				<div className="flex justify-end gap-2">
					<Tooltip>
						<TooltipTrigger asChild>
							<Button variant="outline" size="icon" title="Edit User" asChild>
								<Link href={`./users/${user._id}`}>
									<Edit className="h-4 w-4" />
								</Link>
							</Button>
						</TooltipTrigger>
						<TooltipContent>Edit User</TooltipContent>
					</Tooltip>

					<Tooltip>
						<TooltipTrigger asChild>
							<Button
								variant="outline"
								size="icon"
								onClick={() => onDelete(user._id)}
								onKeyDown={(e) => {
									if (e.key !== "Enter") return;
									onDelete(user._id);
								}}
								className="cursor-pointer"
								title="Delete User"
							>
								<Trash2 className="h-4 w-4" />
							</Button>
						</TooltipTrigger>
						<TooltipContent>Delete User</TooltipContent>
					</Tooltip>
				</div>
			</TableCell>
		</TableRow>
	);
};

export const UserListItemSkeleton = () => {
	return (
		<TableRow>
			<TableCell>
				<Skeleton className="h-6 w-40" />
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-40" />
			</TableCell>
			<TableCell>
				<Skeleton className="h-6 w-16" />
			</TableCell>
			<TableCell className="flex gap-2">
				<Skeleton className="h-6 w-10" />
				<Skeleton className="h-6 w-10" />
			</TableCell>
			<TableCell className="text-right">
				<div className="flex items-center justify-end gap-2">
					<Skeleton className="h-8 w-8" />
					<Skeleton className="h-8 w-8" />
				</div>
			</TableCell>
		</TableRow>
	);
};
