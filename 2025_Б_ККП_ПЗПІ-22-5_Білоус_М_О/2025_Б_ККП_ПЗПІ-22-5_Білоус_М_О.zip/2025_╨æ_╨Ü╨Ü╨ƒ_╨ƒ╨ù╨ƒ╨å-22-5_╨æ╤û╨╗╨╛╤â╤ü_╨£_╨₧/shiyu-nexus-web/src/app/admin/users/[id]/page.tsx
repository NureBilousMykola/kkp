import UserForm from "@/app/admin/users/(components)/UserForm";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { adminUserService } from "@/lib/api/services/users/service";
import { verifySession } from "@/lib/utils/dal";
import { notFound, redirect } from "next/navigation";

export const metadata = {
	title: "Edit User | Admin",
	description: "Edit user details"
};

interface EditUserPageProps {
	params: Promise<{ id: string }>;
}

export default async function EditUserPage({ params }: EditUserPageProps) {
	const userId = (await params).id;
	const session = await verifySession();

	if (!session || !session?.role || session.role !== "admin") {
		redirect("/");
	}

	const userResponse = await adminUserService.getUser(session.token, userId);

	if (!userResponse.ok || !userResponse.data) {
		notFound();
	}

	const user = userResponse.data;

	return (
		<div className="space-y-6">
			<CardHeader className="w-full px-0">
				<CardTitle>
					<h1 className="text-4xl">Edit User</h1>
				</CardTitle>
				<CardDescription>Edit user details</CardDescription>
			</CardHeader>
			<UserForm user={user} />
		</div>
	);
}
