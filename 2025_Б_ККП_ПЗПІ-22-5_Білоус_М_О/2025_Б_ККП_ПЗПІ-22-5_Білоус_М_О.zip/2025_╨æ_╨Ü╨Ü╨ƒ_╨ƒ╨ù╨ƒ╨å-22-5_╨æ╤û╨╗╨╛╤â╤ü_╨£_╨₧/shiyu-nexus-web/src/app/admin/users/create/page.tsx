import UserForm from "@/app/admin/users/(components)/UserForm";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { verifySession } from "@/lib/utils/dal";
import { redirect } from "next/navigation";

export const metadata = {
	title: "Create User | Admin",
	description: "Create a new user in the system"
};

export default async function CreateUserPage() {
	const session = await verifySession();

	if (!session || !session?.role || session.role !== "admin") {
		redirect("/");
	}

	return (
		<div className="space-y-6">
			<CardHeader className="w-full px-0">
				<CardTitle>
					<h1 className="text-4xl">Create User</h1>
				</CardTitle>
				<CardDescription>Create a new user in the system</CardDescription>
			</CardHeader>
			<UserForm />
		</div>
	);
}
