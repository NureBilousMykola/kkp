import UserList from "@/app/admin/users/(components)/UserList";
import { Button } from "@/components/ui/button";
import { CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { verifySession } from "@/lib/utils/dal";
import { UserPlus } from "lucide-react";
import Link from "next/link";

export const metadata = {
	title: "User Management | Admin",
	description: "Manage users in the system"
};

export default async function AdminUsersPage() {
	const session = await verifySession();
	return (
		<div className="space-y-6">
			<div className="flex items-center justify-between">
				<CardHeader className="w-full px-0">
					<CardTitle>
						<h1 className="text-4xl">Users</h1>
					</CardTitle>
					<CardDescription>
						View and manage all users in the system
					</CardDescription>
				</CardHeader>

				<Button asChild>
					<Link href="./users/create">
						<UserPlus className="mr-2 h-4 w-4" />
						Create User
					</Link>
				</Button>
			</div>

			<UserList token={session.token} />
		</div>
	);
}
