import "@styles/index.css";

import type { Metadata, Viewport } from "next";
import { Saira } from "next/font/google";

import { Providers } from "@/app/providers";

const font = Saira({
	subsets: ["latin"],
	display: "swap",
	variable: "--font-saira"
});

export const viewport: Viewport = {
	width: "device-width",
	initialScale: 1,
	themeColor: [
		{ media: "(prefers-color-scheme: light)", color: "#fff" },
		{ media: "(prefers-color-scheme: dark)", color: "#222" }
	],
	colorScheme: "dark light"
};

export const metadata: Metadata = {
	// metadataBase: new URL(""), // takes effect only in production
	title: "Shiyu Nexus",
	description: "",
	keywords: [],
	alternates: {
		canonical: "/",
		languages: {
			"en-US": "/"
		}
	},
	robots: {
		index: true,
		follow: true,
		noarchive: true,
		nosnippet: false,
		noimageindex: false
	}
};

export default function RootLayout({
	children
}: Readonly<{ children: React.ReactNode }>) {
	return (
		<html
			lang="en"
			className="scrollbar-thin bg-background text-foreground"
			suppressHydrationWarning
		>
			<body
				className={`${font.variable} flex min-h-screen flex-col font-saira`}
			>
				<Providers>{children}</Providers>
			</body>
		</html>
	);
}
