"use client";

import {
	AgentsProvider,
	EnemiesProvider,
	EnginesProvider,
	FactionsProvider
} from "@/lib/contexts/dataProviders";
import { ThemeProvider } from "next-themes";

export function Providers({
	children
}: {
	children: React.ReactNode;
}) {
	return (
		<ThemeProvider attribute="class">
			<AgentsProvider>
				<EnginesProvider>
					<FactionsProvider>
						<EnemiesProvider>{children}</EnemiesProvider>
					</FactionsProvider>
				</EnginesProvider>
			</AgentsProvider>
		</ThemeProvider>
	);
}
