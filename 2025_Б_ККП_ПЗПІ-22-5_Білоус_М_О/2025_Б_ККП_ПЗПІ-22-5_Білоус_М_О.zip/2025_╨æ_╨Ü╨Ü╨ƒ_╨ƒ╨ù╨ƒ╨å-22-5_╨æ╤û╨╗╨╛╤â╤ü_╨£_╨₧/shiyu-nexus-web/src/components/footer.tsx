import Link from "next/link";
import type React from "react";
import { ThemeSwitch } from "./themeSwitch";

interface FooterLinkProps {
	href: string;
	children: React.ReactNode;
}

const FooterLink = ({ href, children }: FooterLinkProps) => (
	<Link href={href} className="transition-colors hover:text-primary">
		{children}
	</Link>
);

interface FooterSectionProps {
	title: string;
	links: { href: string; label: string }[];
}

const FooterSection = ({ title, links }: FooterSectionProps) => (
	<div>
		<p className="mb-4 pt-1 font-semibold text-primary">{title}</p>
		<ul className="text-muted-foreground text-xs">
			{links.map((link, index) => (
				// biome-ignore lint/suspicious/noArrayIndexKey: <explanation>
				<li key={index} className="mb-2">
					<FooterLink href={link.href}>{link.label}</FooterLink>
				</li>
			))}
		</ul>
	</div>
);

const footerLinks = {
	socials: [
		// { href: "https://discord.shiyu-nexus/", label: "Discord" },
		{ href: "https://github.com/shiyu-nexus", label: "GitHub" }
	],
	other: [
		{ href: "/contributors", label: "Contributors" },
		{ href: "/changelog", label: "Changelog" },
		{ href: "mailto:contact@shiyu.nexus", label: "Contact" }
	],
	legal: [
		{ href: "/privacy-policy", label: "Privacy Policy" }
		// { href: "mailto:legal@shiyu.nexus", label: "Legal Inquiries" },
		// { href: "mailto:dmca@shiyu.nexus", label: "DMCA Requests" }
	]
};

export const Footer: React.FC = () => {
	const currentYear = new Date().getFullYear();

	return (
		<footer className="z-10 border-border bg-background border-t p-3 text-muted-foreground">
			<div className="mx-auto w-full max-w-screen-xl p-4 py-6 pb-16 lg:py-8">
				<div className="w-full md:flex md:justify-between">
					<div className="mb-4 flex w-full flex-col md:mb-0 md:w-72">
						<div className="flex items-center justify-center gap-1 md:justify-start">
							<picture>
								<img
									srcSet="/icons/logo-dark.svg"
									alt="shiyu.nexus"
									width={100}
									height={100}
								/>
							</picture>
						</div>
					</div>
					<div className="grid grid-cols-2 gap-8 sm:grid-cols-3 sm:gap-6">
						<FooterSection title="Socials" links={footerLinks.socials} />
						<FooterSection title="Other" links={footerLinks.other} />
						<FooterSection title="Legal" links={footerLinks.legal} />
					</div>
				</div>
				<div className="mt-8 flex justify-between border-border border-t p-3 text-muted-foreground text-xs">
					<div className="space-y-1">
						<p>shiyu.nexus © 2024-{currentYear}</p>
						<p>
							Not affiliated with any games or companies unless otherwise
							stated.
						</p>
					</div>
					<ThemeSwitch />
				</div>
			</div>
		</footer>
	);
};
