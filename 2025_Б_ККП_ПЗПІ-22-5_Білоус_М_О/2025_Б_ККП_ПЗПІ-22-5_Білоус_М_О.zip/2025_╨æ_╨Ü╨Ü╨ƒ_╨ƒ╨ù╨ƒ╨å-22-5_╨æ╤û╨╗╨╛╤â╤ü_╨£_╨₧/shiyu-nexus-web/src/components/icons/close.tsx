import React from "react";

import type { IconProps } from ".";

const CloseIcon = React.forwardRef<SVGSVGElement, IconProps>(
	({ className, ...props }, ref) => (
		<svg
			ref={ref}
			{...props}
			className={className}
			width="24"
			height="24"
			viewBox="0 -960 960 960"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
			aria-hidden="true"
		>
			<path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z" />
		</svg>
	)
);

CloseIcon.displayName = "Close";
export default React.memo(CloseIcon);
