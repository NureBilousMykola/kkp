"use client";

import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Computer, Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";

export const ThemeSwitch: React.FC = () => {
	const { theme, setTheme } = useTheme();

	const [tab, setTab] = useState<string>();

	useEffect(() => {
		setTab(theme);
	}, [theme]);

	return (
		<Tabs value={tab} className="!bg-none">
			<TabsList className="p-1">
				{tabs.map((tab) => (
					<TabsTrigger
						key={tab.value}
						value={tab.value}
						className="px-2.5 sm:px-3"
						onClick={() => setTheme(tab.value)}
					>
						<code className="flex items-center gap-1 text-[13px] [&>svg]:h-4 [&>svg]:w-4">
							{tab.icon} {tab.name}
						</code>
					</TabsTrigger>
				))}
			</TabsList>
		</Tabs>
	);
};

const tabs = [
	{
		name: "System",
		value: "system",
		icon: <Computer />
	},
	{
		name: "Dark",
		value: "dark",
		icon: <Moon />
	},
	{
		name: "Light",
		value: "light",
		icon: <Sun />
	}
];
