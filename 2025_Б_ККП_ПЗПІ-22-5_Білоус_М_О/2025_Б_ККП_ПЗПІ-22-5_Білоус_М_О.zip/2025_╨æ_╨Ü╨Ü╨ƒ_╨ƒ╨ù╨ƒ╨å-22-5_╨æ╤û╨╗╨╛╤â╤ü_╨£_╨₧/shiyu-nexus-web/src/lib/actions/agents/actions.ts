"use server";

import { adminAgentService } from "@/lib/api/services/agents/service";
import {
	CreateAgentFormSchema,
	type UpdateAgentFormState,
	type CreateAgentFormState,
	UpdateAgentFormSchema
} from "./types";
import { verifySession } from "@/lib/utils/dal";

export async function createAgent(
	state: CreateAgentFormState,
	formData: FormData
): Promise<Partial<CreateAgentFormState>> {
	const session = await verifySession();

	if (!session || !session?.role || session.role !== "admin") {
		return { message: "You must be logged in to create an agent" };
	}

	const validatedFields = CreateAgentFormSchema.safeParse({
		name: formData.get("name"),
		fullName: formData.get("fullName"),
		normalizedName: formData.get("normalizedName"),
		rarity: formData.get("rarity"),
		specialty: formData.get("specialty"),
		attribute: formData.get("attribute"),
		factionId: formData.get("factionId"),
		isReleased: formData.get("isReleased"),
		isLimited: formData.get("isLimited"),
		imageUrl: formData.get("imageUrl"),
		iconUrl: formData.get("iconUrl")
	});

	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors,
			success: false
		};
	}

	const {
		name,
		fullName,
		normalizedName,
		rarity,
		specialty,
		attribute,
		factionId: faction,
		isReleased,
		isLimited,
		imageUrl,
		iconUrl
	} = validatedFields.data;

	const response = await adminAgentService.createAgent(session.token, {
		name,
		fullName,
		normalizedName,
		rarity,
		specialty,
		attribute,
		faction,
		isReleased,
		isLimited,
		imageUrl,
		iconUrl
	});

	if (!response.ok) {
		return {
			message: response.error || "Failed to create agent",
			success: false
		};
	}

	return { success: true, message: "Agent created successfully" };
}

export async function updateAgent(
	state: UpdateAgentFormState,
	formData: FormData
): Promise<Partial<UpdateAgentFormState>> {
	const session = await verifySession();

	if (!session || !session?.role || session.role !== "admin") {
		return { message: "You must be logged in to create an agent" };
	}

	const validatedFields = UpdateAgentFormSchema.safeParse({
		id: formData.get("id"),
		name: formData.get("name"),
		fullName: formData.get("fullName"),
		normalizedName: formData.get("normalizedName"),
		rarity: formData.get("rarity"),
		specialty: formData.get("specialty"),
		attribute: formData.get("attribute"),
		factionId: formData.get("factionId"),
		isReleased: formData.get("isReleased"),
		isLimited: formData.get("isLimited"),
		imageUrl: formData.get("imageUrl"),
		iconUrl: formData.get("iconUrl")
	});

	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors
		};
	}

	const {
		id,
		name,
		fullName,
		normalizedName,
		rarity,
		specialty,
		attribute,
		factionId: faction,
		isReleased,
		isLimited,
		imageUrl,
		iconUrl
	} = validatedFields.data;

	const response = await adminAgentService.updateAgent(session.token, id, {
		name,
		fullName,
		normalizedName,
		rarity,
		specialty,
		attribute,
		faction,
		isReleased,
		isLimited,
		imageUrl,
		iconUrl
	});

	if (!response.ok) {
		return { message: response.error || "Failed to create agent" };
	}

	return { success: true, message: "Agent updated successfully" };
}
