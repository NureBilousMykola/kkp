import { Attributes } from "@/lib/api/keys/Attribute";
import { Rarities } from "@/lib/api/keys/Rarity";
import { Specialties } from "@/lib/api/keys/Specialty";
import { checkbox, optionalUrl } from "@/lib/utils/zod";
import { z } from "zod";

export const CreateAgentFormSchema = z.object({
	name: z
		.string()
		.min(2, { message: "Name must be at least 2 characters long." })
		.trim(),
	fullName: z
		.string()
		.min(2, { message: "Name must be at least 2 characters long." })
		.trim(),
	normalizedName: z
		.string()
		.min(2, { message: "Name must be at least 2 characters long." })
		.trim(),
	rarity: z.enum(Rarities),
	specialty: z.enum(Specialties),
	attribute: z.enum(Attributes),
	factionId: z.string(),
	isReleased: checkbox(),
	isLimited: checkbox(),
	imageUrl: optionalUrl(),
	iconUrl: optionalUrl()
});

type CreateAgentFormErrors = {
	name?: string[];
	fullName?: string[];
	normalizedName?: string[];
	rarity?: string[];
	specialty?: string[];
	attribute?: string[];
	factionId?: string[];
	isReleased?: string[];
	isLimited?: string[];
	imageUrl?: string[];
	iconUrl?: string[];
};

export type CreateAgentFormState =
	| {
			errors?: CreateAgentFormErrors;
			message?: string;
			success?: boolean;
	  }
	| undefined;

export const UpdateAgentFormSchema = CreateAgentFormSchema.extend({
	id: z.string()
});

export type UpdateAgentFormState =
	| {
			errors?: CreateAgentFormErrors & { id?: string[] };
			message?: string;
			success?: boolean;
	  }
	| undefined;
