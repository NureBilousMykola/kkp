"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { authService } from "../../api/services/auth/service";
import { SigninFormSchema, type SigninFormState } from "./types";

export async function signin(state: SigninFormState, formData: FormData) {
	// Validate form fields
	const validatedFields = SigninFormSchema.safeParse({
		username: formData.get("username"),
		password: formData.get("password")
	});

	// If any form fields are invalid, return early
	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors
		};
	}
	// 2. Prepare data for insertion into database
	const { username, password } = validatedFields.data;

	// 3. Insert the user into the database or call an Auth Library's API
	const newUser = await authService.login(username, password);

	if (!newUser.ok || !newUser.data) {
		return {
			message: "An error occurred while logging into your account."
		};
	}

	(await cookies()).set("auth_token", newUser.data.token, {
		httpOnly: true,
		secure: process.env.NODE_ENV === "production",
		sameSite: "lax",
		maxAge: 7 * 24 * 60 * 60 * 1000,
		path: "/"
	});

	redirect("/profile");
}
