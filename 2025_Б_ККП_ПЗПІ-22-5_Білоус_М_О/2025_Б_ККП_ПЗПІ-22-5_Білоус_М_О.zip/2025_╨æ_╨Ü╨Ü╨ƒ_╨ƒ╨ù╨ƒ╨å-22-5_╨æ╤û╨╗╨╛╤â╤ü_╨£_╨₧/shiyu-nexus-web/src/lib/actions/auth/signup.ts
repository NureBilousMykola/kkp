"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { authService } from "../../api/services/auth/service";
import { SignupFormSchema, type SignupFormState } from "./types";

export async function signup(state: SignupFormState, formData: FormData) {
	// Validate form fields
	const validatedFields = SignupFormSchema.safeParse({
		username: formData.get("username"),
		password: formData.get("password")
	});

	// If any form fields are invalid, return early
	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors
		};
	}
	// 2. Prepare data for insertion into database
	const { username, email, password } = validatedFields.data;

	// 3. Insert the user into the database or call an Auth Library's API
	const newUser = await authService.register(email, username, password);

	if (!newUser.ok || !newUser.data) {
		return {
			message: "An error occurred while creating your account."
		};
	}

	(await cookies()).set("auth_token", newUser.data.token, {
		httpOnly: true,
		secure: process.env.NODE_ENV === "production",
		sameSite: "lax",
		maxAge: 7 * 24 * 60 * 60 * 1000,
		path: "/"
	});

	redirect("/profile");
}
