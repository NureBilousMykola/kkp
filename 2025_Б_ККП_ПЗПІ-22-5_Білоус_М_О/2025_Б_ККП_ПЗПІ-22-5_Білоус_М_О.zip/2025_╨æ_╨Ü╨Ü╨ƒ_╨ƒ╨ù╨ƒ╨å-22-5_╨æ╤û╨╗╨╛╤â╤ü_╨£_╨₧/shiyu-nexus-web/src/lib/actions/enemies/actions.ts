"use server";

import { adminEnemyService } from "@/lib/api/services/enemies/service";
import {
	CreateEnemyFormSchema,
	type UpdateEnemyFormState,
	type CreateEnemyFormState,
	UpdateEnemyFormSchema
} from "./types";
import { verifySession } from "@/lib/utils/dal";

export async function createEnemy(
	state: CreateEnemyFormState,
	formData: FormData
): Promise<Partial<CreateEnemyFormState>> {
	const session = await verifySession();

	if (!session || !session?.role || session.role !== "admin") {
		return { message: "You must be logged in to create an enemy" };
	}

	const validatedFields = CreateEnemyFormSchema.safeParse({
		name: formData.get("name"),
		normalizedName: formData.get("normalizedName"),
		category: formData.get("category"),
		description: formData.get("description"),
		weaknessAttributes: formData.getAll("weaknessAttributes"),
		resistanceAttributes: formData.getAll("resistanceAttributes"),
		imageUrl: formData.get("imageUrl")
	});

	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors,
			success: false
		};
	}

	const {
		name,
		normalizedName,
		category,
		description,
		weaknessAttributes,
		resistanceAttributes,
		imageUrl
	} = validatedFields.data;

	const response = await adminEnemyService.createEnemy(session.token, {
		name,
		normalizedName,
		category,
		description
	});

	if (!response.ok) {
		return {
			message: response.error || "Failed to create enemy",
			success: false
		};
	}

	return { success: true, message: "Enemy created successfully" };
}

export async function updateEnemy(
	state: UpdateEnemyFormState,
	formData: FormData
): Promise<Partial<UpdateEnemyFormState>> {
	const session = await verifySession();

	if (!session || !session?.role || session.role !== "admin") {
		return { message: "You must be logged in to update an enemy" };
	}

	const validatedFields = UpdateEnemyFormSchema.safeParse({
		id: formData.get("id"),
		name: formData.get("name"),
		normalizedName: formData.get("normalizedName"),
		category: formData.get("category"),
		description: formData.get("description"),
		weaknessAttributes: formData.getAll("weaknessAttributes"),
		resistanceAttributes: formData.getAll("resistanceAttributes"),
		imageUrl: formData.get("imageUrl")
	});

	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors,
			success: false
		};
	}

	const {
		id,
		name,
		normalizedName,
		category,
		description,
		weaknessAttributes,
		resistanceAttributes,
		imageUrl
	} = validatedFields.data;

	const response = await adminEnemyService.updateEnemy(session.token, id, {
		name,
		normalizedName,
		category,
		description,
		weaknessAttributes,
		resistanceAttributes,
		imageUrl
	});

	if (!response.ok) {
		return {
			message: response.error || "Failed to update enemy",
			success: false
		};
	}

	return { success: true, message: "Enemy updated successfully" };
}
