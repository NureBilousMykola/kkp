import { Attributes } from "@/lib/api/keys/Attribute";
import { EnemyCategories } from "@/lib/api/keys/EnemyCategory";
import { optionalUrl } from "@/lib/utils/zod";
import { z } from "zod";

export const CreateEnemyFormSchema = z.object({
	name: z
		.string()
		.min(2, { message: "Name must be at least 2 characters long." })
		.trim(),
	normalizedName: z
		.string()
		.min(2, { message: "Name must be at least 2 characters long." })
		.trim(),
	category: z.enum(EnemyCategories),
	description: z.string().optional(),
	// html form does not send empty arrays
	weaknessAttributes: z.array(z.enum(Attributes)).optional().default([]),
	resistanceAttributes: z.array(z.enum(Attributes)).optional().default([]),
	imageUrl: optionalUrl()
});

type CreateEnemyFormErrors = {
	name?: string[];
	normalizedName?: string[];
	category?: string[];
	description?: string[];
	weaknessAttributes?: string[];
	resistanceAttributes?: string[];
	imageUrl?: string[];
};

export type CreateEnemyFormState =
	| {
			errors?: CreateEnemyFormErrors;
			message?: string;
			success?: boolean;
	  }
	| undefined;

export const UpdateEnemyFormSchema = CreateEnemyFormSchema.extend({
	id: z.string()
});

export type UpdateEnemyFormState =
	| {
			errors?: CreateEnemyFormErrors & { id?: string[] };
			id?: string[];
			message?: string;
			success?: boolean;
	  }
	| undefined;
