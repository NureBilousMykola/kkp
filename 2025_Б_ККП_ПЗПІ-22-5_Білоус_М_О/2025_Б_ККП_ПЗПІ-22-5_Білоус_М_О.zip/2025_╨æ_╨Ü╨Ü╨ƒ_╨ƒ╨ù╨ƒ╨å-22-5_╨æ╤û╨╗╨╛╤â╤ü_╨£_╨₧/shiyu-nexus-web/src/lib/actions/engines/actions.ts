"use server";

import { adminEngineService } from "@/lib/api/services/engines/service";
import { verifySession } from "@/lib/utils/dal";
import type {
	CreateEngineFormState,
	UpdateEngineState
} from "./types";
import { CreateEngineSchema, updateEngineSchema } from "./types";

export async function createEngine(
	state: CreateEngineFormState,
	formData: FormData
): Promise<Partial<CreateEngineFormState>> {
	const session = await verifySession();

	const validatedFields = CreateEngineSchema.safeParse({
		name: formData.get("name"),
		rarity: formData.get("rarity"),
		specialty: formData.get("specialty"),
		imageUrl: formData.get("imageUrl")
	});

	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors
		};
	}

	const response = await adminEngineService.createEngine(
		session.token,
		validatedFields.data
	);

	if (!response.ok) {
		return {
			message: response.error || "Failed to create engine",
			success: false
		};
	}

	return { success: true };
}

export async function updateEngine(
	_: UpdateEngineState | undefined,
	formData: FormData
): Promise<UpdateEngineState> {
	const session = await verifySession();

	const validatedFields = updateEngineSchema.safeParse({
		id: formData.get("id"),
		name: formData.get("name"),
		rarity: formData.get("rarity"),
		specialty: formData.get("specialty"),
		imageUrl: formData.get("imageUrl")
	});

	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors
		};
	}

	const response = await adminEngineService.updateEngine(
		session.token,
		validatedFields.data.id,
		validatedFields.data
	);

	if (!response.ok) {
		return {
			message: response.error || "Failed to update engine",
			success: false
		};
	}

	return { success: true };
}
