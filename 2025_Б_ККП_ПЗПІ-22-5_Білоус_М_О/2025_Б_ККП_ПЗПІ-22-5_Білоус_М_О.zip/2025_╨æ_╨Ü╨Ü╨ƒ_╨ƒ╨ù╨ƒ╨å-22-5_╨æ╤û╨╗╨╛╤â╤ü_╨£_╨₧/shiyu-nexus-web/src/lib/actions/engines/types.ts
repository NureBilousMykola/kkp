import { z } from "zod";
import { Specialties } from "@/lib/api/keys/Specialty";

export const CreateEngineSchema = z.object({
	name: z.string().min(1, "Name is required"),
	rarity: z.enum(["S", "A"], {
		required_error: "Rarity is required",
		invalid_type_error: "Invalid rarity"
	}),
	specialty: z.enum(Specialties, {
		required_error: "Specialty is required",
		invalid_type_error: "Invalid specialty"
	}),
	imageUrl: z.string().min(1, "Image URL is required")
});

type CreateEngineFormErrors = {
	name?: string[];
	rarity?: string[];
	specialty?: string[];
	imageUrl?: string[];
};

export type CreateEngineFormState =
	| {
			errors?: CreateEngineFormErrors;
			message?: string;
			success?: boolean;
	  }
	| undefined;

export const updateEngineSchema = CreateEngineSchema.extend({
	id: z.string().min(1, "ID is required")
});

export type UpdateEngineState =
| {
        errors?: CreateEngineFormErrors & { id?: string[] };
        message?: string;
        success?: boolean;
  }
| undefined;
