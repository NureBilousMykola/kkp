"use server";

import {
	adminFactionService,
	factionService
} from "../api/services/factions/service";
import type { IFaction } from "../api/models/IFaction";

export async function getFactions({ token }: { token: string }) {
	try {
		const response = await factionService.getFactions();

		if (!response.ok) {
			return { error: response.error || "Failed to fetch factions" };
		}

		return { factions: response.data };
	} catch (error) {
		return { error: "An unexpected error occurred" };
	}
}

export async function createFaction({
	token,
	faction
}: {
	token: string;
	faction: Partial<IFaction>;
}) {
	try {
		const response = await adminFactionService.createFaction(token, faction);

		if (!response.ok) {
			return { error: response.error || "Failed to create faction" };
		}

		return { faction: response.data };
	} catch (error) {
		return { error: "An unexpected error occurred" };
	}
}

export async function updateFaction({
	token,
	factionId,
	faction
}: {
	token: string;
	factionId: string;
	faction: Partial<IFaction>;
}) {
	try {
		const response = await adminFactionService.updateFaction(
			token,
			factionId,
			faction
		);

		if (!response.ok) {
			return { error: response.error || "Failed to update faction" };
		}

		return { faction: response.data };
	} catch (error) {
		return { error: "An unexpected error occurred" };
	}
}

export async function deleteFaction({
	token,
	factionId
}: {
	token: string;
	factionId: string;
}) {
	try {
		const response = await adminFactionService.deleteFaction(token, factionId);

		if (!response.ok) {
			return { error: response.error || "Failed to delete faction" };
		}

		return { success: true };
	} catch (error) {
		return { error: "An unexpected error occurred" };
	}
}
