"use server";

import { redirect } from "next/navigation";
import { authService } from "../api/services/auth/service";

export async function logout() {
	authService.logout();
	redirect("/auth/login");
}
