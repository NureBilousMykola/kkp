"use server";

import { verifySession } from "@/lib/utils/dal";
import {
	type UpdateUserFormState,
	type CreateUserFormState,
	UpdateUserFormSchema
} from "./types";
import { adminUserService } from "@/lib/api/services/users/service";

export async function createUser(
	state: CreateUserFormState,
	formData: FormData
): Promise<Partial<CreateUserFormState>> {
	// const session = await verifySession();

	// if (!session || !session?.role || session.role !== "admin") {
	// 	return { message: "You must be logged in to create an agent" };
	// }

	// const validatedFields = CreateUserFormSchema.safeParse({
	// 	username: formData.get("username"),
	// 	email: formData.get("email"),
	// 	role: formData.get("role"),
	// 	password: formData.get("password")
	// });

	// if (!validatedFields.success) {
	// 	return {
	// 		errors: validatedFields.error.flatten().fieldErrors,
	// 		success: false
	// 	};
	// }

	// const { username, email, role, password } = validatedFields.data;

	// const response = await adminUserService.createUser(session.token, {
	// 	username,
	// 	email,
	// 	role,
	// 	password
	// });

	// if (!response.ok) {
	// 	return {
	// 		message: response.error || "Failed to create user",
	// 		success: false
	// 	};
	// }

	return { success: true, message: "User created successfully" };
}

export async function updateUser(
	state: UpdateUserFormState,
	formData: FormData
): Promise<Partial<UpdateUserFormState>> {
	const session = await verifySession();

	if (!session || !session?.role || session.role !== "admin") {
		return { message: "You must be logged in to create an agent" };
	}

	const validatedFields = UpdateUserFormSchema.safeParse({
		id: formData.get("id"),
		role: formData.get("role"),
		permissions: formData.get("permissions")
	});

	if (!validatedFields.success) {
		return {
			errors: validatedFields.error.flatten().fieldErrors
		};
	}

	const { id, role, permissions } = validatedFields.data;

	const response = await Promise.all([
		adminUserService.updateUserPermissions(session.token, id, permissions),
		adminUserService.updateUserRole(session.token, id, role)
	]);

	for (const res of response) {
		if (!res.ok) {
			return { message: res.error || "Failed to update user" };
		}
	}

	return { success: true, message: "User updated successfully" };
}
