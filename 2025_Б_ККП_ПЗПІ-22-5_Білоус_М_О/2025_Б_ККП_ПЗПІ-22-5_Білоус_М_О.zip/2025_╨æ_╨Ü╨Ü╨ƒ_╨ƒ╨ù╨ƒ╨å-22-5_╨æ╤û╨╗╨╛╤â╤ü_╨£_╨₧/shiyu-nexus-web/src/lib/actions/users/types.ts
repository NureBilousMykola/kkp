import { z } from "zod";

export const CreateUserFormSchema = z.object({
	username: z.string().min(2, {
		message: "Username must be at least 2 characters."
	}),
	email: z.string().email({
		message: "Please enter a valid email address."
	}),
	role: z.enum(["user", "moderator", "admin"], {
		required_error: "Please select a role."
	}),
	password: z
		.string()
		.min(8, {
			message: "Password must be at least 8 characters."
		})
		.optional()
});

export type CreateUserFormState =
	| {
			errors?: {
				username?: string[];
				email?: string[];
				role?: string[];
				permissions?: string[];
				password?: string[];
			};
			message?: string;
			success?: boolean;
	  }
	| undefined;

export const UpdateUserFormSchema = z.object({
	id: z.string(),
	role: z.enum(["user", "moderator", "admin"], {
		required_error: "Please select a role."
	}),
	permissions: z.array(z.string(), {
		required_error: "Please select at least one permission."
	})
});

export type UpdateUserFormState =
	| {
			errors?: {
				id?: string[];
				role?: string[];
				permissions?: string[];
			};
			message?: string;
			success?: boolean;
	  }
	| undefined;
