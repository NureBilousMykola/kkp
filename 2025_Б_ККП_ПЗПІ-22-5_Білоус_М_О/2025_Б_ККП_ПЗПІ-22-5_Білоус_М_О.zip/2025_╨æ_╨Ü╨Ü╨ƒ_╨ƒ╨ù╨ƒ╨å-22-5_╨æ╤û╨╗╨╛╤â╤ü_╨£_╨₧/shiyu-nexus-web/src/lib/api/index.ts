export interface ApiResponse<T> {
	ok: boolean;
	status: number;
	error: string | null;
	data: T | null;
}

async function handleResponse<R>(response: Response): Promise<ApiResponse<R>> {
	if (!response.ok) {
		return {
			data: null,
			status: response.status,
			ok: false,
			error: await response.json().then((json) => json.message)
		};
	}

	try {
		return {
			data: await response.json(),
			status: response.status,
			ok: true,
			error: null
		};
	} catch (error) {
		return {
			data: null,
			status: response.status,
			ok: false,
			error: "Failed to parse response"
		};
	}
}

type RequestParameters<B> = [
	url: `/api/${string}`,
	options?: {
		jwt?: string | undefined;
		query?: Record<string, string> | undefined;
		body?: Partial<B> | undefined;
		requestOptions?: RequestInit | undefined;
	}
];

async function makeRequest<B, R>(
	method: "GET" | "POST" | "PATCH" | "DELETE",
	...[url, options = {}]: RequestParameters<B>
) {
	const queryString =
		options.query && Object.keys(options.query).length !== 0
			? `?${new URLSearchParams(options.query).toString()}`
			: "";

	const response = await fetch(
		`${process.env.NEXT_PUBLIC_API_URL}${url.replace("/api/", "/")}${queryString}`,
		{
			method: method,
			credentials: "include",
			...(options.body && { body: JSON.stringify(options.body) }),
			headers: {
				"Content-type": "application/json; charset=UTF-8",
				...(options.jwt && { Authorization: `Bearer ${options.jwt}` })
			},
			...options.requestOptions
		}
	);

	return handleResponse<R>(response);
}

export async function get<R>(...params: RequestParameters<undefined>) {
	return makeRequest<undefined, R>("GET", ...params);
}

export async function post<B, R>(...params: RequestParameters<B>) {
	return makeRequest<B, R>("POST", ...params);
}

export async function patch<B, R>(...params: RequestParameters<B>) {
	return makeRequest<B, R>("PATCH", ...params);
}

export async function remove<R>(...params: RequestParameters<undefined>) {
	return makeRequest<undefined, R>("DELETE", ...params);
}
