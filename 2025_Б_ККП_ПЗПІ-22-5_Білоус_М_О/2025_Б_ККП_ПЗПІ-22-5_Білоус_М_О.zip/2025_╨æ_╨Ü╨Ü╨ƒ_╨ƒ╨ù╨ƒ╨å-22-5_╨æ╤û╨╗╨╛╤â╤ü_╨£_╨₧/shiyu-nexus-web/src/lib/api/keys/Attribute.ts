export const Attributes = [
	"physical",
	"fire",
	"ice",
	"ether",
	"electric",
	"frost"
] as const;

export type Attribute = (typeof Attributes)[number];
