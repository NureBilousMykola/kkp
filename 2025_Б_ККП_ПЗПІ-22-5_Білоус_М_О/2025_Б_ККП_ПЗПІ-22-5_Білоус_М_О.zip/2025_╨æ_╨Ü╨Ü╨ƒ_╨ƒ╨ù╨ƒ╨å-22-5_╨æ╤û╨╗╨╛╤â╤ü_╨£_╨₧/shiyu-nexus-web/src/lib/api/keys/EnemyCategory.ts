export const EnemyCategories = [
	"ether_mutants",
	"thugs",
	"corrupted",
	"rabel_soldiers",
	"special"
] as const;

export type EnemyCategory = (typeof EnemyCategories)[number];
