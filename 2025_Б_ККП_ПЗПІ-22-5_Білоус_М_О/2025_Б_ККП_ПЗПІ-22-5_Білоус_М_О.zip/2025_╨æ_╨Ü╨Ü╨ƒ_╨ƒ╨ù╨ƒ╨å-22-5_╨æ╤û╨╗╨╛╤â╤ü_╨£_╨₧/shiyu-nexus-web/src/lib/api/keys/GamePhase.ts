export type GamePhase =
	| "ban"
	| "pick"
	| "preban"
	| "stage_ban"
	| "stage_pick"
	| "room_assignment";
