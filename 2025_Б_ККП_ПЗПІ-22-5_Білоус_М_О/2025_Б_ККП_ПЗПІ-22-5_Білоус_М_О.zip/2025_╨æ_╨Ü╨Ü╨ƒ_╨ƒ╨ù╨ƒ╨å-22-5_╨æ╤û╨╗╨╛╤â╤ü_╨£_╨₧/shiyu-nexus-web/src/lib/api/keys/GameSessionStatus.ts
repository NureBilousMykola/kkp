export type GameSessionStatus =
	| "waiting"
	| "stage_banning"
	| "prebanning"
	| "in_progress"
	| "finished";
