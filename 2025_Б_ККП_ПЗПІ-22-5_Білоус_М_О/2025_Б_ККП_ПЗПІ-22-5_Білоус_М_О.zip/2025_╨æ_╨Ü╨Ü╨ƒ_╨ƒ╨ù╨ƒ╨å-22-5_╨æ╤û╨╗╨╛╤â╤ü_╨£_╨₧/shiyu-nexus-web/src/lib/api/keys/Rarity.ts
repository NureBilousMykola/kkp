export const Rarities = ["B", "A", "S"] as const;
export type Rarity = (typeof Rarities)[number];
