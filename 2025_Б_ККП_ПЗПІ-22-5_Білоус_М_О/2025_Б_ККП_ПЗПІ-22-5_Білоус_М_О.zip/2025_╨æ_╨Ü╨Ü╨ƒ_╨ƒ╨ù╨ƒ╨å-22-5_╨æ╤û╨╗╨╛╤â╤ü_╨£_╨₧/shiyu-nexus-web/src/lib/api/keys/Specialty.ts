export const Specialties = [
	"attack",
	"anomaly",
	"defense",
	"stun",
	"support"
] as const;

export type Specialty = (typeof Specialties)[number];
