export const UserRoles = ["user", "moderator", "admin"] as const;
export type UserRole = (typeof UserRoles)[number];
