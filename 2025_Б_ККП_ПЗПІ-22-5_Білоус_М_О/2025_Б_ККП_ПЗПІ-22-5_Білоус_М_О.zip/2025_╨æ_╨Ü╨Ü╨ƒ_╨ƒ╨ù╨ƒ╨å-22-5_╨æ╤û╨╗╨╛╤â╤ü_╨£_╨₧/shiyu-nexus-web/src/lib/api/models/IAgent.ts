import type { Attribute } from "../keys/Attribute";
import type { Rarity } from "../keys/Rarity";
import type { Specialty } from "../keys/Specialty";

export interface IAgent {
	_id: string;
	name: string;
	fullName: string;
	normalizedName: string;
	isReleased: boolean;
	isLimited: boolean;
	rarity: Rarity;
	specialty: Specialty;
	attribute: Attribute;
	faction: string;
	imageUrl?: string;
	iconUrl?: string;
}
