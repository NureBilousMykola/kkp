export interface IBangboo {
	_id: string;
	name: string;
	normalizedName: string;
	rarity: string;
	imageUrl?: string;
}
