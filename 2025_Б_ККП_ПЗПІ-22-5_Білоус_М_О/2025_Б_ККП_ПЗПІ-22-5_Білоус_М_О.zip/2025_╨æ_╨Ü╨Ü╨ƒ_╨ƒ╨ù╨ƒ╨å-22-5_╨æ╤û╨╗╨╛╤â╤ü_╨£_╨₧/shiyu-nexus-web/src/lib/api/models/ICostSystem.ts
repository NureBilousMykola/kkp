import type { IAgent } from "./IAgent";
import type { IEngine } from "./IEngine";
import type { IUser } from "./IUser";

export interface IAgentCost {
	agent: IAgent | string;
	mindscapeCosts: Map<number, number>;
}

export interface IEngineCost {
	engine: IEngine | string;
	ascensionCosts: Map<number, number>;
}

export interface ICostSystem {
	_id: string;
	name: string;
	description?: string;
	agentCosts: IAgentCost[];
	engineCosts: IEngineCost[];
	isDefault: boolean;
	createdBy: IUser | string;
	createdAt: Date;
	updatedAt: Date;
}

export interface CreateCostSystemRequest {
	name: string;
	description?: string;
	agentCosts?: {
		agent: string;
		mindscapeCosts: Record<number, number>;
	}[];
	engineCosts?: {
		engine: string;
		ascensionCosts: Record<number, number>;
	}[];
	isDefault?: boolean;
}

export interface UpdateCostSystemRequest
	extends Partial<CreateCostSystemRequest> {}

export interface QueryCostSystemRequest {
	search?: string;
	isDefault?: boolean;
	offset?: number;
	limit?: number;
}

export interface CloneCostSystemRequest {
	name: string;
}
