import type { Attribute } from "../keys/Attribute";

export interface IEnemy {
	_id: string;
	name: string;
	normalizedName: string;
	category: string;
	description?: string;
	weaknessAttributes: Attribute[];
	resistanceAttributes: Attribute[];
	imageUrl?: string;
}
