import type { Rarity } from "../keys/Rarity";
import type { Specialty } from "../keys/Specialty";
import type { IAgent } from "./IAgent";

export interface IEngine {
	_id: string;
	name: string;
	normalizedName: string;
	rarity: Rarity;
	specialty: Specialty;
	isCraftable: boolean;
	isEventLimited: boolean;
	signatureAgent?: IAgent;
	maxAscension: number;
	imageUrl?: string;
}
