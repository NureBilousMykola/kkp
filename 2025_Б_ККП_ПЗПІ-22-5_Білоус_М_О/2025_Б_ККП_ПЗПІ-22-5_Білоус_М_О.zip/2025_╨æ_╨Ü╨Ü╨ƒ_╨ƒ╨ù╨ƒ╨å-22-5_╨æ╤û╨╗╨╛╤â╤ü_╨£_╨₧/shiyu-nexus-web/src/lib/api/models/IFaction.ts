export interface IFaction {
	_id: string;
	name: string;
	normalizedName: string;
	iconUrl?: string;
}
