export interface ISave {
	_id: string;
	name: string;
	description: string;
	agents: string[];
	createdAt: Date;
	updatedAt: Date;
}
