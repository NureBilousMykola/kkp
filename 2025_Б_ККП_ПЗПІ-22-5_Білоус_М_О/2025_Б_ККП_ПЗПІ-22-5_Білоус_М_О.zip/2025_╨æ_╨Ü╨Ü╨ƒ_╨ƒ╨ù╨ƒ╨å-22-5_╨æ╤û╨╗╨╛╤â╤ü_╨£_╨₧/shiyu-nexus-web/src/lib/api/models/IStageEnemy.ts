import type { IEnemy } from "./IEnemy";

export interface IStageEnemy {
	_id: string;
	stageId: number;
	roomId: number;
	enemies: {
		_id?: string; // MongoDB subdocument ID
		enemyId: string | IEnemy; // Can be ObjectId string or populated IEnemy object
		level: number;
		enemy?: IEnemy; // For backward compatibility
	}[];
	createdAt?: string;
	updatedAt?: string;
}
