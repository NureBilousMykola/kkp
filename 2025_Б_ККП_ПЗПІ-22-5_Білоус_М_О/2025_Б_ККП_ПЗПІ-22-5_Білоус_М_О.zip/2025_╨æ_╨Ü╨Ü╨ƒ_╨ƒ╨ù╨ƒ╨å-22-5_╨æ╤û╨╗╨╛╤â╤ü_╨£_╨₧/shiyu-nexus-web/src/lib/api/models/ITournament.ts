import type { IDraftPreset } from "./game/IDraftPreset";
import type { IUser } from "./IUser";

export enum TournamentStatus {
	REGISTRATION = "registration",
	ONGOING = "ongoing",
	COMPLETED = "completed",
	CANCELLED = "cancelled"
}

export enum TournamentFormat {
	SINGLE_ELIMINATION = "single_elimination",
	DOUBLE_ELIMINATION = "double_elimination",
	ROUND_ROBIN = "round_robin",
	SWISS = "swiss"
}

export interface TournamentRegistration {
	userId: IUser | string;
	agentSaveId: string;
	isCheckedIn: boolean;
	registeredAt: Date;
	checkedInAt?: Date;
	totalAgentCost: number;
	isEliminated: boolean;
	inLosersBracket: boolean;
}

export interface TournamentMatch {
	_id: string;
	matchNumber: number;
	round: number;
	player1Id?: IUser | string;
	player2Id?: IUser | string;
	draftSessionId?: string;
	winner?: number;
	isBye: boolean;
	isCompleted: boolean;
	isReady: boolean;
	bracket?: "winners" | "losers" | "finals" | null;
	isResetMatch?: boolean;
	scheduledTime?: Date;
	startTime?: Date;
	endTime?: Date;
}

export interface SwissPlayerRecord {
	userId: IUser | string;
	wins: number;
	losses: number;
	byes: number;
	score: number;
	opponents: (IUser | string)[];
}

export interface ITournament {
	_id: string;
	name: string;
	description?: string;
	draftPresetId: IDraftPreset | string;
	organizerId: IUser | string;
	moderatorIds?: (IUser | string)[];
	status: TournamentStatus;
	format: TournamentFormat;
	maxParticipants: number;
	bestOf: number;
	registrationStartTime: Date;
	registrationEndTime: Date;
	tournamentStartTime: Date;
	tournamentEndTime?: Date;
	registrations: TournamentRegistration[];
	matches: TournamentMatch[];
	bracketsGenerated: boolean;
	requireCheckin: boolean;
	checkinStartTime?: Date;
	checkinEndTime?: Date;
	isPublic: boolean;
	password?: string;
	swissRecords?: SwissPlayerRecord[];
}
