import type { UserRole } from "../keys/UserRole";
import type { IAgent } from "./IAgent";
import type { IBangboo } from "./IBangboo";
import type { IEngine } from "./IEngine";
import type { ISave } from "./ISave";

export interface MyAgent {
	agent: IAgent;
	level: number;
	mindscape: number;
}

export interface MyEngine {
	engine: IEngine;
	level: number;
	ascension: number;
}

export interface MyBangboo {
	bangboo: IBangboo;
	level: number;
	ascension: number;
}

export interface IUser {
	_id: string;
	username: string;
	email: string;
	passwordHash?: string;

	role: UserRole;
	permissions: string[];

	token: string;

	discordId?: string;
	discordUsername?: string;
	discordAvatar?: string;
	discordAccessToken?: string;
	discordRefreshToken?: string;

	ownedAgents: MyAgent[];
	ownedEngines: MyEngine[];
	ownedBangboos: MyBangboo[];
	agentSaves: ISave[];
}
