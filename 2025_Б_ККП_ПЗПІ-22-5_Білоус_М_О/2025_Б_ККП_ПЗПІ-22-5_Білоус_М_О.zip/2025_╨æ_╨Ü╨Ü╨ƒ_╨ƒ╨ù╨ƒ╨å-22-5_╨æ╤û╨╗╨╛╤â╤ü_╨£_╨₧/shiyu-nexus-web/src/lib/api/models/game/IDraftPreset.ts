import type { Attribute } from "../../keys/Attribute";
import type { GamePhase } from "../../keys/GamePhase";
import type { Specialty } from "../../keys/Specialty";
import type { IAgent } from "../IAgent";
import type { IEngine } from "../IEngine";
import type { IUser } from "../IUser";

export interface RoomConstraint {
	roomId: number;
	maxAgents?: number;
	bannedAgents: string[];
	bannedSpecialties?: Specialty[];
	bannedAttributes?: Attribute[];
	requiredSpecialties?: Specialty[];
	requiredAttributes?: Attribute[];
}

export interface StageConstraint {
	stageId: number;
	roomConstraints: RoomConstraint[];
}

export interface AgentCost {
	agent: IAgent | string;
	mindscapeCosts: Map<number, number>;
}

export interface EngineCost {
	engine: IEngine | string;
	ascensionCosts: Map<number, number>;
}

export interface DraftPhase {
	type: GamePhase;
	player: 1 | 2;
	count: number;
	timeLimit: number;
}

export interface GeneralRules {
	minCharacters: number;
	maxCharacters: number;
	minCost: number;
	maxCost: number;
	allowedStages: number[];
	costDifferenceForPreban: number;
	allowMirrorPicks: boolean;
	restarts: {
		freeRestarts: number;
		paidRestarts: number;
		timePenalty: number;
	};
}

export interface IDraftPreset {
	_id: string;
	name: string;
	description?: string;
	rules: GeneralRules;
	constraints: StageConstraint[];
	pickableAgents?: string[];
	agentCosts: AgentCost[];
	engineCosts: EngineCost[];
	draftFlow: DraftPhase[];
	createdBy?: IUser | string;
	version: number;
	createdAt?: Date;
	updatedAt?: Date;
}

// Legacy interfaces for backward compatibility
export interface IGameRoomConstraint extends RoomConstraint {}
export interface IGameAgentCost extends AgentCost {}
export interface IGameEngineCost extends EngineCost {}
export interface IGamePhase extends DraftPhase {}
export interface IGameRules extends GeneralRules {}
export interface IGamePreset extends IDraftPreset {}
