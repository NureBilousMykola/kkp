import type { IEngine } from "../IEngine";

export interface IGameEngine {
	engine: IEngine;
	cost: number;
	costReason: string;
}
