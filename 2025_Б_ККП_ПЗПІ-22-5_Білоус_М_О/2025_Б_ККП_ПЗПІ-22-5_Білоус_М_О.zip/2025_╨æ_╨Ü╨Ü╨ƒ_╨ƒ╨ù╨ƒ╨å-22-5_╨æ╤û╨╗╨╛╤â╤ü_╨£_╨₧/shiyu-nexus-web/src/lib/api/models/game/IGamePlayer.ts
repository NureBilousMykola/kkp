export interface IGamePlayer {
	userId: string;
	team: number;
	isReady: boolean;
	selectedCharacters: string[];
	selectedEngines: string[];
	roomAssignments: Record<string, string[]>;
	banList: string[];
	bannedStages: number[];
	prebannedAgents: string[];
	engineAssignments: Record<string, string>;
	totalAgentCost: number;
	agentSaveId?: string;
	agentSaveAgents?: string[];
}
