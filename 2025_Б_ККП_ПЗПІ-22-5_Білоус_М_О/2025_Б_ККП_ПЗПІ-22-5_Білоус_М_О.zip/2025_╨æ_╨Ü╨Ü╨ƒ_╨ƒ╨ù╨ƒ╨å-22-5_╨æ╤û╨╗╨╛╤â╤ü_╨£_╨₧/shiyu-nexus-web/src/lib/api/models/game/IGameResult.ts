export interface IGameResult {
	gameNumber: number;
	stageId: number;
	winner: number;
	timeElapsed: number;
	freeRestartsUsed: Record<string, number>;
	paidRestartsUsed: Record<string, number>;
	notes?: string;
}
