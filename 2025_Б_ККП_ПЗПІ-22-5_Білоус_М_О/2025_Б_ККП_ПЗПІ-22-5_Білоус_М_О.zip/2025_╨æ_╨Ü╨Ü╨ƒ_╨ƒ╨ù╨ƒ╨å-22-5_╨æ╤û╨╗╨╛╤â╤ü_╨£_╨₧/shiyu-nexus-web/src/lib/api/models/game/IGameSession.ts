import type { GamePhase } from "../../keys/GamePhase";
import type { GameSessionStatus } from "../../keys/GameSessionStatus";
import type { IGamePlayer } from "./IGamePlayer";
import type { IGameResult } from "./IGameResult";

export interface IGameSession {
	_id: string;
	presetId: string;

	hostId: string;
	judgeId?: string;
	players: IGamePlayer[];
	spectators: string[];

	title?: string;
	description?: string;
	password?: string;

	status: GameSessionStatus;
	stage: number;
	currentPhase: number;
	currentPhaseType: GamePhase;
	currentTeam: number;
	timeLeft: number;

	startTime?: Date;
	endTime?: Date;

	availableStages: number[];

	prebansCalculated: boolean;

	engineAssignmentComplete: boolean;
	gameResults: IGameResult[];
	numberOfGames: number;
	currentGameNumber: number;
	readyForNextGame: boolean;
	allowSpectators: boolean;
}
