import { get, patch, post, remove } from "../..";
import type { IAgent } from "../../models/IAgent";
import type { CreateAgentBody, getAgentsFilters } from "./types";

export const adminAgentService = {
	createAgent: (jwt: string, agent: CreateAgentBody) => {
		return post<CreateAgentBody, IAgent>("/api/agents", { jwt, body: agent });
	},

	deleteAgent: (jwt: string, id: string) => {
		return remove<IAgent>(`/api/agents/${id}`, { jwt });
	},

	updateAgent: (jwt: string, id: string, agent: CreateAgentBody) => {
		return patch<CreateAgentBody, IAgent>(`/api/agents/${id}`, {
			jwt,
			body: agent
		});
	}
};

export const agentService = {
	getAgents: (filters: getAgentsFilters = {}) => {
		return get<IAgent[]>("/api/agents", { query: filters });
	},

	getAgent: (id: string) => {
		return get<IAgent>(`/api/agents/${id}`);
	}
};
