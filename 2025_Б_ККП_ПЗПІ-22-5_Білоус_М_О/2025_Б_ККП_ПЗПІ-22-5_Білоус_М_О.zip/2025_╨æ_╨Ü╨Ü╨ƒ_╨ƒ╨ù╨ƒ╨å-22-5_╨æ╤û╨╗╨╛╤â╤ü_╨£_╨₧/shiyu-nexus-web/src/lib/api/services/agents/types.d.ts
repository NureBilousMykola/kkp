export interface CreateAgentBody {
	name: string;
	fullName: string;
	normalizedName: string;
	isReleased: boolean;
	isLimited: boolean;
	rarity: string;
	specialty: string;
	attribute: string;
	faction: string;
	hasEngineCostException?: boolean;
	imageUrl?: string;
	iconUrl?: string;
}

export type getAgentsFilters = {
	rarity?: Rarity;
	specialty?: Specialty;
	attribute?: Attribute;
	faction?: IFaction["_id"];
	isReleased?: "true" | "false";
	isLimited?: "true" | "false";
};
