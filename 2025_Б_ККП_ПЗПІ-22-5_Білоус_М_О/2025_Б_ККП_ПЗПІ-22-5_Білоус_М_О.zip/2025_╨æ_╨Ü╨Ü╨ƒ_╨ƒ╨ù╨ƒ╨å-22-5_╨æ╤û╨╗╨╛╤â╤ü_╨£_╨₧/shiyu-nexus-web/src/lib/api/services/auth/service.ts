import { post } from "../..";
import type { IUser } from "../../models/IUser";

export const authService = {
	login: async (username: string, password: string) => {
		const response = post<{ username: string; password: string }, IUser>(
			"/api/auth/login",
			{ body: { username, password } }
		);

		return response;
	},

	register: (email: string, username: string, password: string) => {
		const response = post<
			{ email: string; username: string; password: string },
			IUser
		>("/api/auth/register", {
			body: { email, username, password }
		});

		return response;
	},

	logout: () => {
		const response = post<null, { message: string }>("/api/auth/logout");

		return response;
	}
};
