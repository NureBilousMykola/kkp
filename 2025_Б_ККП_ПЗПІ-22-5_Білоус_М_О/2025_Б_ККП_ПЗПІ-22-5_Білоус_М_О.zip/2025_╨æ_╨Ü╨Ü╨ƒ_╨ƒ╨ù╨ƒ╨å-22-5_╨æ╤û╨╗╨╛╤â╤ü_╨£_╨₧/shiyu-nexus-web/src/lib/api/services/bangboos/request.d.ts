import type { Rarity } from "../../keys/Rarity";

export interface CreateBangbooBody {
	name: string;
	normalizedName: string;
	rarity: Rarity;
	imageUrl?: string;
}

export interface UpdateBangbooBody {
	name?: string;
	normalizedName?: string;
	rarity?: Rarity;
	imageUrl?: string;
}

export interface AddMyBangbooBody {
	bangbooId: string;
	level: number;
	ascension: number;
}

export interface UpdateMyBangbooBody {
	level?: number;
	ascension?: number;
}

export interface AddMultipleBangboosBody {
	bangboos: {
		bangbooId: string;
		level: number;
		ascension: number;
	}[];
}
