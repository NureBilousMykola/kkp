import { get, patch, post, remove } from "../..";
import type { Rarity } from "../../keys/Rarity";
import type { IBangboo } from "../../models/IBangboo";
import type { IUser } from "../../models/IUser";
import type {
	AddMultipleBangboosBody,
	AddMyBangbooBody,
	CreateBangbooBody,
	UpdateBangbooBody,
	UpdateMyBangbooBody
} from "./request";

export const adminBangbooService = {
	createBangboo: (jwt: string, body: CreateBangbooBody) => {
		return post<CreateBangbooBody, IBangboo>("/api/bangboos", {
			jwt,
			body
		});
	},

	updateBangboo: (jwt: string, bangbooId: string, body: UpdateBangbooBody) => {
		return patch<UpdateBangbooBody, IBangboo>(`/api/bangboos/${bangbooId}`, {
			jwt,
			body
		});
	},

	deleteBangboo: (jwt: string, bangbooId: string) => {
		return remove<IBangboo>(`/api/bangboos/${bangbooId}`, { jwt });
	}
};

export const bangbooService = {
	getBangboos: (filters?: { rarity?: Rarity }) => {
		return get<IBangboo[]>("/api/bangboos", { query: filters });
	},

	getBangboo: (bangbooId: string) => {
		return get<IBangboo>(`/api/bangboos/${bangbooId}`);
	}
};

export const myBangbooService = {
	addMyBangboo: (jwt: string, body: AddMyBangbooBody) => {
		return post<AddMyBangbooBody, IUser>("/api/users/inventory/bangboos", {
			jwt,
			body
		});
	},

	updateMyBangboo: (
		jwt: string,
		bangbooId: string,
		body: UpdateMyBangbooBody
	) => {
		return patch<UpdateMyBangbooBody, IUser>(
			`/api/users/inventory/bangboos/${bangbooId}`,
			{ jwt, body }
		);
	},

	removeMyBangboo: (jwt: string, bangbooId: string) => {
		return remove<IUser>(`/api/users/inventory/bangboos/${bangbooId}`, { jwt });
	},

	addMultipleBangboos: (jwt: string, body: AddMultipleBangboosBody) => {
		return post<AddMultipleBangboosBody, IUser>(
			"/api/users/inventory/bangboos/batch",
			{ jwt, body }
		);
	}
};
