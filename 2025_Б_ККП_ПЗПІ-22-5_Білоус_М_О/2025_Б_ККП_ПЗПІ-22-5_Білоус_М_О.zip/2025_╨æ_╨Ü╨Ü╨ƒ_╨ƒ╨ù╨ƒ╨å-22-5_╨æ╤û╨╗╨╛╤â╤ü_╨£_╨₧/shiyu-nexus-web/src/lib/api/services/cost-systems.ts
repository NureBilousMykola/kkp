import { get, post, patch, remove } from "../index";
import type {
	ICostSystem,
	CreateCostSystemRequest,
	UpdateCostSystemRequest,
	QueryCostSystemRequest,
	CloneCostSystemRequest
} from "../models/ICostSystem";

class CostSystemsService {
	/**
	 * Get all cost systems
	 */
	async getCostSystems(token: string, query?: QueryCostSystemRequest) {
		return get<ICostSystem[]>("/api/cost-systems", {
			jwt: token,
			query: query
				? {
						...(query.search && { search: query.search }),
						...(query.isDefault !== undefined && {
							isDefault: query.isDefault.toString()
						}),
						...(query.offset !== undefined && {
							offset: query.offset.toString()
						}),
						...(query.limit !== undefined && { limit: query.limit.toString() })
					}
				: undefined
		});
	}

	/**
	 * Get a specific cost system by ID
	 */
	async getCostSystem(token: string, id: string) {
		return get<ICostSystem>(`/api/cost-systems/${id}`, {
			jwt: token
		});
	}

	/**
	 * Get the default cost system
	 */
	async getDefaultCostSystem(token: string) {
		return get<ICostSystem>("/api/cost-systems/default", {
			jwt: token
		});
	}

	/**
	 * Create a new cost system
	 */
	async createCostSystem(token: string, data: CreateCostSystemRequest) {
		return post<CreateCostSystemRequest, ICostSystem>("/api/cost-systems", {
			jwt: token,
			body: data
		});
	}

	/**
	 * Update an existing cost system
	 */
	async updateCostSystem(
		token: string,
		id: string,
		data: UpdateCostSystemRequest
	) {
		return patch<UpdateCostSystemRequest, ICostSystem>(
			`/api/cost-systems/${id}`,
			{
				jwt: token,
				body: data
			}
		);
	}

	/**
	 * Delete a cost system
	 */
	async deleteCostSystem(token: string, id: string) {
		return remove<void>(`/api/cost-systems/${id}`, {
			jwt: token
		});
	}

	/**
	 * Clone a cost system
	 */
	async cloneCostSystem(
		token: string,
		id: string,
		data: CloneCostSystemRequest
	) {
		return post<CloneCostSystemRequest, ICostSystem>(
			`/api/cost-systems/${id}/clone`,
			{
				jwt: token,
				body: data
			}
		);
	}

	/**
	 * Set a cost system as default
	 */
	async setDefaultCostSystem(token: string, id: string) {
		return patch<Record<string, never>, ICostSystem>(
			`/api/cost-systems/${id}/set-default`,
			{
				jwt: token,
				body: {}
			}
		);
	}
}

export const costSystemsService = new CostSystemsService();
