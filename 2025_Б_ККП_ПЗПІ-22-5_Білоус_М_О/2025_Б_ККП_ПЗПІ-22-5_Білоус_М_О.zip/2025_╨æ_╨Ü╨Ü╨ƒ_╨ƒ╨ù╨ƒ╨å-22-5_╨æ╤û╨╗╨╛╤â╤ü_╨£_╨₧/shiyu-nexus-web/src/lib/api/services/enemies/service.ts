import { get, patch, post, remove } from "../..";
import type { IEnemy } from "../../models/IEnemy";
import type { IStageEnemy } from "../../models/IStageEnemy";

type getEnemiesFilters = {
	category?: string;
	name?: string;
	attribute?: string;
};

type getStageEnemiesFilters = {
	stageId?: number;
	roomId?: number;
	minLevel?: number;
	maxLevel?: number;
};

export const adminEnemyService = {
	createEnemy: (jwt: string, enemy: Partial<IEnemy>) => {
		return post<IEnemy, IEnemy>("/api/enemies", { jwt, body: enemy });
	},

	deleteEnemy: (jwt: string, id: string) => {
		return remove<IEnemy>(`/api/enemies/${id}`, { jwt });
	},

	updateEnemy: (jwt: string, id: string, enemy: Partial<IEnemy>) => {
		return patch<IEnemy, IEnemy>(`/api/enemies/${id}`, { jwt, body: enemy });
	},

	createStageEnemy: (jwt: string, stageEnemy: Partial<IStageEnemy>) => {
		return post<IStageEnemy, IStageEnemy>("/api/enemies/stage", {
			jwt,
			body: stageEnemy
		});
	},

	updateStageEnemy: (
		jwt: string,
		id: string,
		stageEnemy: Partial<IStageEnemy>
	) => {
		return patch<IStageEnemy, IStageEnemy>(`/api/enemies/stage/${id}`, {
			jwt,
			body: stageEnemy
		});
	},

	removeStageEnemy: (jwt: string, id: string) => {
		return remove<IStageEnemy>(`/api/enemies/stage/${id}`, { jwt });
	}
};

export const enemyService = {
	getEnemies: (filters: getEnemiesFilters = {}) => {
		return get<IEnemy[]>("/api/enemies", { query: filters });
	},

	getEnemy: (id: string) => {
		return get<IEnemy>(`/api/enemies/${id}`);
	},

	getStageEnemies: (filters: getStageEnemiesFilters = {}) => {
		// Convert number parameters to strings for query and only include defined values
		const queryParams: Record<string, string> = {};
		if (filters.stageId !== undefined)
			queryParams.stageId = filters.stageId.toString();
		if (filters.roomId !== undefined)
			queryParams.roomId = filters.roomId.toString();
		if (filters.minLevel !== undefined)
			queryParams.minLevel = filters.minLevel.toString();
		if (filters.maxLevel !== undefined)
			queryParams.maxLevel = filters.maxLevel.toString();

		// Always pass query object to be consistent, even if empty
		return get<IStageEnemy[]>("/api/enemies/stage", { query: queryParams });
	},

	getStageEnemy: (id: string) => {
		return get<IStageEnemy>(`/api/enemies/stage/${id}`);
	},

	getEnemiesByAttribute: (attribute: string, isWeakness = true) => {
		const type = isWeakness ? "weakness" : "resistance";
		return get<IEnemy[]>(`/api/enemies/filter/attribute/${attribute}`, {
			query: { type }
		});
	},

	getStageEnemiesByLevel: (minLevel = 1, maxLevel = 100) => {
		return get<IStageEnemy[]>("/api/enemies/stage/filter/level", {
			query: { minLevel: minLevel.toString(), maxLevel: maxLevel.toString() }
		});
	},

	getEnemiesForStage: (stageId: number) => {
		return get<IStageEnemy[]>(`/api/enemies/stage/filter/stage/${stageId}`);
	}
};
