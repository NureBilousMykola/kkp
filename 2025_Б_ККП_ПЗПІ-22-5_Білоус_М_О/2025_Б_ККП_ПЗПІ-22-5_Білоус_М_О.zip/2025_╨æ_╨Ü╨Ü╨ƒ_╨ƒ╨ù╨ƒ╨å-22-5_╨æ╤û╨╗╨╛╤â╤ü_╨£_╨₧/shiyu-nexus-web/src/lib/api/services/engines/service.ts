import { get, patch, post, remove } from "../..";
import type { Rarity } from "../../keys/Rarity";
import type { Specialty } from "../../keys/Specialty";
import type { IEngine } from "../../models/IEngine";

type getEnginesFilters = {
	rarity?: Rarity;
	specialty?: Specialty;
	isCraftable?: "true" | "false";
	isEventLimited?: "true" | "false";
	name?: string;
	signatureAgentId?: string;
};

export const adminEngineService = {
	createEngine: (jwt: string, engine: Partial<IEngine>) => {
		return post<IEngine, IEngine>("/api/engine", { jwt, body: engine });
	},

	deleteEngine: (jwt: string, id: string) => {
		return remove<IEngine>(`/api/engine/${id}`, { jwt });
	},

	updateEngine: (jwt: string, id: string, engine: Partial<IEngine>) => {
		return patch<IEngine, IEngine>(`/api/engine/${id}`, { jwt, body: engine });
	}
};

export const engineService = {
	getEngines: (filters: getEnginesFilters = {}) => {
		return get<IEngine[]>("/api/engines", { query: filters });
	},

	getEngine: (id: string) => {
		return get<IEngine>(`/api/engines/${id}`);
	}
};
