import { get, patch, post, remove } from "../..";
import type { IFaction } from "../../models/IFaction";

export const adminFactionService = {
	createFaction: (jwt: string, faction: Partial<IFaction>) => {
		return post<IFaction, IFaction>("/api/factions", { jwt, body: faction });
	},

	deleteFaction: (jwt: string, id: string) => {
		return remove<IFaction>(`/api/factions/${id}`, { jwt });
	},

	updateFaction: (jwt: string, id: string, faction: Partial<IFaction>) => {
		return patch<IFaction, IFaction>(`/api/factions/${id}`, {
			jwt,
			body: faction
		});
	}
};

export const factionService = {
	getFactions: () => {
		return get<IFaction[]>("/api/factions");
	},

	getFaction: (id: string) => {
		return get<IFaction>(`/api/factions/${id}`);
	},

	getFactionByName: (normalizedName: string) => {
		return get<IFaction>(`/api/factions/name/${normalizedName}`);
	}
};
