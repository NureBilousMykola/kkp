export interface CreateSessionBody {
	presetId: string;
	name: string;
	password?: string;
	agentSaveId?: string;
	allowSpectators?: boolean;
	numberOfGames?: number;
	requireJudge?: boolean;
}

export interface JoinSessionBody {
	team: number;
	password?: string;
	agentSaveId?: string;
}

export interface PickCharacterBody {
	characterId: string;
	engineId?: string;
}

export interface BanCharacterBody {
	characterId: string;
}

export interface BanStageBody {
	stageId: number;
}

export interface PrebanAgentBody {
	characterId: string;
}

export interface AssignRoomBody {
	roomId: number;
	characterIds: string[];
}

export interface AssignEngineBody {
	characterId: string;
	engineId: string;
}

export interface GameResultBody {
	gameNumber: number;
	stageId: number;
	winner: number;
	timeElapsed: number;
	freeRestartsUsed: Record<string, number>;
	paidRestartsUsed: Record<string, number>;
	notes?: string;
}
