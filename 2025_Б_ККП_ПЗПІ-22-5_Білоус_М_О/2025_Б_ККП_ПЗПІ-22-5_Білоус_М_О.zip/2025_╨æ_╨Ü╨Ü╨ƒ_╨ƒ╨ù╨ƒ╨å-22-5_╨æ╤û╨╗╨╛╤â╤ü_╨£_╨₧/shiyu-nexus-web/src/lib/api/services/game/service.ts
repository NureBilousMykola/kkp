import { get, post, remove } from "../..";
import type { IAgent } from "../../models/IAgent";
import type { IGameEngine } from "../../models/game/IGameEngine";
import type { IGameSession } from "../../models/game/IGameSession";
import type {
	AssignEngineBody,
	AssignRoomBody,
	BanCharacterBody,
	BanStageBody,
	CreateSessionBody,
	GameResultBody,
	JoinSessionBody,
	PickCharacterBody,
	PrebanAgentBody
} from "./request";

export const gameSessionService = {
	createSession: (jwt: string, body: CreateSessionBody) => {
		return post<CreateSessionBody, IGameSession>("/api/draft/sessions", {
			jwt,
			body
		});
	},

	getSession: (jwt: string, sessionId: string) => {
		return get<IGameSession>(`/api/draft/sessions/${sessionId}`, { jwt });
	},

	getAllSessions: (jwt: string) => {
		return get<IGameSession[]>("/api/draft/sessions", { jwt });
	},

	joinSession: (jwt: string, sessionId: string, body: JoinSessionBody) => {
		return post<JoinSessionBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/join`,
			{ jwt, body }
		);
	},

	leaveSession: (jwt: string, sessionId: string) => {
		return post<null, null>(`/api/draft/sessions/${sessionId}/leave`, { jwt });
	},

	setReady: (jwt: string, sessionId: string) => {
		return post<null, IGameSession>(`/api/draft/sessions/${sessionId}/ready`, {
			jwt
		});
	},

	// Draft Actions
	pickCharacter: (jwt: string, sessionId: string, body: PickCharacterBody) => {
		return post<PickCharacterBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/pick`,
			{ jwt, body }
		);
	},

	banCharacter: (jwt: string, sessionId: string, body: BanCharacterBody) => {
		return post<BanCharacterBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/ban`,
			{ jwt, body }
		);
	},

	banStage: (jwt: string, sessionId: string, body: BanStageBody) => {
		return post<BanStageBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/ban-stage`,
			{ jwt, body }
		);
	},

	prebanAgent: (jwt: string, sessionId: string, body: PrebanAgentBody) => {
		return post<PrebanAgentBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/preban`,
			{ jwt, body }
		);
	},

	assignRoom: (jwt: string, sessionId: string, body: AssignRoomBody) => {
		return post<AssignRoomBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/assign-room`,
			{ jwt, body }
		);
	},

	assignEngine: (jwt: string, sessionId: string, body: AssignEngineBody) => {
		return post<AssignEngineBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/assign-engine`,
			{ jwt, body }
		);
	},

	submitGameResult: (jwt: string, sessionId: string, body: GameResultBody) => {
		return post<GameResultBody, IGameSession>(
			`/api/draft/sessions/${sessionId}/game-result`,
			{ jwt, body }
		);
	},

	readyForNextGame: (jwt: string, sessionId: string) => {
		return post<null, IGameSession>(
			`/api/draft/sessions/${sessionId}/ready-next-game`,
			{ jwt }
		);
	},

	// Helpers
	getAvailableCharacters: (jwt: string, sessionId: string) => {
		return get<IAgent[]>(
			`/api/draft/sessions/${sessionId}/available-characters`,
			{ jwt }
		);
	},

	getAvailableEngines: (
		jwt: string,
		sessionId: string,
		characterId: string
	) => {
		return get<IGameEngine[]>(
			`/api/draft/sessions/${sessionId}/available-engines/${characterId}`,
			{ jwt }
		);
	},

	getAvailableStages: (jwt: string, sessionId: string) => {
		return get<number[]>(`/api/draft/sessions/${sessionId}/available-stages`, {
			jwt
		});
	},

	// Spectator
	addSpectator: (jwt: string, sessionId: string) => {
		return post<null, IGameSession>(
			`/api/draft/sessions/${sessionId}/spectator`,
			{ jwt }
		);
	},

	removeSpectator: (jwt: string, sessionId: string) => {
		return remove<IGameSession>(`/api/draft/sessions/${sessionId}/spectator`, {
			jwt
		});
	}
};
