import type {
	AgentCost,
	DraftPhase,
	EngineCost,
	GeneralRules,
	StageConstraint
} from "../../models/game/IDraftPreset";

export interface CreatePresetBody {
	name: string;
	description?: string;
	rules: GeneralRules;
	constraints: StageConstraint[];
	pickableAgents?: string[];
	agentCosts: AgentCost[];
	engineCosts: EngineCost[];
	draftFlow: DraftPhase[];
}

export interface UpdatePresetBody {
	name?: string;
	description?: string;
	rules?: Partial<GeneralRules>;
	constraints?: StageConstraint[];
	pickableAgents?: string[];
	agentCosts?: AgentCost[];
	engineCosts?: EngineCost[];
	draftFlow?: DraftPhase[];
	version?: number;
}
