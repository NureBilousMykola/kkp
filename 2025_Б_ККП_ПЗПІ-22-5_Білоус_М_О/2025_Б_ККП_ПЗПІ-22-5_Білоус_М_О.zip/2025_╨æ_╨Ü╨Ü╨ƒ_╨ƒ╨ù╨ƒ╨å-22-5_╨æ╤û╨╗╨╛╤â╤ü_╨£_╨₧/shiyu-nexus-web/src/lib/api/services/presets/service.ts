import { get, patch, post, remove } from "../..";
import type { IDraftPreset } from "../../models/game/IDraftPreset";
import type { CreatePresetBody, UpdatePresetBody } from "./request";

export const adminPresetService = {
	createPreset: (jwt: string, body: CreatePresetBody) => {
		return post<CreatePresetBody, IDraftPreset>("/api/presets", {
			jwt,
			body
		});
	},

	updatePreset: (jwt: string, presetId: string, body: UpdatePresetBody) => {
		return patch<UpdatePresetBody, IDraftPreset>(`/api/presets/${presetId}`, {
			jwt,
			body
		});
	},

	deletePreset: (jwt: string, presetId: string) => {
		return remove<IDraftPreset>(`/api/presets/${presetId}`, { jwt });
	},

	clonePreset: (jwt: string, presetId: string, name: string) => {
		return post<{ name: string }, IDraftPreset>(
			`/api/presets/${presetId}/clone`,
			{
				jwt,
				body: { name }
			}
		);
	}
};

export const presetService = {
	getPresets: () => {
		return get<IDraftPreset[]>("/api/presets");
	},

	getPreset: (presetId: string) => {
		return get<IDraftPreset>(`/api/presets/${presetId}`);
	},

	getMyPresets: (jwt: string) => {
		return get<IDraftPreset[]>("/api/presets/user/created", { jwt });
	}
};
