import type { TournamentFormat } from "../../models/ITournament";

export interface CreateTournamentBody {
	name: string;
	description?: string;
	draftPresetId: string;
	format: TournamentFormat;
	maxParticipants: number;
	bestOf: number;
	registrationStartTime: Date | string;
	registrationEndTime: Date | string;
	tournamentStartTime: Date | string;
	requireCheckin: boolean;
	checkinStartTime?: Date | string;
	checkinEndTime?: Date | string;
	isPublic: boolean;
	password?: string;
}

export interface UpdateTournamentBody {
	name?: string;
	description?: string;
	draftPresetId?: string;
	format?: TournamentFormat;
	maxParticipants?: number;
	bestOf?: number;
	registrationStartTime?: Date | string;
	registrationEndTime?: Date | string;
	tournamentStartTime?: Date | string;
	requireCheckin?: boolean;
	checkinStartTime?: Date | string;
	checkinEndTime?: Date | string;
	isPublic?: boolean;
	password?: string;
}

export interface RegisterTournamentBody {
	agentSaveId: string;
	password?: string;
}

export interface StartMatchBody {
	matchId: string;
}

export interface ReportMatchResultBody {
	matchId: string;
	winner: number;
}

export interface AddModeratorBody {
	userId: string;
}
