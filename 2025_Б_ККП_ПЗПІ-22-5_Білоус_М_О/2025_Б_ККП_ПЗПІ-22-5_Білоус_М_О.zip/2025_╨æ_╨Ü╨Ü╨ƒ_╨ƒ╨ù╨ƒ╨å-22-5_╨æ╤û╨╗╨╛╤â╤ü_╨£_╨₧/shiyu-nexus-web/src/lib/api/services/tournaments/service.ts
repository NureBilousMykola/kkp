import { get, patch, post, remove } from "../..";
import type { ITournament } from "../../models/ITournament";
import type {
	AddModeratorBody,
	CreateTournamentBody,
	RegisterTournamentBody,
	ReportMatchResultBody,
	StartMatchBody,
	UpdateTournamentBody
} from "./request";

export const tournamentService = {
	// Public tournament endpoints
	getAllTournaments: () => {
		return get<ITournament[]>("/api/tournaments");
	},

	getTournament: (tournamentId: string) => {
		return get<ITournament>(`/api/tournaments/${tournamentId}`);
	},

	// Participant endpoints
	registerForTournament: (
		jwt: string,
		tournamentId: string,
		body: RegisterTournamentBody
	) => {
		return post<RegisterTournamentBody, ITournament>(
			`/api/tournaments/${tournamentId}/register`,
			{ jwt, body }
		);
	},

	unregisterFromTournament: (jwt: string, tournamentId: string) => {
		return post<null, ITournament>(
			`/api/tournaments/${tournamentId}/unregister`,
			{ jwt }
		);
	},

	checkIn: (jwt: string, tournamentId: string) => {
		return post<null, ITournament>(
			`/api/tournaments/${tournamentId}/check-in`,
			{ jwt }
		);
	},

	// Organizer endpoints
	createTournament: (jwt: string, body: CreateTournamentBody) => {
		return post<CreateTournamentBody, ITournament>("/api/tournaments", {
			jwt,
			body
		});
	},

	updateTournament: (
		jwt: string,
		tournamentId: string,
		body: UpdateTournamentBody
	) => {
		return patch<UpdateTournamentBody, ITournament>(
			`/api/tournaments/${tournamentId}`,
			{ jwt, body }
		);
	},

	deleteTournament: (jwt: string, tournamentId: string) => {
		return remove<ITournament>(`/api/tournaments/${tournamentId}`, { jwt });
	},

	startTournament: (jwt: string, tournamentId: string) => {
		return post<null, ITournament>(`/api/tournaments/${tournamentId}/start`, {
			jwt
		});
	},

	generateBrackets: (jwt: string, tournamentId: string) => {
		return post<null, ITournament>(
			`/api/tournaments/${tournamentId}/generate-brackets`,
			{ jwt }
		);
	},

	cancelTournament: (jwt: string, tournamentId: string) => {
		return post<null, ITournament>(`/api/tournaments/${tournamentId}/cancel`, {
			jwt
		});
	},

	completeTournament: (jwt: string, tournamentId: string) => {
		return post<null, ITournament>(
			`/api/tournaments/${tournamentId}/complete`,
			{ jwt }
		);
	},

	startMatch: (jwt: string, tournamentId: string, body: StartMatchBody) => {
		return post<StartMatchBody, ITournament>(
			`/api/tournaments/${tournamentId}/start-match`,
			{ jwt, body }
		);
	},

	reportMatchResult: (
		jwt: string,
		tournamentId: string,
		body: ReportMatchResultBody
	) => {
		return post<ReportMatchResultBody, ITournament>(
			`/api/tournaments/${tournamentId}/report-match`,
			{ jwt, body }
		);
	},

	addModerator: (jwt: string, tournamentId: string, body: AddModeratorBody) => {
		return post<AddModeratorBody, ITournament>(
			`/api/tournaments/${tournamentId}/moderators`,
			{ jwt, body }
		);
	},

	removeModerator: (jwt: string, tournamentId: string, moderatorId: string) => {
		return remove<ITournament>(
			`/api/tournaments/${tournamentId}/moderators/${moderatorId}`,
			{ jwt }
		);
	},

	// Utilities
	getMyTournaments: (jwt: string) => {
		return get<ITournament[]>("/api/tournaments/my-tournaments", { jwt });
	},

	getOrganizedTournaments: (jwt: string) => {
		return get<ITournament[]>("/api/tournaments/organized", { jwt });
	},

	getModeratedTournaments: (jwt: string) => {
		return get<ITournament[]>("/api/tournaments/moderated", { jwt });
	},

	// Match management
	getMatches: (jwt: string, tournamentId: string) => {
		return get<ITournament["matches"]>(
			`/api/tournaments/${tournamentId}/matches`,
			{ jwt }
		);
	},

	getUpcomingMatches: (jwt: string, tournamentId: string) => {
		return get<ITournament["matches"]>(
			`/api/tournaments/${tournamentId}/matches/upcoming`,
			{ jwt }
		);
	},

	getUserMatches: (jwt: string, tournamentId: string) => {
		return get<ITournament["matches"]>(
			`/api/tournaments/${tournamentId}/matches/mine`,
			{ jwt }
		);
	}
};
