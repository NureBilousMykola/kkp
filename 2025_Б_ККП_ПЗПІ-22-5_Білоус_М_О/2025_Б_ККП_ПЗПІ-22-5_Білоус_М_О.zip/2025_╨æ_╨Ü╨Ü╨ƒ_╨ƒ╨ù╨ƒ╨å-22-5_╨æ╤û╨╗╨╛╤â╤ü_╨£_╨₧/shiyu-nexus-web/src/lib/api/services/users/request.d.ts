import type { IUser, MyAgent, MyEngine } from "../../models/IUser";

export type UpdateMyUserBody = {
	email?: IUser["email"];
	username?: IUser["username"];
};

export type UpdateMyAgentBody = {
	level: MyAgent["level"];
	mindscape: MyAgent["mindscape"];
};

export interface AddMyAgentsBody {
	agents: {
		agentId: MyAgent["agent"]["_id"];
		level: MyAgent["level"];
		mindscape: MyAgent["mindscape"];
	}[];
}

export type UpdateMyEngineBody = {
	level: MyEngine["level"];
	ascension: MyEngine["ascension"];
};

export interface AddMyEnginesBody {
	engines: {
		engineId: MyEngine["engine"]["_id"];
		level: MyEngine["level"];
		ascension: MyEngine["ascension"];
	}[];
}

export interface CreateMySaveBody {
	name: string;
	description: string;
	agentIds: string[];
}

export interface UpdateMySaveBody {
	name?: string;
	description?: string;
	agentIds?: string[];
}
