import { get, patch, post, remove } from "../..";
import type { ISave } from "../../models/ISave";
import type { IUser } from "../../models/IUser";
import type {
	AddMyAgentsBody,
	AddMyEnginesBody,
	CreateMySaveBody,
	UpdateMyAgentBody,
	UpdateMyEngineBody,
	UpdateMySaveBody,
	UpdateMyUserBody
} from "./request";

export const adminUserService = {
	getUsers: (jwt: string) => {
		return get<IUser[]>("/api/users", { jwt });
	},

	getUser: (jwt: string, id: string) => {
		return get<IUser>(`/api/users/${id}`, { jwt });
	},

	updateUserRole: (jwt: string, id: string, role: string) => {
		return patch<{ role: string }, IUser>(`/api/users/${id}/role`, {
			jwt,
			body: { role }
		});
	},

	updateUserPermissions: (jwt: string, id: string, permissions: string[]) => {
		return patch<{ permissions: string[] }, IUser>(
			`/api/users/${id}/permissions`,
			{
				jwt,
				body: { permissions }
			}
		);
	},

	deleteUser: (jwt: string, id: string) => {
		return remove<IUser>(`/api/users/${id}`, { jwt });
	}
};

export const myUserService = {
	getMyUser: async (jwt: string) => {
		return get<IUser>("/api/users/profile", { jwt });
	},

	updateMyLogin: (jwt: string, params: UpdateMyUserBody) => {
		return patch<UpdateMyUserBody, IUser>("/api/users/profile", {
			jwt,
			body: params
		});
	},

	addMyAgents: (jwt: string, params: AddMyAgentsBody) => {
		return post<AddMyAgentsBody, IUser>("/api/users/inventory/agents", {
			jwt,
			body: params
		});
	},

	updateMyAgent: (
		jwt: string,
		agentId: string,
		agentData: UpdateMyAgentBody
	) => {
		return patch<UpdateMyAgentBody, IUser>(
			`/api/users/inventory/agents/${agentId}`,
			{
				jwt,
				body: agentData
			}
		);
	},

	removeMyAgent: (jwt: string, agentId: string) => {
		return remove<IUser>(`/api/users/inventory/agents/${agentId}`, { jwt });
	},

	addMyEngines: (jwt: string, params: AddMyEnginesBody) => {
		return post<AddMyEnginesBody, IUser>("/api/users/inventory/engines", {
			jwt,
			body: params
		});
	},

	updateMyEngine: (
		jwt: string,
		engineId: string,
		engineData: UpdateMyEngineBody
	) => {
		return patch<UpdateMyEngineBody, IUser>(
			`/api/users/inventory/engines/${engineId}`,
			{
				jwt,
				body: engineData
			}
		);
	},

	removeMyEngine: (jwt: string, engineId: string) => {
		return remove<IUser>(`/api/users/inventory/engines/${engineId}`, { jwt });
	},

	getMyAgentSaves: (jwt: string) => {
		return get<ISave[]>("/api/users/agent-saves", { jwt });
	},

	getMyAgentSave: (jwt: string, saveId: string) => {
		return get<ISave>(`/api/users/agent-saves/${saveId}`, { jwt });
	},

	updateMyAgentSave: (
		jwt: string,
		saveId: string,
		params: UpdateMySaveBody
	) => {
		return patch<UpdateMySaveBody, ISave>(`/api/users/agent-saves/${saveId}`, {
			jwt,
			body: params
		});
	},

	deleteMyAgentSave: (jwt: string, saveId: string) => {
		return remove<{ message: string }>(`/api/users/agent-saves/${saveId}`, {
			jwt
		});
	},

	createMyAgentSave: (jwt: string, params: CreateMySaveBody) => {
		return post<CreateMySaveBody, IUser>("/api/users/agent-saves", {
			jwt,
			body: params
		});
	}
};
