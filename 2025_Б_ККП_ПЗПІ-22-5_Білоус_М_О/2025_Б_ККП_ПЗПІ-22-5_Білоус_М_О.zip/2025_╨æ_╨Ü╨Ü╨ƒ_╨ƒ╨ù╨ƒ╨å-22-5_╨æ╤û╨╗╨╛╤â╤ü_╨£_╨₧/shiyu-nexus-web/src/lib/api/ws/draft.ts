import type { IGameSession } from "@lib/api/models/game/IGameSession";
import { type Socket, io } from "socket.io-client";

interface ClientToServerEvents {
	joinSession: (sessionId: string) => void;
}

interface ServerToClientEvents {
	sessionUpdate: (session: IGameSession) => void;
	phaseTimeout: () => void;
	error: (error: string) => void;
}

export class DraftService {
	private socket?: Socket<ServerToClientEvents, ClientToServerEvents>;

	connectToSession(userToken: string, sessionId: string) {
		if (typeof window === "undefined") return;

		if (!userToken) {
			throw new Error("Must be authenticated to connect to draft WS");
		}

		// reuse existing socket if already connected
		if (this.socket?.connected) {
			this.socket.emit("joinSession", sessionId);
			return;
		}

		this.socket = io(`${process.env.NEXT_PUBLIC_WS_URL}/draft`, {
			auth: {
				token: userToken
			},
			extraHeaders: {
				Authorization: `Bearer ${userToken}`
			},
			transports: ["websocket"], // force WS, skip polling
			reconnectionAttempts: 5
		});

		this.socket.on("connect", () => {
			console.debug("[DraftService] connected:", this.socket?.id);
			this.socket?.emit("joinSession", sessionId);
		});

		this.socket.on("connect_error", (err) => {
			console.error("[DraftService] connection error:", err);
		});

		this.socket.on("disconnect", (reason) => {
			console.debug("[DraftService] disconnected:", reason);
		});

		this.socket.on("error", (error: string) => {
			console.error("[DraftService] socket error:", error);
		});
	}

	onSessionUpdate(handler: (session: IGameSession) => void): () => void {
		this.socket?.on("sessionUpdate", handler);
		return () => {
			this.socket?.off("sessionUpdate", handler);
		};
	}

	onPhaseTimeout(handler: () => void): () => void {
		this.socket?.on("phaseTimeout", handler);
		return () => {
			this.socket?.off("phaseTimeout", handler);
		};
	}

	disconnect() {
		this.socket?.disconnect();
		this.socket = undefined;
	}
}

export const draftService = new DraftService();
