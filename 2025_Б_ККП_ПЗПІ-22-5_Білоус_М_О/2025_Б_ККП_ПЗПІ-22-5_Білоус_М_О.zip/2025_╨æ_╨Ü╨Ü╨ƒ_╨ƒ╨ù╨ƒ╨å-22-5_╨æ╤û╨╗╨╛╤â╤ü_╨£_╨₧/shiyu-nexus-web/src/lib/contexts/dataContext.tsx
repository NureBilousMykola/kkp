import { getItems, getTimestamp, setItems } from "@/lib/db";
import { createContext, useContext, useEffect, useState } from "react";
import type { ApiResponse } from "../api";

const CACHE_TTL = 1000 * 60 * 60; // 1 hour

interface DataService<T> {
	getData: () => Promise<ApiResponse<T[]>>;
}

interface DataContextType<T> {
	data: T[];
	loading: boolean;
	refreshData: () => Promise<void>;
}

export function createDataContext<T>(
	storageKey: string,
	dataService: DataService<T>
) {
	const DataContext = createContext<DataContextType<T> | null>(null);

	const DataProvider = ({ children }: { children: React.ReactNode }) => {
		const [data, setData] = useState<T[] | null>(null);
		const [loading, setLoading] = useState(true);

		useEffect(() => {
			(async () => {
				const ts = await getTimestamp(storageKey);
				const cached = await getItems<T>(storageKey);
				if (cached && ts && Date.now() - ts < CACHE_TTL) {
					setData(cached);
					setLoading(false);
				} else {
					await refreshData();
				}
			})();
		}, [storageKey]);

		const refreshData = async () => {
			setLoading(true);
			const fresh = await dataService.getData();

			if (!fresh.ok) {
				console.error(fresh.error);
				setLoading(false);
				return;
			}

			const newData = fresh.data || [];
			setData(newData);

			await setItems(storageKey, newData); // timestamp updated automatically

			setLoading(false);
		};

		return (
			<DataContext.Provider value={{ data: data || [], loading, refreshData }}>
				{children}
			</DataContext.Provider>
		);
	};

	const useData = () => {
		const ctx = useContext(DataContext);
		if (!ctx) throw new Error(`useData must be inside ${storageKey}Provider`);
		return ctx;
	};

	return { DataProvider, useData };
}
