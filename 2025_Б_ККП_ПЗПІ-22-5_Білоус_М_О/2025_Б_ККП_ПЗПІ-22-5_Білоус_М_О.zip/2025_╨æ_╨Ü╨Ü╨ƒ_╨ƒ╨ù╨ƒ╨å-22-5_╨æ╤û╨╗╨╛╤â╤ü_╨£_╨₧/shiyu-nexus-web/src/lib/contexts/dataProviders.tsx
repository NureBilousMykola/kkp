import type { IAgent } from "../api/models/IAgent";
import type { IEnemy } from "../api/models/IEnemy";
import type { IEngine } from "../api/models/IEngine";
import type { IFaction } from "../api/models/IFaction";
import { agentService } from "../api/services/agents/service";
import { enemyService } from "../api/services/enemies/service";
import { engineService } from "../api/services/engines/service";
import { factionService } from "../api/services/factions/service";
import {
	AGENTS_STORE_KEY,
	ENEMIES_STORE_KEY,
	ENGINES_STORE_KEY,
	FACTIONS_STORE_KEY
} from "../db";
import { createDataContext } from "./dataContext";

export const { DataProvider: AgentsProvider, useData: useAgents } =
	createDataContext<IAgent>(AGENTS_STORE_KEY, {
		getData: agentService.getAgents
	});

export const { DataProvider: EnginesProvider, useData: useEngines } =
	createDataContext<IEngine>(ENGINES_STORE_KEY, {
		getData: engineService.getEngines
	});

export const { DataProvider: FactionsProvider, useData: useFactions } =
	createDataContext<IFaction>(FACTIONS_STORE_KEY, {
		getData: factionService.getFactions
	});

export const { DataProvider: EnemiesProvider, useData: useEnemies } =
	createDataContext<IEnemy>(ENEMIES_STORE_KEY, {
		getData: enemyService.getEnemies
	});
