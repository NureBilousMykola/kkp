"use client";

import {
	createContext,
	useContext,
	useEffect,
	useState,
	type ReactNode,
	useCallback
} from "react";
import type { IGameSession } from "@lib/api/models/game/IGameSession";
import { draftService } from "@lib/api/ws/draft";

interface DraftContextValue {
	session: IGameSession | null;
	connected: boolean;
	error: string | null;
	token: string;
	connect: (sessionId: string) => void;
	disconnect: () => void;
}

const DraftContext = createContext<DraftContextValue | undefined>(undefined);

export const GameProvider = ({
	token,
	children
}: {
	token: string;
	children: ReactNode;
}) => {
	const [session, setSession] = useState<IGameSession | null>(null);
	const [connected, setConnected] = useState(false);
	const [error, setError] = useState<string | null>(null);

	// Handlers
	const handleSessionUpdate = useCallback((s: IGameSession) => {
		setSession(s);
	}, []);

	const handlePhaseTimeout = useCallback(() => {
		// e.g. show a notice
		console.warn("Phase timed out!");
	}, []);

	useEffect(() => {
		// wire up events once socket is created
		draftService.onSessionUpdate(handleSessionUpdate);
		draftService.onPhaseTimeout(handlePhaseTimeout);

		return () => {
			draftService.onSessionUpdate(() => {});
			draftService.onPhaseTimeout(() => {});
			draftService.disconnect();
		};
	}, [handleSessionUpdate, handlePhaseTimeout]);

	const connect = useCallback(
		(sessionId: string) => {
			setError(null);
			draftService.connectToSession(token, sessionId);
			setConnected(true);
		},
		[token]
	);

	const disconnect = useCallback(() => {
		draftService.disconnect();
		setConnected(false);
		setSession(null);
	}, []);

	return (
		<DraftContext.Provider
			value={{
				session,
				connected,
				error,
				token,
				connect,
				disconnect
			}}
		>
			{children}
		</DraftContext.Provider>
	);
};

export function useGameInfo(): DraftContextValue {
	const ctx = useContext(DraftContext);
	if (!ctx) {
		throw new Error("useDraft must be used within a DraftProvider");
	}
	return ctx;
}
