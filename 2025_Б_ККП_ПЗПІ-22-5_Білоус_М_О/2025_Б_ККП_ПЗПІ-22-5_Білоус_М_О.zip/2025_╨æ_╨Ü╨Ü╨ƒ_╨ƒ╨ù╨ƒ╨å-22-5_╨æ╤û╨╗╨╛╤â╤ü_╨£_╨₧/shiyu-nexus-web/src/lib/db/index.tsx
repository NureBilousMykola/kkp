import { openDB } from "idb";

const DB_NAME = "GameCache";
export const AGENTS_STORE_KEY = "agents";
export const ENGINES_STORE_KEY = "engines";
export const FACTIONS_STORE_KEY = "factions";
export const ENEMIES_STORE_KEY = "enemies";

export async function getDB() {
	return openDB(DB_NAME, 1, {
		upgrade(db) {
			if (!db.objectStoreNames.contains(AGENTS_STORE_KEY)) {
				const s = db.createObjectStore(AGENTS_STORE_KEY, { keyPath: "key" });
				s.createIndex("timestamp", "timestamp");
			}
			if (!db.objectStoreNames.contains(ENGINES_STORE_KEY)) {
				const s = db.createObjectStore(ENGINES_STORE_KEY, { keyPath: "key" });
				s.createIndex("timestamp", "timestamp");
			}
			if (!db.objectStoreNames.contains(FACTIONS_STORE_KEY)) {
				const s = db.createObjectStore(FACTIONS_STORE_KEY, { keyPath: "key" });
				s.createIndex("timestamp", "timestamp");
			}
			if (!db.objectStoreNames.contains(ENEMIES_STORE_KEY)) {
				const s = db.createObjectStore(ENEMIES_STORE_KEY, { keyPath: "key" });
				s.createIndex("timestamp", "timestamp");
			}
		}
	});
}

export async function getTimestamp(key: string) {
	const db = await getDB();
	return (await db.get(key, key))?.timestamp as number | undefined;
}

export async function getItems<T>(key: string) {
	const db = await getDB();
	return (await db.get(key, key))?.data as T[];
}

export async function setItems<T>(key: string, items: T[]) {
	const db = await getDB();
	await db.put(key, {
		key: key,
		data: items,
		timestamp: Date.now()
	});
}
