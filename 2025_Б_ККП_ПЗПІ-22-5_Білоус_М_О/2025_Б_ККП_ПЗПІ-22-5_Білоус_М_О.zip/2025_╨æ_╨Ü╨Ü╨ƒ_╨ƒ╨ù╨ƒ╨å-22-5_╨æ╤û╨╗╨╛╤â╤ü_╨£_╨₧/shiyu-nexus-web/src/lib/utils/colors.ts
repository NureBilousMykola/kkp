import type { Attribute } from "../api/keys/Attribute";
import type { Rarity } from "../api/keys/Rarity";
import type { Specialty } from "../api/keys/Specialty";

export const AttributeColors: {
	[key in Attribute]: {
		background: string;
		border: string;
		hover: string;
		text: string;
	};
} = {
	physical: {
		background: "bg-physical",
		border: "border-physical",
		text: "text-physical",
		hover: "hover:border-physical"
	},
	electric: {
		background: "bg-electric",
		border: "border-electric",
		text: "text-electric",
		hover: "hover:border-electric"
	},
	ice: {
		background: "bg-ice",
		border: "border-ice",
		text: "text-ice",
		hover: "hover:border-ice"
	},
	fire: {
		background: "bg-fire",
		border: "border-fire",
		text: "text-fire",
		hover: "hover:border-fire"
	},
	ether: {
		background: "bg-ether",
		border: "border-ether",
		text: "text-ether",
		hover: "hover:border-ether"
	},
	frost: {
		background: "bg-frost",
		border: "border-frost",
		text: "text-frost",
		hover: "hover:border-frost"
	}
};

export const SpecialityColors: {
	[key in Specialty]: {
		background: string;
		border: string;
		hover: string;
		text: string;
	};
} = {
	attack: {
		background: "bg-physical/50",
		border: "border-physical/50",
		text: "text-physical/50",
		hover: "hover:border-physical/50"
	},
	anomaly: {
		background: "bg-electric/50",
		border: "border-electric/50",
		text: "text-electric/50",
		hover: "hover:border-electric/50"
	},
	defense: {
		background: "bg-ice/50",
		border: "border-ice/50",
		text: "text-ice/50",
		hover: "hover:border-ice/50"
	},
	stun: {
		background: "bg-fire/50",
		border: "border-fire/50",
		text: "text-fire/50",
		hover: "hover:border-fire/50"
	},
	support: {
		background: "bg-ether/50",
		border: "border-ether/50",
		text: "text-ether/50",
		hover: "hover:border-ether/50"
	}
};

export const RarityColors: {
	[key in Rarity]: {
		background: string;
		border: string;
		hover: string;
		text: string;
	};
} = {
	S: {
		background: "bg-rarity-s",
		border: "border-rarity-s",
		text: "text-rarity-s",
		hover: "hover:border-rarity-s"
	},
	A: {
		background: "bg-rarity-a",
		border: "border-rarity-a",
		text: "text-rarity-a",
		hover: "hover:border-rarity-a"
	},
	B: {
		background: "bg-rarity-b",
		border: "border-rarity-b",
		text: "text-rarity-b",
		hover: "hover:border-rarity-b"
	}
};
