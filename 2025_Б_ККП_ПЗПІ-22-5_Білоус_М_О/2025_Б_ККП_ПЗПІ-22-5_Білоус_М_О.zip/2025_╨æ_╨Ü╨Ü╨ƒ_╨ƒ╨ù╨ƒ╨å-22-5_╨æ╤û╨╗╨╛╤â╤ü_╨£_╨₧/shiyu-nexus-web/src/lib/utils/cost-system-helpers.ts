import type { IAgentCost, IEngineCost } from "../api/models/ICostSystem";

/**
 * Convert Map to Record for API serialization
 */
export function serializeAgentCosts(agentCosts: IAgentCost[]) {
	return agentCosts.map((cost) => ({
		agent: typeof cost.agent === "string" ? cost.agent : cost.agent._id,
		mindscapeCosts: Object.fromEntries(cost.mindscapeCosts)
	}));
}

/**
 * Convert Map to Record for API serialization
 */
export function serializeEngineCosts(engineCosts: IEngineCost[]) {
	return engineCosts.map((cost) => ({
		engine: typeof cost.engine === "string" ? cost.engine : cost.engine._id,
		ascensionCosts: Object.fromEntries(cost.ascensionCosts)
	}));
}

/**
 * Convert Record to Map after API deserialization
 */
export function deserializeAgentCosts(agentCosts: any[]): IAgentCost[] {
	return agentCosts.map((cost) => ({
		...cost,
		mindscapeCosts: new Map(
			Object.entries(cost.mindscapeCosts || {}).map(([k, v]) => [
				Number(k),
				Number(v)
			])
		)
	}));
}

/**
 * Convert Record to Map after API deserialization
 */
export function deserializeEngineCosts(engineCosts: any[]): IEngineCost[] {
	return engineCosts.map((cost) => ({
		...cost,
		ascensionCosts: new Map(
			Object.entries(cost.ascensionCosts || {}).map(([k, v]) => [
				Number(k),
				Number(v)
			])
		)
	}));
}

/**
 * Get default mindscape costs for an agent
 */
export function getDefaultMindscapeCosts(): Map<number, number> {
	return new Map([
		[0, 10],
		[1, 15],
		[2, 20],
		[3, 25],
		[4, 30],
		[5, 35],
		[6, 40]
	]);
}

/**
 * Get default ascension costs for an engine
 */
export function getDefaultAscensionCosts(): Map<number, number> {
	return new Map([
		[1, 5],
		[2, 8],
		[3, 12],
		[4, 15],
		[5, 20]
	]);
}
