import "server-only";

import { cookies } from "next/headers";
import { cache } from "react";
import { jwtVerify } from "jose";
import { redirect } from "next/navigation";

const secretKey = process.env.JWT_SECRET;
const encodedKey = new TextEncoder().encode(secretKey);

export async function decrypt(session: string | undefined = "") {
	try {
		const { payload } = await jwtVerify(session, encodedKey, {
			algorithms: ["HS256"]
		});
		return payload;
	} catch (error) {
		console.log("Failed to verify session");
	}
}

export const verifySession = cache(async () => {
	const cookie = (await cookies()).get("auth_token")?.value;

	const decoded = (await decrypt(cookie)) as { [prop: string]: string };

	if (!cookie || !decoded) {
		redirect("/auth/login");
	}

	return {
		token: cookie || "",
		id: decoded.sub,
		email: decoded.email,
		username: decoded.username,
		role: decoded.role,
		permissions: decoded.permissions,
		discordId: decoded.discordId
	};
});
