export const fuzzySearch = (query: string, text: string): boolean => {
	const queryChars = query.toLowerCase().split(""); // Split query into agents
	const textLower = text.toLowerCase();

	let queryIndex = 0;

	for (let i = 0; i < textLower.length; i++) {
		if (textLower[i] === queryChars[queryIndex]) {
			queryIndex++;
		}
		if (queryIndex === queryChars.length) {
			return true; // All agents in the query were found in order
		}
	}

	return false;
};
