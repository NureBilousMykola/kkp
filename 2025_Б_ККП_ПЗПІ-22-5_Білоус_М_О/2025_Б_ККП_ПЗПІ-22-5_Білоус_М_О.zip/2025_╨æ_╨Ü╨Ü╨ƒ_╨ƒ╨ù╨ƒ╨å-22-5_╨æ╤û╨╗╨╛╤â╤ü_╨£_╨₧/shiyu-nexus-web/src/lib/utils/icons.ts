import type { Attribute } from "../api/keys/Attribute";
import type { Specialty } from "../api/keys/Specialty";

export const AttributeIcons: {
	[key in Attribute]: string;
} = {
	physical: "/icons/attributes/physical.png",
	fire: "/icons/attributes/fire.png",
	ice: "/icons/attributes/ice.png",
	ether: "/icons/attributes/ether.png",
	electric: "/icons/attributes/electric.png",
	frost: "/icons/attributes/frost.png"
};

export const SpecialtyIcons: {
	[key in Specialty]: string;
} = {
	attack: "/icons/specialties/attack.png",
	anomaly: "/icons/specialties/anomaly.png",
	defense: "/icons/specialties/defense.png",
	stun: "/icons/specialties/stun.png",
	support: "/icons/specialties/support.png"
};
