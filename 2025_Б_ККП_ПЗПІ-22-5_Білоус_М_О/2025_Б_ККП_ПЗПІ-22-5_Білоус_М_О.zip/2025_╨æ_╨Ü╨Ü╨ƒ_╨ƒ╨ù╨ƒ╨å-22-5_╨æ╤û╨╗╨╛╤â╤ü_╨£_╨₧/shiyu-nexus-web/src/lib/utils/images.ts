export const getDiscordAvatarUrl = (
	discordId: string,
	discordAvatar?: string
) => {
	if (!discordAvatar || discordAvatar === "default") {
		// Return the default Discord avatar if no avatar hash is provided
		// The default avatar is determined by the user's discriminator (last digit of ID)
		const defaultAvatarNumber = Number.parseInt(discordId.slice(-1)) % 5;
		return `https://cdn.discordapp.com/embed/avatars/${String(
			defaultAvatarNumber
		)}.png`;
	}
	return `https://cdn.discordapp.com/avatars/${discordId}/${discordAvatar}`;
};

export const getMindscapeImage = (name: string, mindscape: number) => {
	// FIXME: Implement proper handling
	if (mindscape === 6) {
		return `https://raw.githubusercontent.com/shiyu-nexus/shiyu-nexus-assets/refs/heads/main/asset/agent/mindscape/Full/${name}.webp`;
	}
	return `https://raw.githubusercontent.com/shiyu-nexus/shiyu-nexus-assets/refs/heads/main/asset/agent/mindscape/Partial/${name}.webp`;
};
