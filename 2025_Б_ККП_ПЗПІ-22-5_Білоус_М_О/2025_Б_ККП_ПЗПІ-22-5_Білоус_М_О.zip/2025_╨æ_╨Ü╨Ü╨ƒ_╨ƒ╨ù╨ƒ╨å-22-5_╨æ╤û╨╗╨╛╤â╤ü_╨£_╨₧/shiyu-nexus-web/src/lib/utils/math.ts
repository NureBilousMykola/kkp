export const clamp = (value: number, min: number, max: number) =>
	Math.min(Math.max(value, min), max);

export const randomHash = (length: number) => {
	const array = new Uint32Array(length);
	return crypto.getRandomValues(array);
};
