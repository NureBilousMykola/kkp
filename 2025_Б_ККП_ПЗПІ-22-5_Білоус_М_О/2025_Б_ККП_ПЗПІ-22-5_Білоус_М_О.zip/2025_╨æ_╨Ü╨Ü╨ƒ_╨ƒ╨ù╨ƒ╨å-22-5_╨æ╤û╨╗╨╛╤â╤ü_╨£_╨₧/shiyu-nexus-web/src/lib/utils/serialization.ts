/**
 * Utility functions for serializing and deserializing Map objects
 * Used for localStorage and API communication
 */

export function mapToObject<K extends string | number, V>(
	map: Map<K, V>
): Record<K, V> {
	const obj = {} as Record<K, V>;
	for (const [key, value] of map.entries()) {
		obj[key] = value;
	}
	return obj;
}

export function objectToMap<K extends string | number, V>(
	obj: Record<K, V>
): Map<K, V> {
	const map = new Map<K, V>();
	for (const [key, value] of Object.entries(obj)) {
		map.set(key as K, value as V);
	}
	return map;
}
