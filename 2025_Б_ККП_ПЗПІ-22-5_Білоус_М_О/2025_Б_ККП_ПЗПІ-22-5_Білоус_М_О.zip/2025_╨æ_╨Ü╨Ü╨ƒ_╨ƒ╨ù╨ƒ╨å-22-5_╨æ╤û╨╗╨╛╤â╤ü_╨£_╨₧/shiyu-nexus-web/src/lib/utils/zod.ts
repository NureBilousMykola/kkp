import { z } from "zod";

export const checkbox = (trueValue: string | number | boolean = "on") =>
	z.union([
		z.literal(trueValue).transform(() => true),
		z.literal(undefined).transform(() => false),
		z.literal(null).transform(() => false)
	]);

export const optionalUrl = () =>
	z
		.string()
		.optional()
		.refine(
			(value) =>
				value
					? /^(https?):\/\/(?=.*\.[a-z]{2,})[^\s$.?#].[^\s]*$/i.test(value)
					: true,
			{
				message: "Please enter a valid URL"
			}
		);
